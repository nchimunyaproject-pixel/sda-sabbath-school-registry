-- ==========================================================
-- SDA Digital Church Register Database Schema (MySQL / MariaDB)
-- Seventh-day Adventist Church Management System (2025 Edition)
-- Default Database: sda_church_registry
-- ==========================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `sda_church_registry` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `sda_church_registry`;

-- ----------------------------------------------------------
-- 1. Table: conferences (Local Conferences / Missions)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `conferences` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `presidentName` VARCHAR(100) NOT NULL,
  `presidentEmail` VARCHAR(100) NOT NULL,
  `presidentPhone` VARCHAR(50) DEFAULT NULL,
  `headquartersCity` VARCHAR(100) DEFAULT NULL,
  `unionName` VARCHAR(150) DEFAULT 'Southern Zambia Union Conference (SZUC)',
  `address` TEXT DEFAULT NULL,
  `phone` VARCHAR(50) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `createdAt` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 2. Table: districts (Pastoral Circuits / Districts)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `districts` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `conferenceId` VARCHAR(50) NOT NULL,
  `conferenceName` VARCHAR(150) DEFAULT NULL,
  `pastorName` VARCHAR(100) NOT NULL,
  `pastorEmail` VARCHAR(100) NOT NULL,
  `pastorPhone` VARCHAR(50) DEFAULT NULL,
  `createdAt` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `conferenceId` (`conferenceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 3. Table: churches (Registered Church Stations & Companies)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `churches` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `conference` VARCHAR(100) NOT NULL,
  `conferenceId` VARCHAR(50) DEFAULT NULL,
  `district` VARCHAR(100) DEFAULT NULL,
  `districtId` VARCHAR(50) DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `phone` VARCHAR(50) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `elderName` VARCHAR(100) DEFAULT NULL,
  `elderEmail` VARCHAR(100) DEFAULT NULL,
  `pastorId` VARCHAR(50) DEFAULT NULL,
  `pastorName` VARCHAR(100) DEFAULT NULL,
  `isDemo` TINYINT(1) DEFAULT 0,
  `createdAt` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `conferenceId` (`conferenceId`),
  KEY `districtId` (`districtId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 4. Table: users (All 8 Denominational Tiers & Officers)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('SUPER_ADMIN', 'CONFERENCE_PRESIDENT', 'DISTRICT_PASTOR', 'CHURCH_ADMIN', 'CLERK', 'TEACHER', 'TREASURER', 'SUPERINTENDENT') NOT NULL,
  `assignedClass` VARCHAR(50) DEFAULT NULL,
  `language` VARCHAR(50) DEFAULT NULL,
  `churchId` VARCHAR(50) DEFAULT NULL,
  `churchName` VARCHAR(100) DEFAULT NULL,
  `districtId` VARCHAR(50) DEFAULT NULL,
  `districtName` VARCHAR(100) DEFAULT NULL,
  `conferenceId` VARCHAR(50) DEFAULT NULL,
  `conferenceName` VARCHAR(100) DEFAULT NULL,
  `phone` VARCHAR(50) DEFAULT NULL,
  `title` VARCHAR(150) DEFAULT NULL,
  `status` VARCHAR(20) DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `churchId` (`churchId`),
  KEY `districtId` (`districtId`),
  KEY `conferenceId` (`conferenceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 5. Table: classes (Sabbath School Classes)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `classes` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `teacherId` VARCHAR(50) DEFAULT NULL,
  `language` VARCHAR(50) DEFAULT NULL,
  `churchId` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `churchId` (`churchId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 6. Table: students (Class Rosters)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `students` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `classId` VARCHAR(50) NOT NULL,
  `attendanceStatus` VARCHAR(20) DEFAULT 'unmarked',
  `lessonStudied` TINYINT(1) DEFAULT 0,
  `isTransferring` TINYINT(1) DEFAULT 0,
  `memberId` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classId` (`classId`),
  KEY `memberId` (`memberId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 7. Table: church_members (Master Membership Roll)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `church_members` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `memberNumber` VARCHAR(50) DEFAULT NULL,
  `givenNames` VARCHAR(100) DEFAULT NULL,
  `primarySurname` VARCHAR(100) DEFAULT NULL,
  `secondarySurname` VARCHAR(100) DEFAULT NULL,
  `churchId` VARCHAR(50) NOT NULL,
  `status` ENUM('active', 'transferring', 'missing', 'censured', 'disfellowshipped', 'deceased', 'transferred', 'removed') NOT NULL DEFAULT 'active',
  `baptismDate` VARCHAR(50) DEFAULT NULL,
  `dob` VARCHAR(50) DEFAULT NULL,
  `gender` ENUM('male', 'female', 'other') DEFAULT NULL,
  `contact` VARCHAR(50) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `familyUnitId` VARCHAR(50) DEFAULT NULL,
  `relationshipToHead` VARCHAR(50) DEFAULT NULL,
  `memberType` VARCHAR(50) DEFAULT NULL,
  `outreachFlag` TINYINT(1) DEFAULT 0,
  `outreachNotes` TEXT DEFAULT NULL,
  `lastAttendDate` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `churchId` (`churchId`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 8. Table: family_units (Households)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `family_units` (
  `id` VARCHAR(50) NOT NULL,
  `churchId` VARCHAR(50) NOT NULL,
  `familyName` VARCHAR(100) NOT NULL,
  `primaryContactId` VARCHAR(50) NOT NULL,
  `primaryContactName` VARCHAR(100) DEFAULT NULL,
  `address` TEXT NOT NULL,
  `contactPhone` VARCHAR(50) NOT NULL,
  `notes` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `churchId` (`churchId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 9. Table: study_guide_orders (Superintendent Orders)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `study_guide_orders` (
  `id` VARCHAR(50) NOT NULL,
  `churchId` VARCHAR(50) NOT NULL,
  `orderNumber` VARCHAR(50) NOT NULL,
  `memberId` VARCHAR(50) DEFAULT NULL,
  `memberName` VARCHAR(100) NOT NULL,
  `memberContact` VARCHAR(50) DEFAULT NULL,
  `memberEmail` VARCHAR(100) DEFAULT NULL,
  `guideType` VARCHAR(100) NOT NULL,
  `quarter` VARCHAR(50) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `unitPrice` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `totalAmount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `paymentStatus` ENUM('paid', 'pending') NOT NULL DEFAULT 'pending',
  `paymentMethod` VARCHAR(50) NOT NULL DEFAULT 'Cash',
  `orderStatus` ENUM('placed', 'confirmed_with_abc', 'received_from_abc', 'distributed', 'cancelled') NOT NULL DEFAULT 'placed',
  `orderDate` VARCHAR(50) NOT NULL,
  `notes` TEXT DEFAULT NULL,
  `distributedDate` VARCHAR(50) DEFAULT NULL,
  `abcRequisitionRef` VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `churchId` (`churchId`),
  KEY `orderNumber` (`orderNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 10. Table: announcements
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `announcements` (
  `id` VARCHAR(50) NOT NULL,
  `teacherId` VARCHAR(50) NOT NULL,
  `teacherName` VARCHAR(100) NOT NULL,
  `className` VARCHAR(100) NOT NULL,
  `content` TEXT NOT NULL,
  `timestamp` DATETIME NOT NULL,
  `status` VARCHAR(20) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 11. Table: attendance_records
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `attendance_records` (
  `id` VARCHAR(50) NOT NULL,
  `date` DATE NOT NULL,
  `classId` VARCHAR(50) NOT NULL,
  `className` VARCHAR(100) NOT NULL,
  `teacherId` VARCHAR(50) NOT NULL,
  `teacherName` VARCHAR(100) NOT NULL,
  `totalStudents` INT NOT NULL,
  `presentCount` INT NOT NULL,
  `absentCount` INT NOT NULL,
  `visitorCount` INT NOT NULL,
  `lessonStudyCount` INT DEFAULT 0,
  `jsonData` LONGTEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classId` (`classId`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- 12. Table: generic_store (Treasury, Plans, Remittances)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `generic_store` (
  `entity_key` VARCHAR(50) NOT NULL,
  `data` LONGTEXT NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`entity_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- Initial Seed Data: Hierarchical Demonstration Environment
-- ----------------------------------------------------------

INSERT INTO `conferences` (`id`, `name`, `presidentName`, `presidentEmail`, `presidentPhone`, `headquartersCity`, `unionName`, `address`, `phone`, `email`, `createdAt`) VALUES
('conf-lusaka', 'Lusaka Conference', 'Pastor Dr. Harrington Simpasa', 'president@conference.org', '+260 211 251234', 'Lusaka', 'Southern Zambia Union Conference (SZUC)', 'Plot 3025, Independence Avenue, Lusaka', '+260 211 251234', 'info@lusakaconference.org', '2026-01-01T00:00:00.000Z')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

INSERT INTO `districts` (`id`, `name`, `conferenceId`, `conferenceName`, `pastorName`, `pastorEmail`, `pastorPhone`, `createdAt`) VALUES
('dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Pastor H. Chisenga', 'pastor@district.org', '+260 977 123456', '2026-01-01T00:00:00.000Z'),
('dist-central', 'Central Lusaka District', 'conf-lusaka', 'Lusaka Conference', 'Pastor Brian Mulenga', 'bmulenga@conference.org', '+260 971 889900', '2026-01-01T00:00:00.000Z')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

INSERT INTO `churches` (`id`, `name`, `conference`, `conferenceId`, `district`, `districtId`, `city`, `address`, `phone`, `email`, `elderName`, `elderEmail`, `isDemo`, `createdAt`) VALUES
('church-woodlands', 'Woodlands SDA Church', 'Lusaka Conference', 'conf-lusaka', 'Woodlands District', 'dist-woodlands', 'Lusaka', 'Woodlands Main Road, Lusaka, Zambia', '+260 211 254890', 'woodlands@church.org', 'Elder M. S. Banda', 'elder@church.org', 1, '2026-01-01T00:00:00.000Z'),
('church-libala', 'Libala SDA Church', 'Lusaka Conference', 'conf-lusaka', 'Central Lusaka District', 'dist-central', 'Lusaka', 'Libala South Grounds, Lusaka', '+260 211 289001', 'libala@church.org', 'Elder Joseph Phiri', 'jphiri@church.org', 0, '2026-01-01T00:00:00.000Z')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `assignedClass`, `language`, `churchId`, `churchName`, `districtId`, `districtName`, `conferenceId`, `conferenceName`, `title`, `phone`) VALUES
('superadmin-1', 'Elder Dr. Harrington Tembo', 'superadmin@sda.org', 'admin123', 'SUPER_ADMIN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'General Conference System Super Admin', '+260 977 000001'),
('pres-1', 'Pastor Dr. Harrington Simpasa', 'president@conference.org', 'president123', 'CONFERENCE_PRESIDENT', NULL, NULL, NULL, NULL, NULL, NULL, 'conf-lusaka', 'Lusaka Conference', 'Conference President (Territory Overseer)', '+260 211 251234'),
('pastor-1', 'Pastor H. Chisenga', 'pastor@district.org', 'pastor123', 'DISTRICT_PASTOR', NULL, NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'District Pastor (Pastoral Circuit Overseer)', '+260 977 123456'),
('elder-1', 'Elder M. S. Banda', 'elder@church.org', 'elder123', 'CHURCH_ADMIN', NULL, NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Church First Elder (Station Administrator)', '+260 977 111222'),
('clerk-1', 'Sister P. Tembo', 'clerk@church.org', 'clerk123', 'CLERK', NULL, NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Church Clerk (Secretariat)', '+260 978 222333'),
('treasurer-1', 'Elder Joseph Banda', 'treasurer@church.org', 'treasurer123', 'TREASURER', NULL, NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Church Treasurer (Sacred Trust)', '+260 977 444555'),
('superintendent-1', 'Sister R. Simpasa', 'superintendent@church.org', 'superintendent123', 'SUPERINTENDENT', NULL, NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Sabbath School Superintendent', '+260 977 666777'),
('t1', 'Elder Musonda', 'musonda@church.org', 'password123', 'TEACHER', 'c1', 'English', 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Adult Sabbath School Teacher', '+260 979 888999'),
('t2', 'Sister Chanda', 'chanda@church.org', 'password123', 'TEACHER', 'c2', NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Youth Ministry Teacher', '+260 971 222111'),
('t3', 'Brother Mwale', 'mwale@church.org', 'password123', 'TEACHER', 'c3', NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Primary Class Teacher', '+260 975 333222')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

INSERT INTO `classes` (`id`, `name`, `teacherId`, `language`, `churchId`) VALUES
('c1', 'Adult Sabbath School', 't1', 'English', 'church-woodlands'),
('c2', 'Youth Ministry', 't2', NULL, 'church-woodlands'),
('c3', 'Primary Class', 't3', NULL, 'church-woodlands')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

INSERT INTO `students` (`id`, `name`, `classId`, `attendanceStatus`, `lessonStudied`, `isTransferring`, `memberId`) VALUES
('s1', 'Alice Walker', 'c1', 'unmarked', 0, 0, 'mem-1'),
('s2', 'Robert Miller', 'c1', 'unmarked', 0, 0, 'mem-2'),
('s3', 'Sarah Jenkins', 'c2', 'unmarked', 0, 0, 'mem-3'),
('s4', 'Little Timmy', 'c3', 'unmarked', 0, 0, 'mem-4')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

COMMIT;
