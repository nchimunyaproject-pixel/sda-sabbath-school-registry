import express from 'express';
import cors from 'cors';
import mysql from 'mysql2/promise';

const app = express();
const PORT = 3001;

const dbConfig = {
  host: '127.0.0.1', 
  user: 'root',      
  password: '',      
  database: 'sda_church_registry',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
};

app.use(cors());
app.use(express.json({ limit: '50mb' }));

const pool = mysql.createPool(dbConfig);

/**
 * Seed Database with Initial Structure if Empty
 */
async function seedDatabase() {
  try {
    const [rows] = await pool.query('SELECT COUNT(*) as count FROM classes');
    if (rows[0].count === 0) {
      console.log('🌱 Database is empty. Seeding initial SDA classes...');
      
      const initialClasses = [
        ['c1', 'Adult Sabbath School', 't1', 'English'],
        ['c2', 'Youth Ministry', 't2', null],
        ['c3', 'Primary Class', 't3', null]
      ];

      await pool.query(
        'INSERT INTO classes (id, name, teacherId, language) VALUES ?',
        [initialClasses]
      );
      
      console.log('✅ Seeding complete.');
    }
  } catch (err) {
    console.error('❌ Seeding failed:', err.message);
  }
}

// Test connection and seed
try {
  const connection = await pool.getConnection();
  console.log('✅ DATABASE CONNECTED');
  connection.release();
  await seedDatabase();
} catch (err) {
  console.error('\n❌ DATABASE CONNECTION FAILED!');
}

/**
 * GET: Fetch all church registry data
 */
app.get('/api/data', async (req, res) => {
  try {
    const [users] = await pool.query('SELECT * FROM users');
    const [classes] = await pool.query('SELECT * FROM classes');
    const [students] = await pool.query('SELECT * FROM students');
    const [announcements] = await pool.query('SELECT * FROM announcements');
    const [attendanceRecords] = await pool.query('SELECT * FROM attendance_records');
    const [attStudents] = await pool.query('SELECT * FROM attendance_students');
    const [visitors] = await pool.query('SELECT * FROM visitors');

    const teachers = users.filter(u => u.role === 'TEACHER');
    const admins = users.filter(u => u.role === 'CLERK');

    const formattedClasses = classes.map(c => ({
      ...c,
      students: students.filter(s => s.classId === c.id).map(s => ({
        ...s,
        lessonStudied: !!s.lessonStudied
      }))
    }));

    const formattedAttendance = attendanceRecords.map(r => ({
      ...r,
      date: r.date instanceof Date ? r.date.toISOString().split('T')[0] : r.date,
      records: attStudents.filter(as => as.recordId === r.id).map(as => ({
        id: as.studentId,
        name: as.name,
        attendanceStatus: as.status,
        lessonStudied: !!as.lessonStudied
      })),
      visitors: visitors.filter(v => v.recordId === r.id)
    }));

    res.json({
      admins,
      teachers,
      classes: formattedClasses,
      announcements,
      attendanceRecords: formattedAttendance
    });
  } catch (err) {
    console.error('Database Read Error:', err.message);
    res.status(500).json({ error: 'Database Read Error' });
  }
});

/**
 * POST: Synchronize frontend state to MySQL
 */
app.post('/api/sync', async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const { admins, teachers, classes, announcements, attendanceRecords } = req.body;
    await connection.beginTransaction();

    await connection.query('DELETE FROM users');
    const allUsers = [...(admins || []), ...(teachers || [])];
    if (allUsers.length > 0) {
      await connection.query(
        'INSERT INTO users (id, name, email, password, role, assignedClass, language, churchName) VALUES ?',
        [allUsers.map(u => [u.id, u.name, u.email, u.password, u.role, u.assignedClass || null, u.language || null, u.churchName || null])]
      );
    }

    await connection.query('DELETE FROM students');
    await connection.query('DELETE FROM classes');
    if (classes && classes.length > 0) {
      await connection.query(
        'INSERT INTO classes (id, name, teacherId, language) VALUES ?',
        [classes.map(c => [c.id, c.name, c.teacherId || null, c.language || null])]
      );
      
      const allStudents = classes.flatMap(c => (c.students || []).map(s => [s.id, s.name, c.id, s.attendanceStatus, s.lessonStudied ? 1 : 0]));
      if (allStudents.length > 0) {
        await connection.query(
          'INSERT INTO students (id, name, classId, attendanceStatus, lessonStudied) VALUES ?',
          [allStudents]
        );
      }
    }

    await connection.query('DELETE FROM announcements');
    if (announcements && announcements.length > 0) {
      await connection.query(
        'INSERT INTO announcements (id, teacherId, teacherName, className, content, timestamp, status) VALUES ?',
        [announcements.map(a => [a.id, a.teacherId, a.teacherName, a.className, a.content, a.timestamp.slice(0, 19).replace('T', ' '), a.status])]
      );
    }

    await connection.query('DELETE FROM visitors');
    await connection.query('DELETE FROM attendance_students');
    await connection.query('DELETE FROM attendance_records');
    if (attendanceRecords && attendanceRecords.length > 0) {
      await connection.query(
        'INSERT INTO attendance_records (id, date, classId, className, teacherId, teacherName, totalStudents, presentCount, absentCount, visitorCount, lessonStudyCount) VALUES ?',
        [attendanceRecords.map(r => [r.id, r.date, r.classId, r.className, r.teacherId, r.teacherName, r.totalStudents, r.presentCount, r.absentCount, r.visitorCount, r.lessonStudyCount || 0])]
      );

      const historyStudents = attendanceRecords.flatMap(r => (r.records || []).map(s => [r.id, s.id, s.name, s.attendanceStatus, s.lessonStudied ? 1 : 0]));
      if (historyStudents.length > 0) {
        await connection.query(
          'INSERT INTO attendance_students (recordId, studentId, name, status, lessonStudied) VALUES ?',
          [historyStudents]
        );
      }

      const historyVisitors = attendanceRecords.flatMap(r => (r.visitors || []).map(v => [v.id, r.id, v.name, v.classId, v.contact || null, v.location || null, v.purpose || null]));
      if (historyVisitors.length > 0) {
        await connection.query(
          'INSERT INTO visitors (id, recordId, name, classId, contact, location, purpose) VALUES ?',
          [historyVisitors]
        );
      }
    }

    await connection.commit();
    res.json({ success: true });
  } catch (err) {
    await connection.rollback();
    console.error('MySQL Sync Error:', err.message);
    res.status(500).json({ error: 'Sync failed' });
  } finally {
    connection.release();
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server: http://localhost:${PORT}`);
});