-- ==========================================================
-- SDA Digital Church Register Database Schema (PostgreSQL)
-- Seventh-day Adventist Church Management System (2025 Edition)
-- Default Database: sda_church_registry
-- ==========================================================

-- 1. Create Custom ENUM Types
DO $$ BEGIN
  CREATE TYPE role_enum AS ENUM (
    'SUPER_ADMIN', 
    'CONFERENCE_PRESIDENT', 
    'DISTRICT_PASTOR', 
    'CHURCH_ADMIN', 
    'CLERK', 
    'TEACHER', 
    'TREASURER', 
    'SUPERINTENDENT'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE member_status_enum AS ENUM (
    'active', 
    'transferring', 
    'missing', 
    'censured', 
    'disfellowshipped', 
    'deceased', 
    'transferred', 
    'removed'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE gender_enum AS ENUM ('male', 'female', 'other');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- 2. Conferences Table
CREATE TABLE IF NOT EXISTS conferences (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  president_name VARCHAR(100) NOT NULL,
  president_email VARCHAR(100) NOT NULL,
  president_phone VARCHAR(50),
  headquarters_city VARCHAR(100),
  union_name VARCHAR(150) DEFAULT 'Southern Zambia Union Conference (SZUC)',
  address TEXT,
  phone VARCHAR(50),
  email VARCHAR(100),
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Districts Table
CREATE TABLE IF NOT EXISTS districts (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  conference_id VARCHAR(50) NOT NULL REFERENCES conferences(id) ON DELETE CASCADE,
  conference_name VARCHAR(150),
  pastor_name VARCHAR(100) NOT NULL,
  pastor_email VARCHAR(100) NOT NULL,
  pastor_phone VARCHAR(50),
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Churches Table (Local Church Stations & Companies)
CREATE TABLE IF NOT EXISTS churches (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  conference VARCHAR(100) NOT NULL,
  conference_id VARCHAR(50) REFERENCES conferences(id) ON DELETE SET NULL,
  district VARCHAR(100),
  district_id VARCHAR(50) REFERENCES districts(id) ON DELETE SET NULL,
  city VARCHAR(100),
  address TEXT,
  phone VARCHAR(50),
  email VARCHAR(100),
  elder_name VARCHAR(100),
  elder_email VARCHAR(100),
  pastor_id VARCHAR(50),
  pastor_name VARCHAR(100),
  is_demo BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. Users Table
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role role_enum NOT NULL,
  assigned_class VARCHAR(50),
  language VARCHAR(50),
  church_id VARCHAR(50) REFERENCES churches(id) ON DELETE SET NULL,
  church_name VARCHAR(100),
  district_id VARCHAR(50) REFERENCES districts(id) ON DELETE SET NULL,
  district_name VARCHAR(100),
  conference_id VARCHAR(50) REFERENCES conferences(id) ON DELETE SET NULL,
  conference_name VARCHAR(100),
  phone VARCHAR(50),
  title VARCHAR(150),
  status VARCHAR(20) DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 6. Sabbath School Classes Table
CREATE TABLE IF NOT EXISTS classes (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  teacher_id VARCHAR(50) REFERENCES users(id) ON DELETE SET NULL,
  language VARCHAR(50) DEFAULT 'English',
  church_id VARCHAR(50) REFERENCES churches(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 7. Church Members (Master Church Roll)
CREATE TABLE IF NOT EXISTS church_members (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  member_number VARCHAR(50),
  given_names VARCHAR(100),
  primary_surname VARCHAR(100),
  secondary_surname VARCHAR(100),
  church_id VARCHAR(50) NOT NULL REFERENCES churches(id) ON DELETE CASCADE,
  status member_status_enum NOT NULL DEFAULT 'active',
  baptism_date VARCHAR(50),
  dob VARCHAR(50),
  gender gender_enum,
  contact VARCHAR(50),
  email VARCHAR(100),
  address TEXT,
  family_unit_id VARCHAR(50),
  relationship_to_head VARCHAR(50),
  member_type VARCHAR(50) DEFAULT 'baptized',
  outreach_flag BOOLEAN DEFAULT FALSE,
  outreach_notes TEXT,
  last_attend_date VARCHAR(50),
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 8. Students Table (Class Attendance Roster)
CREATE TABLE IF NOT EXISTS students (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  class_id VARCHAR(50) NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  attendance_status VARCHAR(20) DEFAULT 'unmarked',
  lesson_studied BOOLEAN DEFAULT FALSE,
  is_transferring BOOLEAN DEFAULT FALSE,
  member_id VARCHAR(50) REFERENCES church_members(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 9. Family Units Table
CREATE TABLE IF NOT EXISTS family_units (
  id VARCHAR(50) PRIMARY KEY,
  church_id VARCHAR(50) NOT NULL REFERENCES churches(id) ON DELETE CASCADE,
  family_name VARCHAR(100) NOT NULL,
  primary_contact_id VARCHAR(50) NOT NULL,
  primary_contact_name VARCHAR(100),
  address TEXT NOT NULL,
  contact_phone VARCHAR(50) NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 10. Study Guide Orders Table
CREATE TABLE IF NOT EXISTS study_guide_orders (
  id VARCHAR(50) PRIMARY KEY,
  church_id VARCHAR(50) NOT NULL REFERENCES churches(id) ON DELETE CASCADE,
  order_number VARCHAR(50) NOT NULL,
  member_id VARCHAR(50),
  member_name VARCHAR(100) NOT NULL,
  member_contact VARCHAR(50),
  member_email VARCHAR(100),
  guide_type VARCHAR(100) NOT NULL,
  quarter VARCHAR(50) NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  unit_price NUMERIC(10,2) NOT NULL DEFAULT 0.00,
  total_amount NUMERIC(10,2) NOT NULL DEFAULT 0.00,
  payment_status VARCHAR(30) NOT NULL DEFAULT 'pending',
  payment_method VARCHAR(50) NOT NULL DEFAULT 'Cash',
  order_status VARCHAR(30) NOT NULL DEFAULT 'placed',
  order_date VARCHAR(50) NOT NULL,
  notes TEXT,
  distributed_date VARCHAR(50),
  abc_requisition_ref VARCHAR(100),
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 11. Announcements Table
CREATE TABLE IF NOT EXISTS announcements (
  id VARCHAR(50) PRIMARY KEY,
  teacher_id VARCHAR(50) REFERENCES users(id) ON DELETE SET NULL,
  teacher_name VARCHAR(100) NOT NULL,
  class_name VARCHAR(100) NOT NULL,
  content TEXT NOT NULL,
  timestamp TIMESTAMPTZ NOT NULL,
  status VARCHAR(20) DEFAULT 'pending'
);

-- 12. Attendance Records Table
CREATE TABLE IF NOT EXISTS attendance_records (
  id VARCHAR(50) PRIMARY KEY,
  date DATE NOT NULL,
  class_id VARCHAR(50) NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  class_name VARCHAR(100) NOT NULL,
  teacher_id VARCHAR(50),
  teacher_name VARCHAR(100) NOT NULL,
  total_students INT NOT NULL,
  present_count INT NOT NULL,
  absent_count INT NOT NULL,
  visitor_count INT NOT NULL,
  lesson_study_count INT DEFAULT 0,
  json_data JSONB,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 13. Generic Key-Value Store (Sacred Trust Remittances, Treasury, SS Council Plans)
CREATE TABLE IF NOT EXISTS generic_store (
  entity_key VARCHAR(50) PRIMARY KEY,
  data JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------
-- Composite Indexes for High Performance Querying
-- ----------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_users_role_church ON users(role, church_id);
CREATE INDEX IF NOT EXISTS idx_members_church_status ON church_members(church_id, status);
CREATE INDEX IF NOT EXISTS idx_attendance_class_date ON attendance_records(class_id, date);
CREATE INDEX IF NOT EXISTS idx_districts_conf ON districts(conference_id);
CREATE INDEX IF NOT EXISTS idx_churches_district ON churches(district_id);

-- ----------------------------------------------------------
-- Initial Seed Data: Hierarchical Demonstration Environment
-- ----------------------------------------------------------
INSERT INTO conferences (id, name, president_name, president_email, president_phone, headquarters_city, union_name, address, phone, email)
VALUES ('conf-lusaka', 'Lusaka Conference', 'Pastor Dr. Harrington Simpasa', 'president@conference.org', '+260 211 251234', 'Lusaka', 'Southern Zambia Union Conference (SZUC)', 'Plot 3025, Independence Avenue, Lusaka', '+260 211 251234', 'info@lusakaconference.org')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

INSERT INTO districts (id, name, conference_id, conference_name, pastor_name, pastor_email, pastor_phone)
VALUES 
('dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Pastor H. Chisenga', 'pastor@district.org', '+260 977 123456'),
('dist-central', 'Central Lusaka District', 'conf-lusaka', 'Lusaka Conference', 'Pastor Brian Mulenga', 'bmulenga@conference.org', '+260 971 889900')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

INSERT INTO churches (id, name, conference, conference_id, district, district_id, city, address, phone, email, elder_name, elder_email, is_demo)
VALUES 
('church-woodlands', 'Woodlands SDA Church', 'Lusaka Conference', 'conf-lusaka', 'Woodlands District', 'dist-woodlands', 'Lusaka', 'Woodlands Main Road, Lusaka, Zambia', '+260 211 254890', 'woodlands@church.org', 'Elder M. S. Banda', 'elder@church.org', true),
('church-libala', 'Libala SDA Church', 'Lusaka Conference', 'conf-lusaka', 'Central Lusaka District', 'dist-central', 'Lusaka', 'Libala South Grounds, Lusaka', '+260 211 289001', 'libala@church.org', 'Elder Joseph Phiri', 'jphiri@church.org', false)
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

INSERT INTO users (id, name, email, password, role, assigned_class, language, church_id, church_name, district_id, district_name, conference_id, conference_name, title, phone)
VALUES 
('superadmin-1', 'Elder Dr. Harrington Tembo', 'superadmin@sda.org', 'admin123', 'SUPER_ADMIN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'General Conference System Super Admin', '+260 977 000001'),
('pres-1', 'Pastor Dr. Harrington Simpasa', 'president@conference.org', 'president123', 'CONFERENCE_PRESIDENT', NULL, NULL, NULL, NULL, NULL, NULL, 'conf-lusaka', 'Lusaka Conference', 'Conference President (Territory Overseer)', '+260 211 251234'),
('pastor-1', 'Pastor H. Chisenga', 'pastor@district.org', 'pastor123', 'DISTRICT_PASTOR', NULL, NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'District Pastor (Pastoral Circuit Overseer)', '+260 977 123456'),
('elder-1', 'Elder M. S. Banda', 'elder@church.org', 'elder123', 'CHURCH_ADMIN', NULL, NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Church First Elder (Station Administrator)', '+260 977 111222'),
('clerk-1', 'Sister P. Tembo', 'clerk@church.org', 'clerk123', 'CLERK', NULL, NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Church Clerk (Secretariat)', '+260 978 222333'),
('treasurer-1', 'Elder Joseph Banda', 'treasurer@church.org', 'treasurer123', 'TREASURER', NULL, NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Church Treasurer (Sacred Trust)', '+260 977 444555'),
('superintendent-1', 'Sister R. Simpasa', 'superintendent@church.org', 'superintendent123', 'SUPERINTENDENT', NULL, NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Sabbath School Superintendent', '+260 977 666777'),
('t1', 'Elder Musonda', 'musonda@church.org', 'password123', 'TEACHER', 'c1', 'English', 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Adult Sabbath School Teacher', '+260 979 888999'),
('t2', 'Sister Chanda', 'chanda@church.org', 'password123', 'TEACHER', 'c2', NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Youth Ministry Teacher', '+260 971 222111'),
('t3', 'Brother Mwale', 'mwale@church.org', 'password123', 'TEACHER', 'c3', NULL, 'church-woodlands', 'Woodlands SDA Church', 'dist-woodlands', 'Woodlands District', 'conf-lusaka', 'Lusaka Conference', 'Primary Class Teacher', '+260 975 333222')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

INSERT INTO classes (id, name, teacher_id, language, church_id)
VALUES 
('c1', 'Adult Sabbath School', 't1', 'English', 'church-woodlands'),
('c2', 'Youth Ministry', 't2', NULL, 'church-woodlands'),
('c3', 'Primary Class', 't3', NULL, 'church-woodlands')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

INSERT INTO students (id, name, class_id, attendance_status, lesson_studied, is_transferring, member_id)
VALUES 
('s1', 'Alice Walker', 'c1', 'unmarked', false, false, 'mem-1'),
('s2', 'Robert Miller', 'c1', 'unmarked', false, false, 'mem-2'),
('s3', 'Sarah Jenkins', 'c2', 'unmarked', false, false, 'mem-3'),
('s4', 'Little Timmy', 'c3', 'unmarked', false, false, 'mem-4')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;
