import React, { useState, useEffect } from 'react';
import { 
  User, Announcement, AttendanceRecord, Class, Visitor, TransferRequest, TransferStatus,
  Student, ChurchMember, FamilyUnit, ChurchMeeting, ChurchOfficer 
} from '../types';
import { summarizeAnnouncements, generateAttendanceInsight } from '../services/geminiService';
import { ADULT_LANGUAGES } from '../constants';
import { 
  Users, Calendar, Megaphone, Plus, Search, 
  TrendingUp, Clock, Sparkles, X, ChevronRight, Book, Edit3, CalendarDays,
  Printer, FileDown, Globe, BookOpen, HeartHandshake, Phone, MapPin, MessageSquare,
  HandHelping, GraduationCap, UsersRound, BookMarked, CheckCircle, ShieldPlus, Settings,
  ArrowRightLeft, Send, Check, AlertCircle, User as UserIcon, Building2, Landmark, FileText, Home,
  Shield, ShieldCheck
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer
} from 'recharts';
import { FamilyUnitsView } from '../components/clerk/FamilyUnitsView';
import { TransfersPipelineView } from '../components/clerk/TransfersPipelineView';
import { GovernanceMeetingsView } from '../components/clerk/GovernanceMeetingsView';
import { DocumentGeneratorView } from '../components/clerk/DocumentGeneratorView';
import { ConferenceSyncView } from '../components/clerk/ConferenceSyncView';

interface ClerkDashboardProps {
  user: User;
  teachers: User[];
  classes: Class[];
  announcements: Announcement[];
  attendanceRecords: AttendanceRecord[];
  deleteStudent: (classId: string, studentId: string) => void;
  admins: User[];
  transferRequests: TransferRequest[];
  initiateTransfer: (studentId: string, studentName: string, toChurchId: string, toChurchName: string, reason?: string) => void;
  updateTransferStatus: (requestId: string, status: TransferRequest['status']) => void;
  updateTransferStage?: (requestId: string, status: TransferRequest['status'], extra?: Partial<TransferRequest>) => void;
  churchMembers: ChurchMember[];
  addChurchMember: (member: Omit<ChurchMember, 'id' | 'churchId'>) => void;
  updateChurchMember: (memberId: string, updates: Partial<ChurchMember>) => void;
  deleteChurchMember: (memberId: string) => void;
  familyUnits?: FamilyUnit[];
  addFamilyUnit?: (fam: Omit<FamilyUnit, 'id' | 'churchId'>) => void;
  updateFamilyUnit?: (id: string, updates: Partial<FamilyUnit>) => void;
  deleteFamilyUnit?: (id: string) => void;
  meetings?: ChurchMeeting[];
  addMeeting?: (m: Omit<ChurchMeeting, 'id' | 'churchId'>) => void;
  updateMeeting?: (id: string, updates: Partial<ChurchMeeting>) => void;
  deleteMeeting?: (id: string) => void;
  officers?: ChurchOfficer[];
  addOfficer?: (o: Omit<ChurchOfficer, 'id' | 'churchId'>) => void;
  updateOfficer?: (id: string, updates: Partial<ChurchOfficer>) => void;
  deleteOfficer?: (id: string) => void;
}

type ClerkTab = 'family_units' | 'transfers' | 'governance' | 'documents' | 'conference' | 'analytics' | 'staff';

const ClerkDashboard: React.FC<ClerkDashboardProps> = ({ 
  user, teachers, classes, announcements, attendanceRecords,
  deleteStudent, admins, transferRequests, initiateTransfer, updateTransferStatus,
  updateTransferStage, churchMembers, addChurchMember, updateChurchMember, deleteChurchMember,
  familyUnits = [], addFamilyUnit, updateFamilyUnit, deleteFamilyUnit,
  meetings = [], addMeeting, updateMeeting, deleteMeeting,
  officers = [], addOfficer, updateOfficer, deleteOfficer
}) => {
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);
  const [editedSummary, setEditedSummary] = useState<string>('');
  const [insight, setInsight] = useState<string | null>(null);
  const [activeViewClass, setActiveViewClass] = useState<Class | null>(null);
  const [isTransferring, setIsTransferring] = useState(false);
  const [selectedStudentForTransfer, setSelectedStudentForTransfer] = useState<Student | null>(null);
  const [targetChurchId, setTargetChurchId] = useState('');
  const [transferReason, setTransferReason] = useState('');
  const [activeTab, setActiveTab] = useState<ClerkTab>('family_units');
  const [selectedDocMember, setSelectedDocMember] = useState<ChurchMember | null>(null);
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [isAddingMember, setIsAddingMember] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberContact, setNewMemberContact] = useState('');
  const [newMemberAddress, setNewMemberAddress] = useState('');
  const [newMemberBaptismDate, setNewMemberBaptismDate] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  
  const currentChurchId = user.churchId || user.id;
  const isDemo = user.churchName === 'Woodlands SDA Church' || user.churchId === 'church-woodlands';
  const myClasses = classes.filter(c => c.churchId === currentChurchId || (isDemo && (c.churchId === 'admin-1' || c.churchId === 'admin-initial' || c.churchId === 'church-woodlands')));
  const myMembers = churchMembers.filter(m => m.churchId === currentChurchId || (isDemo && (m.churchId === 'admin-initial' || m.churchId === 'church-woodlands')));
  const myFamilyUnits = familyUnits.filter(f => f.churchId === currentChurchId || (isDemo && (f.churchId === 'admin-initial' || f.churchId === 'church-woodlands')));
  const myMeetings = meetings.filter(m => m.churchId === currentChurchId || (isDemo && (m.churchId === 'admin-initial' || m.churchId === 'church-woodlands')));
  const myOfficers = officers.filter(o => o.churchId === currentChurchId || (isDemo && (o.churchId === 'admin-initial' || o.churchId === 'church-woodlands')));

  const totalMembers = myClasses.reduce((acc, c) => acc + (c.students?.length || 0), 0);
  const todayRecords = attendanceRecords.filter(r => r.date === new Date().toISOString().split('T')[0] && myClasses.some(c => c.id === r.classId));
  
  const todayAttendanceCount = todayRecords.reduce((acc, r) => acc + r.presentCount, 0);
  const todayVisitorCount = todayRecords.reduce((acc, r) => acc + (r.visitorCount || 0), 0);
  const todayLessonCount = todayRecords.reduce((acc, r) => acc + (r.lessonStudyCount || 0), 0);
  
  const allTodayVisitors = todayRecords.flatMap(r => r.visitors || []);
  const lessonPercentage = todayAttendanceCount > 0 ? (todayLessonCount / todayAttendanceCount) * 100 : 0;

  const outreachSummary = todayRecords.reduce((acc, r) => {
    if (r.outreachReport) {
      acc.prospectiveMembersCount += r.outreachReport.prospectiveMembersCount || 0;
      acc.dailyStudyPlanCount += r.outreachReport.dailyStudyPlanCount || 0;
      acc.bibleStudiesGivenCount += r.outreachReport.bibleStudiesGivenCount || 0;
      acc.personalWitnessingCount += r.outreachReport.personalWitnessingCount || 0;
      acc.literatureGivenCount += r.outreachReport.literatureGivenCount || 0;
      acc.christianHelpValue += r.outreachReport.christianHelpValue || 0;
      acc.christianHelpHours += r.outreachReport.christianHelpHours || 0;
      acc.vopEnrolmentsCount += r.outreachReport.vopEnrolmentsCount || 0;
      acc.vopGraduationsCount += r.outreachReport.vopGraduationsCount || 0;
      acc.prospectiveMembersVisitedCount += r.outreachReport.prospectiveMembersVisitedCount || 0;
      acc.actionUnitProjectsCount += r.outreachReport.actionUnitProjectsCount || 0;
      acc.totalReportingCount += r.outreachReport.totalReportingCount || 0;
    }
    return acc;
  }, {
    prospectiveMembersCount: 0,
    dailyStudyPlanCount: 0,
    bibleStudiesGivenCount: 0,
    personalWitnessingCount: 0,
    literatureGivenCount: 0,
    christianHelpValue: 0,
    christianHelpHours: 0,
    vopEnrolmentsCount: 0,
    vopGraduationsCount: 0,
    prospectiveMembersVisitedCount: 0,
    actionUnitProjectsCount: 0,
    totalReportingCount: 0
  });

  useEffect(() => {
    if (todayRecords.length > 0) {
      const stats = {
        totalRecords: todayRecords.length,
        averageAttendance: todayRecords.reduce((acc, r) => acc + (r.presentCount / r.totalStudents), 0) / todayRecords.length,
        lessonParticipation: lessonPercentage,
        visitorEngagement: todayVisitorCount
      };
      generateAttendanceInsight(stats).then(setInsight);
    }
  }, [todayRecords, lessonPercentage, todayVisitorCount]);

  const handleSummarize = async () => {
    setIsSummarizing(true);
    const result = await summarizeAnnouncements(announcements.filter(a => myClasses.some(c => c.id === a.teacherId || c.name === a.className))); // Rough filter
    setSummary(result);
    setEditedSummary(result || '');
    setIsSummarizing(false);
  };

  const handleDownload = () => {
    if (!editedSummary) return;
    const element = document.createElement("a");
    const file = new Blob([editedSummary], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `SDA_Report_${new Date().toISOString().split('T')[0]}.txt`;
    element.click();
  };

  const handleInitiateTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentForTransfer || !targetChurchId) return;
    
    const targetChurch = admins.find(a => a.id === targetChurchId);
    if (!targetChurch) return;

    initiateTransfer(
      selectedStudentForTransfer.id, 
      selectedStudentForTransfer.name, 
      targetChurch.id, 
      targetChurch.churchName || 'Unknown Church',
      transferReason
    );
    
    setIsTransferring(false);
    setSelectedStudentForTransfer(null);
    setTargetChurchId('');
    setTransferReason('');
  };

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    addChurchMember({
      name: newMemberName,
      contact: newMemberContact,
      address: newMemberAddress,
      baptismDate: newMemberBaptismDate,
      status: 'active'
    });
    setNewMemberName('');
    setNewMemberContact('');
    setNewMemberAddress('');
    setNewMemberBaptismDate('');
    setIsAddingMember(false);
  };

  const filteredMembers = myMembers.filter(m => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.contact?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const incomingTransfers = transferRequests.filter(r => r.toChurchId === user.id);
  const outgoingTransfers = transferRequests.filter(r => r.fromChurchId === user.id);

  const chartData = myClasses.reduce((acc, c) => {
    const baseName = c.name.split(' (')[0];
    const record = todayRecords.find(r => r.classId === c.id);
    
    const existing = acc.find(item => item.name === baseName);
    if (existing) {
      existing.present += record?.presentCount || 0;
      existing.visitors += record?.visitorCount || 0;
      existing.lessons += record?.lessonStudyCount || 0;
    } else {
      acc.push({
        name: baseName,
        present: record?.presentCount || 0,
        visitors: record?.visitorCount || 0,
        lessons: record?.lessonStudyCount || 0
      });
    }
    return acc;
  }, [] as { name: string; present: number; visitors: number; lessons: number }[]).map(item => ({
    ...item,
    name: item.name.substring(0, 15)
  }));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
      <header className="mb-8 sm:mb-10 flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-6 sm:p-10 rounded-[2rem] shadow-sm border border-slate-100">
        <div className="flex items-center gap-4">
          <div className="p-3 sm:p-4 bg-blue-900 rounded-2xl shadow-md">
            <CalendarDays className="w-8 h-8 text-amber-400" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-gray-900 tracking-tighter uppercase leading-none">Clerk's Registry</h1>
            <p className="text-slate-500 font-bold text-xs sm:text-sm mt-2 flex items-center gap-2">Conference Management Portal</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2.5 bg-blue-50 border border-blue-200 text-blue-950 px-5 py-3.5 rounded-2xl text-xs font-black uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4 text-blue-700" />
            <span>Church Secretariat & Rolls</span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8 sm:mb-10">
        <StatCard 
          title="Total Church Roll" 
          value={myMembers.length.toString()} 
          icon={<Users className="text-blue-600" />} 
          subtitle={`${myMembers.filter(m => m.status === 'active').length} Active Members`} 
        />
        <StatCard 
          title="Family Units (FUR)" 
          value={myFamilyUnits.length.toString()} 
          icon={<Home className="text-indigo-600" />} 
          subtitle="Households Recorded" 
        />
        <StatCard 
          title="Active Transfers" 
          value={transferRequests.filter(r => r.status !== 'approved' && r.status !== 'rejected').length.toString()} 
          icon={<ArrowRightLeft className="text-purple-600" />} 
          subtitle="4-Stage Pipeline" 
        />
        <StatCard 
          title="Today's Presence" 
          value={(todayAttendanceCount + todayVisitorCount).toString()} 
          icon={<Calendar className="text-emerald-600" />} 
          subtitle={`${todayAttendanceCount} Mem + ${todayVisitorCount} Vis`} 
        />
      </div>

      <div className="flex overflow-x-auto pb-2 gap-3 mb-8 no-scrollbar">
        <button 
          onClick={() => setActiveTab('family_units')}
          className={`px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-wider transition-all whitespace-nowrap flex items-center gap-2 ${activeTab === 'family_units' ? 'bg-blue-900 text-white shadow-lg shadow-blue-900/15' : 'bg-white text-slate-500 border border-slate-100 hover:bg-slate-50'}`}
        >
          <Home className="w-4 h-4" /> Family Units & Members
        </button>
        <button 
          onClick={() => setActiveTab('transfers')}
          className={`px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-wider transition-all whitespace-nowrap flex items-center gap-2 ${activeTab === 'transfers' ? 'bg-blue-900 text-white shadow-lg shadow-blue-900/15' : 'bg-white text-slate-500 border border-slate-100 hover:bg-slate-50'}`}
        >
          <ArrowRightLeft className="w-4 h-4" /> Transfer Pipeline
          {transferRequests.some(r => r.status !== 'approved' && r.status !== 'rejected') && (
            <span className="w-2 h-2 bg-amber-400 rounded-full inline-block" />
          )}
        </button>
        <button 
          onClick={() => setActiveTab('governance')}
          className={`px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-wider transition-all whitespace-nowrap flex items-center gap-2 ${activeTab === 'governance' ? 'bg-blue-900 text-white shadow-lg shadow-blue-900/15' : 'bg-white text-slate-500 border border-slate-100 hover:bg-slate-50'}`}
        >
          <Landmark className="w-4 h-4" /> Board & Minutes
        </button>
        <button 
          onClick={() => setActiveTab('documents')}
          className={`px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-wider transition-all whitespace-nowrap flex items-center gap-2 ${activeTab === 'documents' ? 'bg-blue-900 text-white shadow-lg shadow-blue-900/15' : 'bg-white text-slate-500 border border-slate-100 hover:bg-slate-50'}`}
        >
          <FileText className="w-4 h-4" /> Official Documents
        </button>
        <button 
          onClick={() => setActiveTab('conference')}
          className={`px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-wider transition-all whitespace-nowrap flex items-center gap-2 ${activeTab === 'conference' ? 'bg-blue-900 text-white shadow-lg shadow-blue-900/15' : 'bg-white text-slate-500 border border-slate-100 hover:bg-slate-50'}`}
        >
          <Building2 className="w-4 h-4" /> Conference & Directory
        </button>
        <button 
          onClick={() => setActiveTab('analytics')}
          className={`px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-wider transition-all whitespace-nowrap flex items-center gap-2 ${activeTab === 'analytics' ? 'bg-blue-900 text-white shadow-lg shadow-blue-900/15' : 'bg-white text-slate-500 border border-slate-100 hover:bg-slate-50'}`}
        >
          <TrendingUp className="w-4 h-4" /> Sabbath School Analytics
        </button>
        <button 
          onClick={() => setActiveTab('staff')}
          className={`px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-wider transition-all whitespace-nowrap flex items-center gap-2 ${activeTab === 'staff' ? 'bg-blue-900 text-white shadow-lg shadow-blue-900/15' : 'bg-white text-slate-500 border border-slate-100 hover:bg-slate-50'}`}
        >
          <ShieldPlus className="w-4 h-4" /> Staff Credentials
        </button>
      </div>

      {activeTab === 'analytics' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-[2rem] p-6 sm:p-10 border border-slate-100 shadow-sm">
            <h3 className="text-xl font-black flex items-center gap-2 text-slate-900 uppercase tracking-tighter mb-8">
              <TrendingUp className="w-6 h-6 text-blue-600" /> Session Analytics
            </h3>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#0f172a', fontSize: 10, fontWeight: '900'}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 10, fontWeight: 'bold'}} />
                  <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '16px', border: 'none'}} />
                  <Bar dataKey="present" fill="#1e3a8a" radius={[6, 6, 0, 0]} name="Members" />
                  <Bar dataKey="visitors" fill="#f59e0b" radius={[6, 6, 0, 0]} name="Visitors" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            {insight && (
              <div className="mt-8 p-6 bg-slate-50 rounded-2xl border border-slate-100 flex gap-4 items-start">
                <Sparkles className="w-6 h-6 text-blue-500 shrink-0" />
                <div className="text-sm text-slate-800 font-bold leading-relaxed italic">{insight}</div>
              </div>
            )}
          </div>

          <div className="bg-white rounded-[2rem] p-6 sm:p-10 border border-slate-100 shadow-sm">
            <h3 className="text-xl font-black flex items-center gap-3 text-slate-900 uppercase tracking-tighter mb-8">
              <HeartHandshake className="w-6 h-6 text-amber-500" /> Sabbath Guest List
            </h3>
            <div className="space-y-4">
              {allTodayVisitors.length === 0 ? (
                <div className="py-10 text-center border-2 border-dashed border-slate-50 rounded-3xl">
                  <p className="text-slate-300 font-black text-xs uppercase tracking-widest">No visitors reported today</p>
                </div>
              ) : allTodayVisitors.map(visitor => {
                const visitorClass = myClasses.find(c => c.id === visitor.classId);
                return (
                  <div key={visitor.id} className="p-5 bg-amber-50/20 border-2 border-amber-100 rounded-3xl">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <span className="font-black text-slate-900 text-lg block leading-none">{visitor.name}</span>
                        <span className="text-[9px] font-black text-amber-700 uppercase tracking-[0.2em] mt-1 block">Class: {visitorClass?.name}</span>
                      </div>
                      <div className="px-3 py-1 bg-amber-500 text-white rounded-lg text-[9px] font-black uppercase tracking-widest">Visitor</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-white rounded-[2rem] p-6 sm:p-10 border border-slate-100 shadow-sm">
            <h3 className="text-xl font-black flex items-center gap-3 text-slate-900 uppercase tracking-tighter mb-8">
              <TrendingUp className="w-6 h-6 text-blue-600" /> Outreach & Witnessing Summary
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              <SummaryItem label="Prospective" value={outreachSummary.prospectiveMembersCount} icon={<UsersRound className="w-4 h-4 text-blue-500" />} />
              <SummaryItem label="Daily Study" value={outreachSummary.dailyStudyPlanCount} icon={<BookMarked className="w-4 h-4 text-emerald-500" />} />
              <SummaryItem label="Bible Studies" value={outreachSummary.bibleStudiesGivenCount} icon={<BookOpen className="w-4 h-4 text-amber-500" />} />
              <SummaryItem label="Witnessing (W)" value={outreachSummary.personalWitnessingCount} icon={<MessageSquare className="w-4 h-4 text-purple-500" />} />
              <SummaryItem label="Literature (I)" value={outreachSummary.literatureGivenCount} icon={<Plus className="w-4 h-4 text-rose-500" />} />
              <SummaryItem label="Help Value (T)" value={`$${outreachSummary.christianHelpValue}`} icon={<HandHelping className="w-4 h-4 text-emerald-600" />} />
              <SummaryItem label="Help Hours (N)" value={outreachSummary.christianHelpHours} icon={<Clock className="w-4 h-4 text-blue-600" />} />
              <SummaryItem label="VOP Enrol (E)" value={outreachSummary.vopEnrolmentsCount} icon={<Plus className="w-4 h-4 text-amber-600" />} />
              <SummaryItem label="VOP Grad (S)" value={outreachSummary.vopGraduationsCount} icon={<GraduationCap className="w-4 h-4 text-purple-600" />} />
              <SummaryItem label="Visited (I)" value={outreachSummary.prospectiveMembersVisitedCount} icon={<MapPin className="w-4 h-4 text-rose-600" />} />
              <SummaryItem label="Projects (N)" value={outreachSummary.actionUnitProjectsCount} icon={<Plus className="w-4 h-4 text-blue-500" />} />
              <SummaryItem label="Reporting (G)" value={outreachSummary.totalReportingCount} icon={<CheckCircle className="w-4 h-4 text-emerald-500" />} />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-[2rem] p-6 sm:p-10 border border-slate-100 shadow-sm flex flex-col">
          <h3 className="text-xl font-black mb-8 flex items-center gap-2 text-slate-900 uppercase tracking-tighter">
            <Book className="w-6 h-6 text-slate-400" /> Registry Books
          </h3>
          <div className="space-y-4 overflow-y-auto max-h-[800px] pr-2 custom-scrollbar">
            {myClasses.length === 0 ? (
              <p className="text-slate-400 text-xs font-black uppercase text-center py-10">No Classes Available</p>
            ) : myClasses
                .filter((c, idx, arr) => {
                  if (c.name.toLowerCase().includes('adult')) {
                    return idx === arr.findIndex(other => other.name.toLowerCase().includes('adult'));
                  }
                  return true;
                })
                .map(c => {
              const teacher = teachers.find(t => t.id === c.teacherId);
              const todayRecord = todayRecords.find(r => r.classId === c.id);
              return (
                <div key={c.id} onClick={() => setActiveViewClass(c)} className="p-5 rounded-2xl border border-slate-50 bg-slate-50/50 hover:bg-white hover:border-blue-200 cursor-pointer transition-all group shadow-sm">
                  <div className="flex items-center justify-between mb-3">
                    <p className="font-black text-slate-950 uppercase text-sm tracking-tight">{c.name}</p>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-500 transition-all transform group-hover:translate-x-1" />
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <span className="text-[8px] font-black bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md uppercase">{todayRecord?.presentCount || 0} Members</span>
                    <span className="text-[8px] font-black bg-amber-100 text-amber-800 px-2 py-0.5 rounded-md uppercase">{todayRecord?.visitorCount || 0} Guests</span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-black uppercase mt-3">{teacher ? `By: ${teacher.name}` : 'No Teacher Assigned'}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      ) : null}

      {activeTab === 'family_units' && (
        <FamilyUnitsView
          members={myMembers}
          familyUnits={myFamilyUnits}
          onAddMember={addChurchMember}
          onUpdateMember={updateChurchMember}
          onDeleteMember={deleteChurchMember}
          onAddFamilyUnit={addFamilyUnit || (() => {})}
          onUpdateFamilyUnit={updateFamilyUnit || (() => {})}
          onDeleteFamilyUnit={deleteFamilyUnit || (() => {})}
          onOpenOutreachLetter={(member: ChurchMember) => {
            setSelectedDocMember(member);
            setActiveTab('documents');
          }}
        />
      )}

      {activeTab === 'transfers' && (
        <TransfersPipelineView
          requests={transferRequests}
          currentChurchUser={user}
          allChurches={admins.filter(a => a.id !== user.id)}
          members={myMembers}
          onInitiateTransfer={(transferData) => {
            initiateTransfer(
              transferData.studentId || `MEMBER-${Date.now()}`,
              transferData.studentName,
              transferData.toChurchId,
              transferData.toChurchName || 'Unknown Church',
              transferData.reason
            );
          }}
          onUpdateTransferStage={(reqId: string, stage: TransferStatus, metadata) => {
            if (updateTransferStage) {
              updateTransferStage(reqId, stage, metadata);
            } else {
              updateTransferStatus(reqId, stage);
            }
          }}
          onRejectTransfer={(id: string) => {
            updateTransferStatus(id, 'rejected');
          }}
        />
      )}

      {activeTab === 'governance' && (
        <GovernanceMeetingsView
          meetings={myMeetings}
          officers={myOfficers}
          onAddMeeting={addMeeting || (() => {})}
          onUpdateMeeting={updateMeeting || (() => {})}
          onDeleteMeeting={deleteMeeting || (() => {})}
          onAddOfficer={addOfficer || (() => {})}
          onUpdateOfficer={updateOfficer || (() => {})}
          onDeleteOfficer={deleteOfficer || (() => {})}
        />
      )}

      {activeTab === 'documents' && (
        <DocumentGeneratorView
          members={myMembers}
          currentChurchUser={user}
          preselectedMember={selectedDocMember}
        />
      )}

      {activeTab === 'conference' && (
        <ConferenceSyncView
          members={myMembers}
          familyUnits={myFamilyUnits}
          transfers={transferRequests}
          currentChurchUser={user}
        />
      )}

      {activeTab === 'staff' && (
        <div className="bg-white rounded-[2rem] p-6 sm:p-10 border border-slate-100 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
            <div>
              <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                <ShieldPlus className="w-8 h-8 text-blue-600" /> Authorized Staff & Credentials
              </h3>
              <p className="text-slate-400 font-bold text-xs mt-2 uppercase tracking-widest">
                Database registry of teacher emails, assigned classes, and security keys
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <button 
                onClick={() => {
                  const staffRows = [
                    ['Teacher Name', 'Email Address', 'Password', 'Assigned Class', 'Language'].join(','),
                    ...teachers.filter(t => myClasses.some(c => c.id === t.assignedClass)).map(t => {
                      const c = myClasses.find(cls => cls.id === t.assignedClass);
                      return `"${t.name}","${t.email}","${t.password || ''}","${c?.name || 'Unassigned'}","${t.language || 'English'}"`;
                    })
                  ].join('\n');
                  const blob = new Blob([staffRows], { type: 'text/csv' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `staff_credentials_${new Date().toISOString().split('T')[0]}.csv`;
                  a.click();
                }}
                className="flex items-center gap-2 bg-slate-100 text-slate-700 px-5 py-4 rounded-xl hover:bg-slate-200 transition-all font-black text-[10px] uppercase tracking-widest"
              >
                <FileDown className="w-4 h-4" /> Export Credentials CSV
              </button>
              <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-900 px-4 py-3 rounded-xl text-xs font-bold">
                <Shield className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Teacher Appointments & Portal Access: Sabbath School Superintendent & Council Authority</span>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-separate border-spacing-y-4">
              <thead>
                <tr className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                  <th className="px-6 pb-2">Teacher Name</th>
                  <th className="px-6 pb-2">Email / Username</th>
                  <th className="px-6 pb-2">Database Security Key</th>
                  <th className="px-6 pb-2">Assigned Class</th>
                  <th className="px-6 pb-2 text-right">Portal Status</th>
                </tr>
              </thead>
              <tbody>
                {teachers.filter(t => myClasses.some(c => c.id === t.assignedClass)).map(teacher => {
                  const assignedClass = myClasses.find(c => c.id === teacher.assignedClass);
                  const isShowing = showPasswords[teacher.id];
                  
                  return (
                    <tr key={teacher.id} className="bg-slate-50/50 hover:bg-white border border-slate-100 transition-all group">
                      <td className="px-6 py-5 rounded-l-2xl border-y border-l border-slate-100">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600 font-black text-xs">
                            {teacher.name.charAt(0)}
                          </div>
                          <div>
                            <p className="font-black text-slate-900 text-sm">{teacher.name}</p>
                            {teacher.language && (
                              <p className="text-[9px] text-amber-600 font-bold uppercase tracking-wider">{teacher.language}</p>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-5 border-y border-slate-100">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-700 font-mono">{teacher.email}</span>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(teacher.email);
                              setShowPasswords(prev => ({ ...prev, [`email-${teacher.id}`]: true }));
                              setTimeout(() => setShowPasswords(prev => ({ ...prev, [`email-${teacher.id}`]: false })), 2000);
                            }}
                            className="p-1 text-slate-300 hover:text-blue-600 rounded transition-colors text-[9px] font-bold"
                            title="Copy email"
                          >
                            {showPasswords[`email-${teacher.id}`] ? 'Copied!' : 'Copy'}
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-5 border-y border-slate-100">
                        <div className="flex items-center gap-2">
                          <code className="bg-white px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-mono font-bold text-blue-900">
                            {isShowing ? teacher.password : '••••••••'}
                          </code>
                          <button 
                            onClick={() => setShowPasswords(prev => ({ ...prev, [teacher.id]: !isShowing }))}
                            className="p-2 hover:bg-white rounded-lg transition-all text-slate-400 hover:text-blue-600"
                            title={isShowing ? "Hide Password" : "Show Password"}
                          >
                            {isShowing ? <X className="w-4 h-4" /> : <Settings className="w-4 h-4" />}
                          </button>
                          <button
                            onClick={() => {
                              if (teacher.password) {
                                navigator.clipboard.writeText(teacher.password);
                                setShowPasswords(prev => ({ ...prev, [`pwd-${teacher.id}`]: true }));
                                setTimeout(() => setShowPasswords(prev => ({ ...prev, [`pwd-${teacher.id}`]: false })), 2000);
                              }
                            }}
                            className="p-1 text-slate-300 hover:text-blue-600 rounded transition-colors text-[9px] font-bold"
                            title="Copy password"
                          >
                            {showPasswords[`pwd-${teacher.id}`] ? 'Copied!' : 'Copy'}
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-5 border-y border-slate-100">
                        <span className="px-3 py-1 bg-blue-50 text-blue-700 rounded-lg text-[10px] font-black uppercase tracking-widest">
                          {assignedClass?.name || 'Unassigned'}
                        </span>
                      </td>
                      <td className="px-6 py-5 rounded-r-2xl border-y border-r border-slate-100 text-right">
                        <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-lg text-[10px] font-black uppercase tracking-wider">
                          <CheckCircle className="w-3 h-3" /> Active
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {isAddingMember && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xl z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-[3rem] p-10 sm:p-12 max-w-2xl w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-3xl font-black text-slate-950 tracking-tighter uppercase">Add Church Member</h2>
              <button onClick={() => setIsAddingMember(false)} className="p-3 hover:bg-slate-100 rounded-full transition-all border border-slate-100 active:scale-90"><X className="w-8 h-8 text-slate-950" /></button>
            </div>
            
            <form onSubmit={handleAddMember} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
                  <input type="text" required value={newMemberName} onChange={(e) => setNewMemberName(e.target.value)} className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-200 rounded-2xl outline-none focus:border-blue-900 transition-all font-black text-slate-900 placeholder:text-slate-400 text-lg" placeholder="Member Name..." />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Contact Number</label>
                  <input type="text" value={newMemberContact} onChange={(e) => setNewMemberContact(e.target.value)} className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-200 rounded-2xl outline-none focus:border-blue-900 transition-all font-black text-slate-900 placeholder:text-slate-400 text-lg" placeholder="Phone..." />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Home Address</label>
                <input type="text" value={newMemberAddress} onChange={(e) => setNewMemberAddress(e.target.value)} className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-200 rounded-2xl outline-none focus:border-blue-900 transition-all font-black text-slate-900 placeholder:text-slate-400 text-lg" placeholder="Residential Address..." />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Baptism Date</label>
                <input type="date" value={newMemberBaptismDate} onChange={(e) => setNewMemberBaptismDate(e.target.value)} className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-200 rounded-2xl outline-none focus:border-blue-900 transition-all font-black text-slate-900 text-lg" />
              </div>
              
              <div className="mt-12 flex gap-4">
                <button type="button" onClick={() => setIsAddingMember(false)} className="flex-1 py-5 bg-slate-100 text-slate-950 rounded-2xl font-black uppercase tracking-widest text-sm">Cancel</button>
                <button type="submit" className="flex-1 py-5 bg-blue-900 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-black transition-all shadow-2xl border-b-8 border-blue-950 text-sm">Register Member</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {activeViewClass && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xl z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-[3rem] p-8 sm:p-10 max-w-4xl w-full shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-3xl font-black text-slate-950 tracking-tighter uppercase leading-none">{activeViewClass.name}</h2>
                <p className="text-slate-400 font-black text-[10px] uppercase tracking-[0.3em] mt-2">Registry Book Details</p>
              </div>
              <button onClick={() => setActiveViewClass(null)} className="p-3 hover:bg-slate-100 rounded-full transition-all border border-slate-100 active:scale-90"><X className="w-8 h-8 text-slate-950" /></button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Assigned Teacher</h4>
                    <span className="text-[9px] font-bold text-slate-400">Read-Only</span>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-900 rounded-xl flex items-center justify-center text-white font-black text-xl">
                      {teachers.find(t => t.id === activeViewClass.teacherId)?.name.charAt(0) || '?'}
                    </div>
                    <div>
                      <p className="font-black text-slate-900">{teachers.find(t => t.id === activeViewClass.teacherId)?.name || 'No Teacher Assigned'}</p>
                      <p className="text-[10px] text-slate-400 font-bold">{teachers.find(t => t.id === activeViewClass.teacherId)?.email || 'N/A'}</p>
                      {activeViewClass.language && (
                        <span className="inline-block mt-2 px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-[8px] font-black uppercase tracking-widest">{activeViewClass.language} Hub</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="bg-blue-950 rounded-3xl p-6 text-white border-4 border-blue-900">
                  <h4 className="text-[9px] font-black text-amber-400 uppercase tracking-[0.3em] mb-4">Class Statistics</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-blue-900/50 rounded-2xl border border-blue-800">
                      <p className="text-[8px] font-black text-blue-300 uppercase tracking-widest mb-1">Total Members</p>
                      <p className="text-2xl font-black">{activeViewClass.students.length}</p>
                    </div>
                    <div className="p-4 bg-blue-900/50 rounded-2xl border border-blue-800">
                      <p className="text-[8px] font-black text-blue-300 uppercase tracking-widest mb-1">Registry Status</p>
                      <p className="text-sm font-black text-emerald-400 uppercase">Active</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Users className="w-4 h-4" /> Member Registry
                </h4>
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                  {activeViewClass.students.length === 0 ? (
                    <p className="text-center py-10 text-slate-300 font-black text-[10px] uppercase tracking-widest bg-slate-50 rounded-3xl border-2 border-dashed border-slate-100">No members registered</p>
                  ) : activeViewClass.students.map(student => (
                    <div key={student.id} className="p-4 bg-white border border-slate-100 rounded-2xl flex items-center justify-between group hover:border-blue-200 transition-all">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center text-slate-400 font-black text-xs">
                          {student.name.charAt(0)}
                        </div>
                        <span className="font-bold text-slate-900 text-sm">{student.name}</span>
                      </div>
                      <button 
                        onClick={() => {
                          if (confirm(`Are you sure you want to remove ${student.name} from the registry?`)) {
                            deleteStudent(activeViewClass.id, student.id);
                            // Update local state to reflect deletion immediately in the modal
                            setActiveViewClass(prev => prev ? {
                              ...prev,
                              students: prev.students.filter(s => s.id !== student.id)
                            } : null);
                          }
                        }}
                        className="p-2 text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                        title="Remove Member"
                      >
                        <X className="w-4 h-4" />
                      </button>
                      {!student.isTransferring && (
                        <button 
                          onClick={() => {
                            setSelectedStudentForTransfer(student);
                            setIsTransferring(true);
                          }}
                          className="p-2 text-slate-300 hover:text-blue-500 transition-colors opacity-0 group-hover:opacity-100"
                          title="Initiate Transfer"
                        >
                          <ArrowRightLeft className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {isTransferring && selectedStudentForTransfer && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xl z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-[3rem] p-10 max-w-md w-full shadow-2xl border-8 border-white animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-3xl font-black text-slate-950 tracking-tighter uppercase">Transfer Member</h2>
              <button onClick={() => setIsTransferring(false)} className="p-3 hover:bg-slate-100 rounded-full transition-all border border-slate-100"><X className="w-8 h-8 text-slate-950" /></button>
            </div>
            
            <div className="mb-8 p-6 bg-blue-50 rounded-3xl border border-blue-100">
              <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-2">Member to Transfer</p>
              <p className="text-xl font-black text-blue-900">{selectedStudentForTransfer.name}</p>
            </div>

            <form onSubmit={handleInitiateTransfer} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Select Destination Church</label>
                <select 
                  required 
                  value={targetChurchId} 
                  onChange={(e) => setTargetChurchId(e.target.value)}
                  className="w-full px-6 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-8 focus:ring-blue-50 focus:border-blue-900 transition-all font-black text-slate-900 outline-none"
                >
                  <option value="">Select a church...</option>
                  {admins.filter(a => a.id !== user.id).map(admin => (
                    <option key={admin.id} value={admin.id}>{admin.churchName}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Reason for Transfer</label>
                <textarea 
                  required 
                  value={transferReason} 
                  onChange={(e) => setTransferReason(e.target.value)}
                  placeholder="e.g. Relocation, Marriage, etc."
                  className="w-full px-6 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-8 focus:ring-blue-50 focus:border-blue-900 transition-all font-bold text-slate-900 outline-none resize-none"
                  rows={3}
                />
              </div>
              
              <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 flex gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
                <p className="text-[10px] font-bold text-amber-800 leading-relaxed">
                  This will send a formal request to the receiving clerk. The member will remain in your registry until the transfer is approved after two readings.
                </p>
              </div>

              <button type="submit" className="w-full py-5 bg-blue-900 text-white rounded-2xl font-black shadow-xl border-b-8 border-blue-950 uppercase tracking-widest text-xs hover:bg-black transition-all active:scale-95">
                Send Transfer Request
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode; subtitle?: string }> = ({ title, value, icon, subtitle }) => (
  <div className="bg-white p-10 rounded-[2.5rem] border-2 border-slate-50 shadow-sm relative overflow-hidden group hover:border-blue-200 transition-all duration-500">
    <div className="flex justify-between items-start mb-8 relative z-10">
      <div className="p-5 bg-slate-50 rounded-[1.5rem] group-hover:bg-white group-hover:shadow-xl transition-all border border-slate-100">{icon}</div>
      {subtitle && <span className="text-[9px] font-black text-amber-700 bg-amber-50 px-4 py-1.5 rounded-full border border-amber-100 uppercase tracking-widest">{subtitle}</span>}
    </div>
    <h4 className="text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] mb-2">{title}</h4>
    <p className="text-5xl font-black text-slate-950 tracking-tighter">{value}</p>
  </div>
);

const SummaryItem: React.FC<{ label: string; value: string | number; icon: React.ReactNode }> = ({ label, value, icon }) => (
  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col items-center text-center">
    <div className="mb-2">{icon}</div>
    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</span>
    <span className="text-xl font-black text-slate-900">{value}</span>
  </div>
);

export default ClerkDashboard;