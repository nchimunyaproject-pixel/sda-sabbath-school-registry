import React, { useState, useEffect } from 'react';
import { User, Class, Announcement, AttendanceRecord, Student, Visitor, OutreachReport, ChurchMember } from '../types';
import { 
  CheckCircle, Users, Megaphone, AlertCircle, Plus, 
  UserPlus, Settings, X, Save, CalendarDays, Globe, BookOpen, 
  UserCheck, HeartHandshake, Phone, MapPin, MessageSquare, Loader2,
  TrendingUp, HandHelping, GraduationCap, UsersRound, BookMarked, Clock,
  Search
} from 'lucide-react';

interface TeacherDashboardProps {
  user: User;
  churchClass?: Class; // Made optional to handle initial sync states
  submitAnnouncement: (ann: Announcement) => void;
  submitAttendance: (rec: AttendanceRecord) => void;
  addStudent: (classId: string, studentName: string, memberId?: string) => void;
  updatePassword: (teacherId: string, newPassword: string) => void;
  churchMembers: ChurchMember[];
}

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ 
  user, churchClass, submitAnnouncement, submitAttendance, addStudent, updatePassword, churchMembers
}) => {
  const [students, setStudents] = useState<Student[]>(churchClass?.students || []);
  const [visitors, setVisitors] = useState<Visitor[]>([]);
  const [announcementText, setAnnouncementText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  
  const [isAddingStudent, setIsAddingStudent] = useState(false);
  const [isAddingVisitor, setIsAddingVisitor] = useState(false);
  const [newStudentName, setNewStudentName] = useState('');
  const [memberSearchTerm, setMemberSearchTerm] = useState('');
  const [selectedMemberId, setSelectedMemberId] = useState<string | null>(null);
  
  const [newVisitorName, setNewVisitorName] = useState('');
  const [newVisitorContact, setNewVisitorContact] = useState('');
  const [newVisitorLocation, setNewVisitorLocation] = useState('');
  const [newVisitorPurpose, setNewVisitorPurpose] = useState('');

  const [outreachReport, setOutreachReport] = useState<OutreachReport>({
    prospectiveMembersCount: 0,
    dailyStudyPlanCount: 0,
    bibleStudiesGivenCount: 0,
    personalWitnessingCount: 0,
    literatureGivenCount: 0,
    christianHelpValue: 0,
    christianHelpHours: 0,
    vopEnrolmentsCount: 0,
    vopGraduationsCount: 0,
    prospectiveMembersVisitedCount: 0,
    actionUnitProjectsCount: 0,
    totalReportingCount: 0
  });

  // Update local students list whenever the churchClass prop updates
  useEffect(() => {
    if (churchClass?.students) {
      setStudents(churchClass.students);
    }
  }, [churchClass]);

  if (!churchClass) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 text-center">
        <div className="p-6 bg-white rounded-[3rem] shadow-xl border border-slate-100 animate-bounce mb-8">
          <Loader2 className="w-12 h-12 text-blue-900 animate-spin" />
        </div>
        <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tighter">Synchronizing Class...</h2>
        <p className="text-slate-500 font-bold mt-2 max-w-xs mx-auto">Please wait while we retrieve your registry from the conference database.</p>
      </div>
    );
  }

  const markAttendance = (studentId: string, status: 'present' | 'absent') => {
    setStudents(prev => prev.map(s => s.id === studentId ? { ...s, attendanceStatus: status } : s));
  };

  const toggleLessonStudy = (studentId: string) => {
    setStudents(prev => prev.map(s => s.id === studentId ? { ...s, lessonStudied: !s.lessonStudied } : s));
  };

  const addVisitor = () => {
    if (!newVisitorName.trim()) return;
    const guest: Visitor = {
      id: `v-${Date.now()}`,
      name: newVisitorName,
      classId: churchClass.id,
      contact: newVisitorContact,
      location: newVisitorLocation,
      purpose: newVisitorPurpose
    };
    setVisitors(prev => [...prev, guest]);
    setNewVisitorName('');
    setNewVisitorContact('');
    setNewVisitorLocation('');
    setNewVisitorPurpose('');
    setIsAddingVisitor(false);
  };

  const removeVisitor = (id: string) => {
    setVisitors(prev => prev.filter(v => v.id !== id));
  };

  const regularPresent = students.filter(s => s.attendanceStatus === 'present').length;
  const guestCount = visitors.length;
  const grandTotal = regularPresent + guestCount;

  const handleAttendanceSubmit = () => {
    const presentCount = regularPresent;
    const lessonCount = students.filter(s => s.lessonStudied).length;
    
    submitAttendance({
      id: `att-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      classId: churchClass.id,
      className: churchClass.name,
      teacherId: user.id,
      teacherName: user.name,
      totalStudents: students.length,
      presentCount: presentCount,
      absentCount: students.filter(s => s.attendanceStatus === 'absent').length,
      visitorCount: guestCount,
      lessonStudyCount: lessonCount,
      records: [...students],
      visitors: [...visitors],
      outreachReport: { ...outreachReport }
    });
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const handleAnnouncementSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcementText.trim()) return;
    
    setIsSubmitting(true);
    submitAnnouncement({
      id: `ann-${Date.now()}`,
      teacherId: user.id,
      teacherName: user.name,
      className: churchClass.name,
      content: announcementText,
      timestamp: new Date().toISOString(),
      status: 'pending'
    });
    setAnnouncementText('');
    setIsSubmitting(false);
  };

  const filteredMasterMembers = churchMembers.filter(m => 
    m.status === 'active' &&
    m.name.toLowerCase().includes(memberSearchTerm.toLowerCase()) &&
    !students.some(s => s.memberId === m.id) // Don't show members already in this class
  );

  const handleAddMemberFromRegister = (member: ChurchMember) => {
    if (!churchClass) return;
    addStudent(churchClass.id, member.name, member.id);
    setIsAddingStudent(false);
    setMemberSearchTerm('');
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
      <div className="mb-8 grid grid-cols-1 md:grid-cols-3 gap-4 bg-blue-950 rounded-[2.5rem] p-8 shadow-2xl border-4 border-blue-900 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-32 -mt-32 blur-3xl pointer-events-none" />
        <div className="flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-blue-800 pb-4 md:pb-0">
          <span className="text-[10px] font-black text-blue-300 uppercase tracking-[0.3em] mb-1">Members Present</span>
          <span className="text-4xl font-black text-white leading-none">{regularPresent}</span>
        </div>
        <div className="flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-blue-800 py-4 md:py-0">
          <span className="text-[10px] font-black text-amber-400 uppercase tracking-[0.3em] mb-1">Today's Visitors</span>
          <span className="text-4xl font-black text-white leading-none">{guestCount}</span>
        </div>
        <div className="flex flex-col items-center justify-center pt-4 md:pt-0">
          <span className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.3em] mb-1">Grand Total</span>
          <span className="text-4xl font-black text-white leading-none">{grandTotal}</span>
        </div>
      </div>

      <header className="mb-6 sm:mb-8 flex flex-col sm:row sm:items-center justify-between gap-6 bg-white p-6 sm:p-10 rounded-[2rem] shadow-sm border border-slate-100">
        <div className="flex items-center gap-5">
          <div className="p-3.5 bg-blue-900 rounded-2xl shadow-lg flex items-center justify-center">
            <CalendarDays className="w-8 h-8 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 leading-none tracking-tight">Sabbath Portal</h1>
              {churchClass.language && (
                <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-700 rounded-lg border border-amber-200">
                  <Globe className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-black uppercase tracking-widest">{churchClass.language}</span>
                </div>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <span className="bg-blue-50 text-blue-700 text-[9px] font-black px-3 py-1.5 rounded-lg border border-blue-100 uppercase tracking-widest">{churchClass.name}</span>
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          <button onClick={() => setIsAddingStudent(true)} className="flex-grow sm:flex-none flex items-center justify-center gap-2 bg-blue-900 text-white px-8 py-4 rounded-2xl hover:bg-black transition-all font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-900/10 active:scale-95 border-b-4 border-blue-950">
            <UserPlus className="w-4 h-4" /> Add Member
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <section className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-[2.5rem] p-6 sm:p-10 shadow-sm border border-slate-100">
            <div className="flex justify-between items-center mb-10 pb-6 border-b border-slate-50">
              <h2 className="text-xl font-black flex items-center gap-3 text-slate-900 tracking-tighter uppercase">
                <UserCheck className="w-6 h-6 text-emerald-600" /> Class Members
              </h2>
            </div>

            <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2 custom-scrollbar">
              {students.length === 0 ? (
                <div className="text-center py-12 border-4 border-dashed border-slate-50 rounded-[2.5rem] bg-slate-50/20">
                  <p className="text-slate-300 font-black text-[10px] uppercase tracking-[0.4em]">Class Registry Empty</p>
                </div>
              ) : students.map(student => (
                <div 
                  key={student.id}
                  className={`p-5 rounded-3xl border-2 transition-all flex flex-col sm:flex-row items-center justify-between gap-5 group ${
                    student.attendanceStatus === 'present' ? 'border-emerald-600 bg-emerald-50/40' : 
                    student.attendanceStatus === 'absent' ? 'border-rose-600 bg-rose-50/40' : 'border-slate-50 bg-slate-50/30'
                  }`}
                >
                  <div className="flex items-center gap-5 w-full sm:w-auto">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg border-4 transition-all ${
                      student.attendanceStatus === 'present' ? 'bg-emerald-600 text-white border-emerald-400 rotate-2' : 
                      student.attendanceStatus === 'absent' ? 'bg-rose-600 text-white border-rose-400 -rotate-2' : 'bg-white text-slate-200 border-slate-50'
                    }`}>
                      {student.name.charAt(0)}
                    </div>
                    <div>
                      <span className="font-black text-lg text-slate-950 block leading-none tracking-tight">{student.name}</span>
                      <button 
                        onClick={() => toggleLessonStudy(student.id)}
                        className={`flex items-center gap-1.5 mt-1 transition-all ${student.lessonStudied ? 'text-amber-600' : 'text-slate-300 hover:text-amber-400'}`}
                      >
                        <BookOpen className={`w-3.5 h-3.5 ${student.lessonStudied ? 'fill-amber-500' : ''}`} />
                        <span className="text-[9px] font-black uppercase tracking-widest">
                          {student.lessonStudied ? 'Lesson Studied' : 'Mark Lesson'}
                        </span>
                      </button>
                    </div>
                  </div>

                  <div className="flex gap-2 w-full sm:w-auto">
                    <button onClick={() => markAttendance(student.id, 'present')} className={`flex-1 sm:flex-none px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest border-b-4 ${student.attendanceStatus === 'present' ? 'bg-emerald-700 text-white border-emerald-900' : 'bg-white text-slate-400 border-slate-100'}`}>Present</button>
                    <button onClick={() => markAttendance(student.id, 'absent')} className={`flex-1 sm:flex-none px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest border-b-4 ${student.attendanceStatus === 'absent' ? 'bg-rose-700 text-white border-rose-900' : 'bg-white text-slate-400 border-slate-100'}`}>Absent</button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-[2.5rem] p-6 sm:p-10 shadow-sm border border-slate-100">
            <div className="flex justify-between items-center mb-10 pb-6 border-b border-slate-50">
              <h2 className="text-xl font-black flex items-center gap-3 text-slate-900 tracking-tighter uppercase">
                <TrendingUp className="w-6 h-6 text-blue-600" /> Outreach & Witnessing
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <OutreachInput 
                label="Prospective Members" 
                value={outreachReport.prospectiveMembersCount} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, prospectiveMembersCount: v }))}
                icon={<UsersRound className="w-4 h-4" />}
              />
              <OutreachInput 
                label="Daily Study Plan" 
                value={outreachReport.dailyStudyPlanCount} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, dailyStudyPlanCount: v }))}
                icon={<BookMarked className="w-4 h-4" />}
              />
              <OutreachInput 
                label="Bible Studies Given" 
                value={outreachReport.bibleStudiesGivenCount} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, bibleStudiesGivenCount: v }))}
                icon={<BookOpen className="w-4 h-4" />}
              />
              <OutreachInput 
                label="(W) Personal Witnessing" 
                value={outreachReport.personalWitnessingCount} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, personalWitnessingCount: v }))}
                icon={<MessageSquare className="w-4 h-4" />}
              />
              <OutreachInput 
                label="(I) Literature Given" 
                value={outreachReport.literatureGivenCount} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, literatureGivenCount: v }))}
                icon={<Plus className="w-4 h-4" />}
              />
              <OutreachInput 
                label="(T) Christian Help (Value)" 
                value={outreachReport.christianHelpValue} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, christianHelpValue: v }))}
                icon={<HandHelping className="w-4 h-4" />}
                placeholder="Cash value..."
              />
              <OutreachInput 
                label="(N) Christian Help (Hours)" 
                value={outreachReport.christianHelpHours} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, christianHelpHours: v }))}
                icon={<Clock className="w-4 h-4" />}
                placeholder="Hours..."
              />
              <OutreachInput 
                label="(E) VOP Enrolments" 
                value={outreachReport.vopEnrolmentsCount} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, vopEnrolmentsCount: v }))}
                icon={<Plus className="w-4 h-4" />}
              />
              <OutreachInput 
                label="(S) VOP Graduation" 
                value={outreachReport.vopGraduationsCount} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, vopGraduationsCount: v }))}
                icon={<GraduationCap className="w-4 h-4" />}
              />
              <OutreachInput 
                label="(I) Prospective Visited" 
                value={outreachReport.prospectiveMembersVisitedCount} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, prospectiveMembersVisitedCount: v }))}
                icon={<MapPin className="w-4 h-4" />}
              />
              <OutreachInput 
                label="(N) Action Unit Projects" 
                value={outreachReport.actionUnitProjectsCount} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, actionUnitProjectsCount: v }))}
                icon={<Plus className="w-4 h-4" />}
              />
              <OutreachInput 
                label="(G) Total Reporting" 
                value={outreachReport.totalReportingCount} 
                onChange={(v) => setOutreachReport(prev => ({ ...prev, totalReportingCount: v }))}
                icon={<CheckCircle className="w-4 h-4" />}
              />
            </div>
          </div>

          <div className="bg-white rounded-[2.5rem] p-6 sm:p-10 shadow-sm border border-slate-100">
            <div className="flex justify-between items-center mb-8 pb-6 border-b border-slate-50">
              <h2 className="text-xl font-black flex items-center gap-3 text-slate-900 tracking-tighter uppercase">
                <HeartHandshake className="w-6 h-6 text-amber-500" /> Sabbath Visitors
              </h2>
              <button 
                onClick={() => setIsAddingVisitor(true)}
                className="flex items-center gap-2 px-6 py-3 bg-amber-50 text-amber-700 rounded-xl border border-amber-200 font-black text-[10px] uppercase tracking-widest hover:bg-amber-100 transition-all active:scale-95"
              >
                <Plus className="w-4 h-4" /> Add Visitor
              </button>
            </div>

            <div className="space-y-4">
              {visitors.length === 0 ? (
                <div className="text-center py-10 bg-slate-50/50 border-2 border-dashed border-slate-100 rounded-3xl">
                  <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest">No visitors recorded today</p>
                </div>
              ) : visitors.map(visitor => (
                <div key={visitor.id} className="p-6 bg-amber-50/30 border-2 border-amber-100 rounded-[2rem] group relative">
                  <button onClick={() => removeVisitor(visitor.id)} className="absolute top-4 right-4 p-2 text-slate-300 hover:text-rose-500 transition-colors">
                    <X className="w-5 h-5" />
                  </button>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-6">
                    <div className="w-14 h-14 bg-amber-500 rounded-2xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-amber-500/20">
                      {visitor.name.charAt(0)}
                    </div>
                    <div className="flex-grow">
                      <h4 className="font-black text-slate-900 text-xl tracking-tight leading-none mb-3">{visitor.name}</h4>
                      <div className="flex flex-wrap gap-x-6 gap-y-2">
                        {visitor.contact && (
                          <div className="flex items-center gap-2 text-slate-500">
                            <Phone className="w-3.5 h-3.5 text-amber-600" />
                            <span className="text-xs font-bold">{visitor.contact}</span>
                          </div>
                        )}
                        {visitor.location && (
                          <div className="flex items-center gap-2 text-slate-500">
                            <MapPin className="w-3.5 h-3.5 text-amber-600" />
                            <span className="text-xs font-bold">{visitor.location}</span>
                          </div>
                        )}
                        {visitor.purpose && (
                          <div className="flex items-center gap-2 text-slate-500">
                            <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
                            <span className="text-xs font-bold italic">{visitor.purpose}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button onClick={handleAttendanceSubmit} className="w-full py-6 bg-blue-900 text-white rounded-[2rem] font-black text-xl hover:bg-black shadow-2xl transition-all uppercase tracking-[0.2em] flex items-center justify-center gap-4 border-b-8 border-blue-950 active:scale-95">
            <Save className="w-6 h-6" /> Close Today's Registry
          </button>
        </section>

        <div className="space-y-8">
          <section className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-100">
            <h2 className="text-lg font-black flex items-center gap-3 mb-6 text-purple-900 tracking-tighter uppercase">
              <Megaphone className="w-6 h-6" /> Class Report
            </h2>
            <form onSubmit={handleAnnouncementSubmit} className="space-y-5">
              <textarea
                value={announcementText} onChange={(e) => setAnnouncementText(e.target.value)}
                placeholder="Any special happenings or visitor stories to share?"
                rows={5}
                className="w-full p-6 bg-slate-50 border border-slate-100 rounded-3xl focus:ring-8 focus:ring-purple-50 focus:border-purple-600 focus:bg-white outline-none transition-all text-slate-900 font-bold resize-none placeholder:text-slate-300 shadow-inner"
              />
              <button type="submit" disabled={!announcementText.trim() || isSubmitting} className="w-full py-4.5 bg-purple-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-purple-900 disabled:opacity-50 transition-all border-b-4 border-purple-950">Submit Report</button>
            </form>
          </section>

          <div className="bg-blue-950 rounded-[2.5rem] p-10 text-white shadow-2xl border-4 border-blue-900">
            <h3 className="text-[9px] font-black text-amber-400 flex items-center gap-2 mb-4 uppercase tracking-[0.4em]"><AlertCircle className="w-4 h-4" /> Steward's Tip</h3>
            <p className="text-xs text-blue-50 leading-loose font-bold italic opacity-90 tracking-wide">
              "When visitors enter the courts of the Lord, our registry serves as the first hand of fellowship. Record their details with love."
            </p>
          </div>
        </div>
      </div>

      {isAddingVisitor && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xl z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-[3rem] p-8 sm:p-10 max-w-xl w-full shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-black text-slate-950 tracking-tighter uppercase">New Visitor Profile</h2>
              <button onClick={() => setIsAddingVisitor(false)} className="p-3 hover:bg-slate-100 rounded-full transition-all border border-slate-100"><X className="w-6 h-6 text-slate-950" /></button>
            </div>
            <div className="space-y-5">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Guest Name</label>
                <input 
                  type="text" value={newVisitorName} onChange={(e) => setNewVisitorName(e.target.value)}
                  className="w-full px-6 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-amber-50 focus:border-amber-500 transition-all font-bold text-slate-900 placeholder:text-slate-400 outline-none" 
                  placeholder="Enter full name..." autoFocus 
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Contact Number</label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                    <input 
                      type="text" value={newVisitorContact} onChange={(e) => setNewVisitorContact(e.target.value)}
                      className="w-full pl-11 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-amber-50 focus:border-amber-500 transition-all font-bold text-slate-900 placeholder:text-slate-400 outline-none" 
                      placeholder="Phone or Email" 
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Place of Origin</label>
                  <div className="relative">
                    <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                    <input 
                      type="text" value={newVisitorLocation} onChange={(e) => setNewVisitorLocation(e.target.value)}
                      className="w-full pl-11 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-amber-50 focus:border-amber-500 transition-all font-bold text-slate-900 placeholder:text-slate-400 outline-none" 
                      placeholder="Home Church/City" 
                    />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Purpose for Visit</label>
                <textarea 
                  value={newVisitorPurpose} onChange={(e) => setNewVisitorPurpose(e.target.value)}
                  className="w-full px-6 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-amber-50 focus:border-amber-500 transition-all font-bold text-slate-900 placeholder:text-slate-400 outline-none resize-none" 
                  placeholder="e.g. Just moved, visiting family, interested in SDA..." 
                  rows={2}
                />
              </div>
              <button onClick={addVisitor} className="w-full py-5 bg-amber-500 text-white rounded-2xl font-black shadow-xl border-b-8 border-amber-600 uppercase tracking-widest text-xs hover:bg-amber-600 transition-all active:scale-95 mt-4">
                Register Visitor
              </button>
            </div>
          </div>
        </div>
      )}

      {isAddingStudent && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xl z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-[3rem] p-10 max-w-xl w-full shadow-2xl border-8 border-white animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-black text-slate-950 tracking-tighter uppercase leading-none">Add from Register</h2>
              <button onClick={() => setIsAddingStudent(false)} className="p-3 hover:bg-slate-100 rounded-full transition-all border border-slate-100"><X className="w-8 h-8 text-slate-950" /></button>
            </div>

            <div className="space-y-6">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                <input 
                  type="text" 
                  value={memberSearchTerm} 
                  onChange={(e) => setMemberSearchTerm(e.target.value)} 
                  className="w-full pl-12 pr-6 py-5 bg-slate-50 border-4 border-slate-100 rounded-3xl focus:ring-8 focus:ring-blue-50 focus:border-blue-900 transition-all font-black text-xl text-slate-900 placeholder:text-slate-400 outline-none" 
                  placeholder="Search Master Register..." 
                  autoFocus 
                />
              </div>

              <div className="max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar space-y-3">
                {filteredMasterMembers.length === 0 ? (
                  <div className="text-center py-10 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-100">
                    <p className="text-slate-400 font-black text-[10px] uppercase tracking-widest">
                      {memberSearchTerm ? 'No matching members found' : 'Type to search church register'}
                    </p>
                  </div>
                ) : (
                  filteredMasterMembers.map(member => (
                    <button 
                      key={member.id}
                      onClick={() => handleAddMemberFromRegister(member)}
                      className="w-full p-5 bg-white border-2 border-slate-50 rounded-2xl flex items-center justify-between hover:border-blue-200 hover:shadow-md transition-all group"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-blue-900 font-black">
                          {member.name.charAt(0)}
                        </div>
                        <div className="text-left">
                          <p className="font-black text-slate-900 leading-none">{member.name}</p>
                          <p className="text-[10px] text-slate-400 font-bold mt-1">{member.contact || 'No contact info'}</p>
                        </div>
                      </div>
                      <Plus className="w-5 h-5 text-slate-200 group-hover:text-blue-600 transition-colors" />
                    </button>
                  ))
                )}
              </div>

              <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 flex gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
                <p className="text-[10px] font-bold text-amber-800 leading-relaxed">
                  Only members registered by the Church Clerk can be added to the class registry. If a member is missing, please contact the Clerk.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface OutreachInputProps {
  label: string;
  value: number;
  onChange: (val: number) => void;
  icon: React.ReactNode;
  placeholder?: string;
}

const OutreachInput: React.FC<OutreachInputProps> = ({ label, value, onChange, icon, placeholder }) => (
  <div className="space-y-2">
    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-2">
      {icon} {label}
    </label>
    <input 
      type="number" 
      value={value || ''} 
      onChange={(e) => onChange(parseInt(e.target.value) || 0)}
      className="w-full px-5 py-3 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-500 transition-all font-bold text-slate-900 placeholder:text-slate-300 outline-none" 
      placeholder={placeholder || "0"}
      min="0"
    />
  </div>
);

export default TeacherDashboard;