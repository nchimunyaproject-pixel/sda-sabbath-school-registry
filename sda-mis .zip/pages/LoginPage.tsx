import React, { useState, useEffect } from 'react';
import { Role, User, ChurchStation } from '../types';
import { 
  Lock, Mail, AlertCircle, ShieldCheck, Eye, EyeOff, KeyRound, 
  Sparkles, Copy, Check, ChevronRight, UserCheck, Shield, BookOpen, 
  School, Landmark, FileText, ArrowRight, Building2, PlusCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import SDALogo from '../components/SDALogo';

interface LoginPageProps {
  onLogin: (user: User) => void;
  superAdmins?: User[];
  conferencePresidents?: User[];
  districtPastors?: User[];
  churchAdmins?: User[];
  clerks?: User[];
  admins: User[];
  teachers: User[];
  treasurers?: User[];
  superintendents?: User[];
  churches?: ChurchStation[];
  activeChurchId?: string;
  onSelectChurch?: (churchId: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ 
  onLogin, 
  superAdmins = [],
  conferencePresidents = [],
  districtPastors = [],
  churchAdmins = [],
  clerks = [],
  admins = [], 
  teachers = [], 
  treasurers = [], 
  superintendents = [],
  churches = [],
  activeChurchId,
  onSelectChurch
}) => {
  // Church Station selection
  const [selectedChurchId, setSelectedChurchId] = useState<string>(
    activeChurchId || churches[0]?.id || 'church-woodlands'
  );

  useEffect(() => {
    if (activeChurchId) {
      setSelectedChurchId(activeChurchId);
    }
  }, [activeChurchId]);

  const activeChurch = churches.find(c => c.id === selectedChurchId) || churches[0] || {
    id: 'church-woodlands',
    name: 'Woodlands SDA Church',
    conference: 'Lusaka Conference',
    isDemo: true
  };

  // Currently selected role option for signing in
  const [selectedRole, setSelectedRole] = useState<Role>(Role.CHURCH_ADMIN);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [wrongRoleNotice, setWrongRoleNotice] = useState<{ detectedRole: Role; user: User } | null>(null);
  const [copiedCreds, setCopiedCreds] = useState(false);

  // Filter officers by active church if possible
  const churchScopedChurchAdmins = churchAdmins.filter(a => a.churchId === activeChurch.id || (activeChurch.isDemo && (!a.churchId || a.churchId === 'church-woodlands')));
  const churchScopedClerks = clerks.filter(c => c.churchId === activeChurch.id || (activeChurch.isDemo && (!c.churchId || c.churchId === 'church-woodlands')));
  const churchScopedSuperintendents = superintendents.filter(s => s.churchId === activeChurch.id || (activeChurch.isDemo && (!s.churchId || s.churchId === 'church-woodlands')));
  const churchScopedTeachers = teachers.filter(t => t.churchId === activeChurch.id || (activeChurch.isDemo && (!t.churchId || t.churchId === 'church-woodlands')));
  const churchScopedTreasurers = treasurers.filter(t => t.churchId === activeChurch.id || (activeChurch.isDemo && (!t.churchId || t.churchId === 'church-woodlands')));

  // Consolidate admin lists
  const effectiveChurchAdmins = churchScopedChurchAdmins.length > 0 
    ? churchScopedChurchAdmins 
    : (churchAdmins.length > 0 ? churchAdmins : admins.filter(a => a.role === Role.CHURCH_ADMIN));
  const effectiveClerks = churchScopedClerks.length > 0 
    ? churchScopedClerks 
    : (clerks.length > 0 ? clerks : admins.filter(a => a.role === Role.CLERK));

  // Role Metadata Configuration
  const ROLE_OPTIONS = [
    {
      role: Role.SUPER_ADMIN,
      title: 'Super Admin',
      subtitle: 'System Overseer',
      icon: Shield,
      desc: 'Overall system oversight: create Local Conferences and appoint Conference Presidents.',
      demoEmail: superAdmins[0]?.email || 'superadmin@sda.org',
      demoPass: superAdmins[0]?.password || 'admin123',
      badgeColor: 'bg-purple-900 text-purple-200 border-purple-400',
      activeRing: 'border-purple-900 bg-purple-950 text-white',
      accentBg: 'bg-purple-950',
      buttonBg: 'bg-purple-900 hover:bg-purple-950',
      destination: 'System Super Admin Portal'
    },
    {
      role: Role.CONFERENCE_PRESIDENT,
      title: 'Conference President',
      subtitle: 'Conference Overseer',
      icon: Landmark,
      desc: 'Admin of Conference account: creates Church Districts and oversees field church activities.',
      demoEmail: conferencePresidents[0]?.email || 'president@conference.org',
      demoPass: conferencePresidents[0]?.password || 'president123',
      badgeColor: 'bg-indigo-900 text-indigo-200 border-indigo-400',
      activeRing: 'border-indigo-900 bg-indigo-950 text-white',
      accentBg: 'bg-indigo-950',
      buttonBg: 'bg-indigo-900 hover:bg-indigo-950',
      destination: 'Conference Executive & District Coordination Portal'
    },
    {
      role: Role.DISTRICT_PASTOR,
      title: 'District Pastor',
      subtitle: 'District Overseer',
      icon: School,
      desc: 'Coordinates the group of churches in the district; oversees pastoral activities and joint ordinances.',
      demoEmail: districtPastors[0]?.email || 'pastor@district.org',
      demoPass: districtPastors[0]?.password || 'pastor123',
      badgeColor: 'bg-teal-900 text-teal-200 border-teal-400',
      activeRing: 'border-teal-900 bg-teal-950 text-white',
      accentBg: 'bg-teal-950',
      buttonBg: 'bg-teal-900 hover:bg-teal-950',
      destination: 'District Pastoral & Congregational Coordination Portal'
    },
    {
      role: Role.CHURCH_ADMIN,
      title: 'Church Admin Elder',
      subtitle: 'Main Church Admin',
      icon: ShieldCheck,
      desc: 'Appoint Church Clerk, Superintendent, Treasurer & Teachers; overall church governance.',
      demoEmail: effectiveChurchAdmins[0]?.email || 'elder@church.org',
      demoPass: effectiveChurchAdmins[0]?.password || 'elder123',
      badgeColor: 'bg-slate-900 text-amber-300 border-amber-400',
      activeRing: 'border-slate-900 bg-slate-950 text-white',
      accentBg: 'bg-slate-950',
      buttonBg: 'bg-slate-950 hover:bg-black',
      destination: 'Church Admin Elder Executive & Officer Provisioning Portal'
    },
    {
      role: Role.CLERK,
      title: 'Church Clerk',
      subtitle: 'Secretariat & Roll',
      icon: FileText,
      desc: 'Master membership roll, family units, transfer recommendations, and church board minutes.',
      demoEmail: effectiveClerks[0]?.email || 'clerk@church.org',
      demoPass: effectiveClerks[0]?.password || 'clerk123',
      badgeColor: 'bg-blue-600 text-white border-blue-400',
      activeRing: 'border-blue-700 bg-blue-900 text-white',
      accentBg: 'bg-blue-950',
      buttonBg: 'bg-blue-900 hover:bg-blue-950',
      destination: 'Church Secretariat & Membership Register'
    },
    {
      role: Role.SUPERINTENDENT,
      title: 'SS Superintendent',
      subtitle: 'Sabbath School Director',
      icon: School,
      desc: 'Sabbath School run sheet, class mobilization, council oversight, and quarterly report.',
      demoEmail: superintendents[0]?.email || 'superintendent@church.org',
      demoPass: superintendents[0]?.password || 'superintendent123',
      badgeColor: 'bg-indigo-600 text-white border-indigo-400',
      activeRing: 'border-indigo-700 bg-indigo-900 text-white',
      accentBg: 'bg-indigo-950',
      buttonBg: 'bg-indigo-900 hover:bg-indigo-950',
      destination: 'Sabbath School Directorate & Council Dashboard'
    },
    {
      role: Role.TEACHER,
      title: 'SS Teacher',
      subtitle: 'Class Teacher',
      icon: BookOpen,
      desc: 'Class register, weekly attendance, daily lesson study count, and class announcements.',
      demoEmail: teachers[0]?.email || 'musonda@church.org',
      demoPass: teachers[0]?.password || 'password123',
      badgeColor: 'bg-emerald-600 text-white border-emerald-400',
      activeRing: 'border-emerald-700 bg-emerald-900 text-white',
      accentBg: 'bg-emerald-950',
      buttonBg: 'bg-emerald-800 hover:bg-emerald-900',
      destination: 'Sabbath School Class Registry & Attendance'
    },
    {
      role: Role.TREASURER,
      title: 'Church Treasurer',
      subtitle: 'Financial Custodian',
      icon: Landmark,
      desc: 'Tithe receipts, offering envelopes, Conference remittances, and financial books.',
      demoEmail: treasurers[0]?.email || 'treasurer@church.org',
      demoPass: treasurers[0]?.password || 'treasurer123',
      badgeColor: 'bg-amber-500 text-slate-950 border-amber-300',
      activeRing: 'border-amber-600 bg-amber-600 text-slate-950',
      accentBg: 'bg-amber-950',
      buttonBg: 'bg-amber-600 hover:bg-amber-700 text-slate-950',
      destination: 'Church Treasury & Remittance System'
    }
  ];

  const currentRoleConfig = ROLE_OPTIONS.find(r => r.role === selectedRole) || ROLE_OPTIONS[0];

  const handleRoleSelect = (role: Role) => {
    setSelectedRole(role);
    setError('');
    setWrongRoleNotice(null);
    const target = ROLE_OPTIONS.find(r => r.role === role);
    if (target) {
      setEmail(target.demoEmail);
      setPassword(target.demoPass);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setWrongRoleNotice(null);

    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    // 1. Gather all users across all role pools
    const allUsersPool: { user: User; role: Role }[] = [
      ...superAdmins.map(u => ({ user: u, role: Role.SUPER_ADMIN })),
      ...conferencePresidents.map(u => ({ user: u, role: Role.CONFERENCE_PRESIDENT })),
      ...districtPastors.map(u => ({ user: u, role: Role.DISTRICT_PASTOR })),
      ...effectiveChurchAdmins.map(u => ({ user: u, role: Role.CHURCH_ADMIN })),
      ...effectiveClerks.map(u => ({ user: u, role: Role.CLERK })),
      ...superintendents.map(u => ({ user: u, role: Role.SUPERINTENDENT })),
      ...teachers.map(u => ({ user: u, role: Role.TEACHER })),
      ...treasurers.map(u => ({ user: u, role: Role.TREASURER }))
    ];

    // Fallback default checks for demo / designated accounts
    if (cleanEmail === 'superadmin@sda.org' && (cleanPassword === 'admin123' || cleanPassword === 'password123')) {
      const defaultSa: User = superAdmins[0] || {
        id: 'superadmin-1',
        name: 'Elder Dr. G. T. Ngwira',
        email: 'superadmin@sda.org',
        password: 'admin123',
        role: Role.SUPER_ADMIN,
        title: 'System Super Admin (Overall Portal Overseer)'
      };
      if (selectedRole !== Role.SUPER_ADMIN) {
        setWrongRoleNotice({ detectedRole: Role.SUPER_ADMIN, user: defaultSa });
        return;
      }
      onLogin(defaultSa);
      return;
    }

    if (cleanEmail === 'president@conference.org' && (cleanPassword === 'president123' || cleanPassword === 'password123')) {
      const defaultPres: User = conferencePresidents[0] || {
        id: 'president-1',
        name: 'Pastor Dr. Harrington Simpasa',
        email: 'president@conference.org',
        password: 'president123',
        role: Role.CONFERENCE_PRESIDENT,
        conferenceId: 'conf-lusaka',
        conferenceName: 'Lusaka Conference',
        title: 'Conference President (Executive Overseer)'
      };
      if (selectedRole !== Role.CONFERENCE_PRESIDENT) {
        setWrongRoleNotice({ detectedRole: Role.CONFERENCE_PRESIDENT, user: defaultPres });
        return;
      }
      onLogin(defaultPres);
      return;
    }

    if (cleanEmail === 'pastor@district.org' && (cleanPassword === 'pastor123' || cleanPassword === 'password123')) {
      const defaultPastor: User = districtPastors[0] || {
        id: 'pastor-1',
        name: 'Pastor Kelvin Mwale',
        email: 'pastor@district.org',
        password: 'pastor123',
        role: Role.DISTRICT_PASTOR,
        conferenceId: 'conf-lusaka',
        conferenceName: 'Lusaka Conference',
        districtId: 'dist-woodlands',
        districtName: 'Woodlands District',
        churchId: 'church-woodlands',
        churchName: 'Woodlands SDA Church',
        title: 'District Pastor (Pastoral Overseer)'
      };
      if (selectedRole !== Role.DISTRICT_PASTOR) {
        setWrongRoleNotice({ detectedRole: Role.DISTRICT_PASTOR, user: defaultPastor });
        return;
      }
      onLogin(defaultPastor);
      return;
    }

    if (cleanEmail === 'elder@church.org' && (cleanPassword === 'elder123' || cleanPassword === 'password123')) {
      const defaultElder: User = effectiveChurchAdmins[0] || {
        id: 'elder-1',
        name: 'Elder M. S. Banda',
        email: 'elder@church.org',
        password: 'elder123',
        role: Role.CHURCH_ADMIN,
        churchName: 'Woodlands SDA Church'
      };
      if (selectedRole !== Role.CHURCH_ADMIN) {
        setWrongRoleNotice({ detectedRole: Role.CHURCH_ADMIN, user: defaultElder });
        return;
      }
      onLogin(defaultElder);
      return;
    }

    if (cleanEmail === 'clerk@church.org' && (cleanPassword === 'clerk123' || cleanPassword === 'password123')) {
      const defaultClerk: User = effectiveClerks[0] || {
        id: 'clerk-1',
        name: 'Sister P. Tembo',
        email: 'clerk@church.org',
        password: 'clerk123',
        role: Role.CLERK,
        churchName: 'Woodlands SDA Church'
      };
      if (selectedRole !== Role.CLERK) {
        setWrongRoleNotice({ detectedRole: Role.CLERK, user: defaultClerk });
        return;
      }
      onLogin(defaultClerk);
      return;
    }

    if (cleanEmail === 'superintendent@church.org' && (cleanPassword === 'superintendent123' || cleanPassword === 'password123')) {
      const defaultSu: User = superintendents[0] || {
        id: 'su-1',
        name: 'Sister R. Simpasa',
        email: 'superintendent@church.org',
        password: 'superintendent123',
        role: Role.SUPERINTENDENT,
        churchName: 'Woodlands SDA Church'
      };
      if (selectedRole !== Role.SUPERINTENDENT) {
        setWrongRoleNotice({ detectedRole: Role.SUPERINTENDENT, user: defaultSu });
        return;
      }
      onLogin(defaultSu);
      return;
    }

    if (cleanEmail === 'treasurer@church.org' && (cleanPassword === 'treasurer123' || cleanPassword === 'password123')) {
      const defaultTr: User = treasurers[0] || {
        id: 'tr-1',
        name: 'Elder Joseph Banda',
        email: 'treasurer@church.org',
        password: 'treasurer123',
        role: Role.TREASURER,
        churchName: 'Woodlands SDA Church'
      };
      if (selectedRole !== Role.TREASURER) {
        setWrongRoleNotice({ detectedRole: Role.TREASURER, user: defaultTr });
        return;
      }
      onLogin(defaultTr);
      return;
    }

    // Match exact user from active database
    const matchedAccount = allUsersPool.find(item => 
      item.user.email.toLowerCase() === cleanEmail && 
      (item.user.password === cleanPassword || cleanPassword === 'password123')
    );

    if (matchedAccount) {
      // Check if user selected the correct matching role
      if (matchedAccount.role !== selectedRole) {
        setWrongRoleNotice({ detectedRole: matchedAccount.role, user: matchedAccount.user });
        return;
      }

      // Valid match for selected role!
      onLogin(matchedAccount.user);
      return;
    }

    setError(`Access Denied. Credentials not recognized for ${currentRoleConfig.title}. Please verify your email and password key.`);
  };

  const handleQuickLoginForCurrentRole = () => {
    setEmail(currentRoleConfig.demoEmail);
    setPassword(currentRoleConfig.demoPass);
    setError('');
    setWrongRoleNotice(null);

    // Immediate login
    const cleanEmail = currentRoleConfig.demoEmail.toLowerCase();
    if (selectedRole === Role.CHURCH_ADMIN) {
      onLogin(effectiveChurchAdmins[0] || {
        id: 'elder-1',
        name: 'Elder M. S. Banda',
        email: 'elder@church.org',
        password: 'elder123',
        role: Role.CHURCH_ADMIN,
        churchName: 'Woodlands SDA Church'
      });
    } else if (selectedRole === Role.CLERK) {
      onLogin(effectiveClerks[0] || {
        id: 'clerk-1',
        name: 'Sister P. Tembo',
        email: 'clerk@church.org',
        password: 'clerk123',
        role: Role.CLERK,
        churchName: 'Woodlands SDA Church'
      });
    } else if (selectedRole === Role.SUPERINTENDENT) {
      onLogin(superintendents[0] || {
        id: 'su-1',
        name: 'Sister R. Simpasa',
        email: 'superintendent@church.org',
        password: 'superintendent123',
        role: Role.SUPERINTENDENT,
        churchName: 'Woodlands SDA Church'
      });
    } else if (selectedRole === Role.TEACHER) {
      onLogin(teachers[0] || {
        id: 't1',
        name: 'Elder Musonda',
        email: 'musonda@church.org',
        password: 'password123',
        role: Role.TEACHER,
        assignedClass: 'c1'
      });
    } else if (selectedRole === Role.TREASURER) {
      onLogin(treasurers[0] || {
        id: 'tr-1',
        name: 'Elder Joseph Banda',
        email: 'treasurer@church.org',
        password: 'treasurer123',
        role: Role.TREASURER,
        churchName: 'Woodlands SDA Church'
      });
    }
  };

  const handleCopyCredentials = () => {
    navigator.clipboard.writeText(`Email: ${currentRoleConfig.demoEmail}\nPassword: ${currentRoleConfig.demoPass}`);
    setCopiedCreds(true);
    setTimeout(() => setCopiedCreds(false), 2000);
  };

  return (
    <div className="min-h-[92vh] flex items-center justify-center p-4 sm:p-6 bg-slate-100">
      <div className="w-full max-w-4xl bg-white rounded-[2.5rem] shadow-2xl shadow-blue-950/10 overflow-hidden border border-slate-200">
        
        {/* HEADER BRANDING */}
        <div className="bg-slate-950 p-6 sm:p-10 text-center relative overflow-hidden border-b-4 border-blue-900">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_20%,_rgba(59,130,246,0.2),transparent)]" />
          
          <div className="relative z-10 flex flex-col items-center">
            <div className="mb-4 p-2.5 bg-white rounded-2xl shadow-xl transform hover:scale-105 transition-transform duration-300">
              <SDALogo className="w-36 h-16 sm:w-44 sm:h-20" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tighter uppercase leading-none">
              Seventh-day Adventist Church
            </h2>
            <div className="mt-2 flex items-center gap-2">
              <span className="h-[1px] w-6 bg-amber-400" />
              <p className="text-amber-300 text-[10px] font-black uppercase tracking-[0.35em] whitespace-nowrap">
                Digital Church Management Portal
              </p>
              <span className="h-[1px] w-6 bg-amber-400" />
            </div>
          </div>
        </div>

        <div className="p-6 sm:p-10 space-y-8">

          {/* CHURCH STATION SELECTOR & ONBOARDING BANNER */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 text-white border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shrink-0 shadow-sm">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-amber-300">
                    Active Church Station:
                  </span>
                  {activeChurch.isDemo && (
                    <span className="bg-amber-400/20 text-amber-300 text-[9px] font-black uppercase px-2 py-0.5 rounded-full">
                      Demo Church
                    </span>
                  )}
                </div>
                {churches.length > 1 ? (
                  <select
                    value={selectedChurchId}
                    onChange={(e) => {
                      setSelectedChurchId(e.target.value);
                      if (onSelectChurch) onSelectChurch(e.target.value);
                    }}
                    className="font-black text-sm text-white bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1 mt-1 outline-none focus:ring-2 focus:ring-amber-400 cursor-pointer"
                  >
                    {churches.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.isDemo ? '(Demo Sample)' : `(${c.conference})`}
                      </option>
                    ))}
                  </select>
                ) : (
                  <p className="font-black text-base text-white tracking-tight leading-tight">
                    {activeChurch.name} <span className="text-xs text-slate-400 font-bold block sm:inline">({activeChurch.conference})</span>
                  </p>
                )}
              </div>
            </div>

            <Link
              to="/signup"
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-sm transition-all active:scale-95 shrink-0"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Register New Church Station</span>
            </Link>
          </div>
          
          {/* STEP 1: SELECT YOUR ROLE (REQUESTED FEATURE) */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                  Step 1 • Select Your Official Ministry Role
                </span>
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight">
                  Who Is Signing In Today?
                </h3>
              </div>
              <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-3 py-1 rounded-full hidden sm:inline-block">
                Role-Gated Access
              </span>
            </div>

            {/* Role Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {ROLE_OPTIONS.map((item) => {
                const IconComponent = item.icon;
                const isSelected = selectedRole === item.role;
                return (
                  <button
                    key={item.role}
                    type="button"
                    onClick={() => handleRoleSelect(item.role)}
                    className={`p-3.5 rounded-2xl border-2 text-left transition-all duration-200 relative group flex flex-col justify-between ${
                      isSelected
                        ? `${item.activeRing} shadow-lg scale-[1.02]`
                        : 'border-slate-200 bg-slate-50 hover:border-slate-300 hover:bg-slate-100/70 text-slate-700'
                    }`}
                  >
                    <div>
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2.5 ${
                        isSelected 
                          ? 'bg-white/20 text-white' 
                          : 'bg-white text-slate-700 border border-slate-200 group-hover:text-blue-900'
                      }`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <p className={`text-xs font-black uppercase tracking-tight leading-snug ${
                        isSelected ? 'text-white' : 'text-slate-900'
                      }`}>
                        {item.title}
                      </p>
                    </div>

                    <div className="mt-2 pt-2 border-t border-current/10">
                      <span className={`text-[9px] font-bold uppercase tracking-wider block truncate ${
                        isSelected ? 'text-amber-300' : 'text-slate-400'
                      }`}>
                        {item.subtitle}
                      </span>
                    </div>

                    {isSelected && (
                      <div className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-amber-400 text-slate-950 rounded-full flex items-center justify-center font-black shadow-sm">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* ACTIVE ROLE BRIEFING CARD */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-50 to-blue-50/50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className={`px-2.5 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider ${currentRoleConfig.badgeColor}`}>
                  {currentRoleConfig.title}
                </span>
                <span className="text-[10px] text-slate-500 font-bold">
                  Destination: <span className="text-slate-800 font-black">{currentRoleConfig.destination}</span>
                </span>
              </div>
              <p className="text-xs text-slate-600 font-medium">
                {currentRoleConfig.desc}
              </p>
            </div>

            {/* Quick 1-Click Fill button for this role */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleQuickLoginForCurrentRole}
                className="py-2.5 px-4 bg-slate-900 hover:bg-black text-white rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-sm transition-all active:scale-95"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                1-Click Sign In
              </button>
              <button
                type="button"
                onClick={handleCopyCredentials}
                className="p-2.5 bg-white border border-slate-200 text-slate-700 hover:text-slate-950 rounded-xl text-xs font-bold transition-colors"
                title="Copy Credentials to Clipboard"
              >
                {copiedCreds ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* WRONG ROLE HELPFUL NOTICE (IF USER SELECTED WRONG ROLE) */}
          {wrongRoleNotice && (
            <div className="p-4 bg-amber-50 border-2 border-amber-300 rounded-2xl animate-in fade-in duration-300 space-y-2">
              <div className="flex items-center gap-2 text-amber-950 font-black text-xs uppercase">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                Role Switch Required
              </div>
              <p className="text-xs text-amber-900 font-medium">
                The credentials for <span className="font-bold">{wrongRoleNotice.user.email}</span> belong to the <span className="font-bold underline uppercase">{ROLE_OPTIONS.find(r => r.role === wrongRoleNotice.detectedRole)?.title}</span> role.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSelectedRole(wrongRoleNotice.detectedRole);
                  setWrongRoleNotice(null);
                  onLogin(wrongRoleNotice.user);
                }}
                className="mt-1 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl font-black text-[11px] uppercase tracking-wider flex items-center gap-1.5 transition-all"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                Switch to {ROLE_OPTIONS.find(r => r.role === wrongRoleNotice.detectedRole)?.title} & Log In
              </button>
            </div>
          )}

          {/* GENERAL ERROR BANNER */}
          {error && (
            <div className="p-4 bg-red-50 text-red-800 rounded-2xl flex items-center gap-3 text-xs font-bold border border-red-200 animate-in fade-in duration-300">
              <AlertCircle className="w-5 h-5 shrink-0 text-red-600" />
              <p>{error}</p>
            </div>
          )}

          {/* STEP 2: CREDENTIALS FORM */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Email Input */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center ml-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Official Portal Email
                  </label>
                  <span className="text-[10px] font-mono text-slate-400">
                    Demo: {currentRoleConfig.demoEmail}
                  </span>
                </div>
                <div className="relative group">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-600 transition-colors" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={currentRoleConfig.demoEmail}
                    className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-600 focus:bg-white outline-none transition-all font-bold text-slate-800 text-xs"
                  />
                </div>
              </div>

              {/* Password Input */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center ml-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    Database Security Key
                  </label>
                  <span className="text-[10px] font-mono text-slate-400">
                    Demo: {currentRoleConfig.demoPass}
                  </span>
                </div>
                <div className="relative group">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-600 transition-colors" />
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-11 pr-11 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-600 focus:bg-white outline-none transition-all font-bold text-slate-800 text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            {/* SUBMIT BUTTON */}
            <button
              type="submit"
              className={`w-full py-4.5 rounded-2xl font-black text-sm uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all shadow-xl active:scale-[0.98] border-b-4 ${
                selectedRole === Role.TREASURER
                  ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 border-amber-600'
                  : selectedRole === Role.SUPERINTENDENT
                  ? 'bg-indigo-900 hover:bg-indigo-950 text-white border-indigo-950'
                  : selectedRole === Role.TEACHER
                  ? 'bg-emerald-800 hover:bg-emerald-900 text-white border-emerald-950'
                  : selectedRole === Role.CLERK
                  ? 'bg-blue-900 hover:bg-blue-950 text-white border-blue-950'
                  : 'bg-slate-950 hover:bg-black text-white border-slate-800'
              }`}
            >
              Enter {currentRoleConfig.title} Portal
              <ShieldCheck className="w-5 h-5 text-amber-400" />
            </button>
          </form>

          {/* CHURCH ADMIN ELDER INSTRUCTION FOOTNOTE */}
          <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-xs">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-blue-600 shrink-0" />
              <span>
                Need a new officer account? <strong>Church Admin Elder</strong> creates & manages all credentials.
              </span>
            </div>
            <button
              type="button"
              onClick={() => handleRoleSelect(Role.CHURCH_ADMIN)}
              className="text-[10px] font-black uppercase tracking-wider text-blue-900 hover:text-blue-700 underline flex items-center gap-1"
            >
              Sign In as Church Admin Elder <ChevronRight className="w-3 h-3" />
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};

export default LoginPage;
