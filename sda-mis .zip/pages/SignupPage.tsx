import React, { useState } from 'react';
import { Role, User, ChurchStation, Conference, District } from '../types';
import { 
  Building2, User as UserIcon, Mail, Lock, ShieldCheck, ChevronLeft, 
  MapPin, Phone, Sparkles, CheckCircle2, ArrowRight, BookOpen, Layers,
  Eye, EyeOff, ShieldAlert, Check, Copy
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import SDALogo from '../components/SDALogo';

interface SignupPageProps {
  onRegisterChurch: (church: ChurchStation, elder: User, initialSetupType: 'blank' | 'standard_classes') => void;
  onAutoLogin?: (user: User) => void;
  conferences?: Conference[];
  districts?: District[];
}

const COMMON_CONFERENCES = [
  'Lusaka Conference',
  'Midlands Conference',
  'South Zambia Conference',
  'Copperbelt Conference',
  'North Zambia Field',
  'East Zambia Field',
  'West Zambia Field',
  'Central African Division',
  'Southern Africa-Indian Ocean Division (SID)',
  'East-Central Africa Division (ECD)',
  'Trans-European Division (TED)',
  'North American Division (NAD)',
  'Other / Independent Conference'
];

export const SignupPage: React.FC<SignupPageProps> = ({ 
  onRegisterChurch, 
  onAutoLogin,
  conferences = [],
  districts = []
}) => {
  const navigate = useNavigate();

  // Form States
  const [churchName, setChurchName] = useState('');
  const [conference, setConference] = useState('Lusaka Conference');
  const [customConference, setCustomConference] = useState('');
  const [selectedDistrictId, setSelectedDistrictId] = useState('');
  const [customDistrict, setCustomDistrict] = useState('');
  const [district, setDistrict] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [churchPhone, setChurchPhone] = useState('');
  
  // Elder Credentials
  const [elderName, setElderName] = useState('');
  const [elderEmail, setElderEmail] = useState('');
  const [elderPhone, setElderPhone] = useState('');
  const [elderPassword, setElderPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Setup options
  const [initialSetupType, setInitialSetupType] = useState<'blank' | 'standard_classes'>('blank');
  
  // Submission & Confirmation state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registeredResult, setRegisteredResult] = useState<{ church: ChurchStation; elder: User } | null>(null);
  const [copiedCreds, setCopiedCreds] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const effectiveConference = conference === 'Other / Independent Conference' && customConference.trim()
    ? customConference.trim()
    : conference;

  const matchedConferenceObj = conferences.find(c => 
    c.name.toLowerCase() === effectiveConference.toLowerCase()
  );

  const availableDistrictsForConf = districts.filter(d => 
    (matchedConferenceObj && d.conferenceId === matchedConferenceObj.id) ||
    d.conferenceName?.toLowerCase() === effectiveConference.toLowerCase()
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!churchName.trim()) {
      setErrorMsg('Please specify the official Church Station Name.');
      return;
    }
    if (!elderName.trim()) {
      setErrorMsg('Please specify the presiding Church Admin Elder full name.');
      return;
    }
    if (!elderEmail.trim()) {
      setErrorMsg('Please specify an official email address for the elder.');
      return;
    }
    if (elderPassword.length < 6) {
      setErrorMsg('Master password should be at least 6 characters long.');
      return;
    }

    setIsSubmitting(true);

    const chosenDistrictObj = availableDistrictsForConf.find(d => d.id === selectedDistrictId);
    const finalDistrictName = chosenDistrictObj 
      ? chosenDistrictObj.name 
      : (customDistrict.trim() || district.trim() || (availableDistrictsForConf[0]?.name || 'Woodlands District'));
    const finalDistrictId = chosenDistrictObj?.id || availableDistrictsForConf[0]?.id;
    const finalConferenceId = matchedConferenceObj?.id;

    const payload = {
      churchName: churchName.trim(),
      conference: effectiveConference,
      conferenceId: finalConferenceId,
      district: finalDistrictName,
      districtId: finalDistrictId,
      city: city.trim(),
      address: address.trim(),
      phone: churchPhone.trim() || elderPhone.trim(),
      elderName: elderName.trim(),
      elderEmail: elderEmail.trim().toLowerCase(),
      elderPassword: elderPassword.trim(),
      elderPhone: elderPhone.trim(),
      initialSetupType
    };

    try {
      // 1. Send to backend database
      let backendSuccess = false;
      let returnedChurch: ChurchStation | null = null;
      let returnedElder: User | null = null;

      try {
        const res = await fetch('/api/churches/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (res.ok) {
          const data = await res.json();
          returnedChurch = data.church;
          returnedElder = data.elder;
          backendSuccess = true;
        }
      } catch (netErr) {
        console.warn('Backend endpoint unreachable, creating local church station record:', netErr);
      }

      // If backend returned or fallback locally:
      const churchId = returnedChurch?.id || `church-${churchName.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now().toString(36)}`;
      const finalChurch: ChurchStation = returnedChurch || {
        id: churchId,
        name: churchName.trim(),
        conference: effectiveConference,
        conferenceId: finalConferenceId,
        district: finalDistrictName,
        districtId: finalDistrictId,
        city: city.trim(),
        address: address.trim(),
        phone: churchPhone.trim() || elderPhone.trim(),
        email: elderEmail.trim().toLowerCase(),
        elderName: elderName.trim(),
        elderEmail: elderEmail.trim().toLowerCase(),
        pastorName: chosenDistrictObj?.pastorName,
        isDemo: false,
        createdAt: new Date().toISOString()
      };

      const finalElder: User = returnedElder || {
        id: `elder-${Date.now().toString(36)}`,
        name: elderName.trim(),
        email: elderEmail.trim().toLowerCase(),
        password: elderPassword.trim(),
        role: Role.CHURCH_ADMIN,
        churchId: finalChurch.id,
        churchName: finalChurch.name,
        title: 'Church Admin Elder (Main Admin)',
        phone: elderPhone.trim() || churchPhone.trim(),
        status: 'active',
        createdAt: new Date().toISOString()
      };

      // Notify parent app state
      onRegisterChurch(finalChurch, finalElder, initialSetupType);

      setRegisteredResult({
        church: finalChurch,
        elder: finalElder
      });
    } catch (err: any) {
      console.error('Registration error:', err);
      setErrorMsg(err.message || 'Failed to complete church station registration.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyCredentials = () => {
    if (!registeredResult) return;
    const slip = `CHURCH STATION REGISTRATION CREDENTIALS
Church: ${registeredResult.church.name}
Conference: ${registeredResult.church.conference}
Church Admin Elder: ${registeredResult.elder.name}
Login Email: ${registeredResult.elder.email}
Password: ${elderPassword}
Portal URL: Seventh-day Adventist Church Digital Registry`;

    navigator.clipboard.writeText(slip);
    setCopiedCreds(true);
    setTimeout(() => setCopiedCreds(false), 3000);
  };

  const handleLaunchPortal = () => {
    if (registeredResult && onAutoLogin) {
      onAutoLogin(registeredResult.elder);
      navigate('/');
    } else {
      navigate('/login');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 sm:p-6 lg:p-8 bg-slate-900 py-12">
      {/* Background Decor */}
      <div className="fixed inset-0 pointer-events-none opacity-20">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-500 rounded-full blur-[140px]" />
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-amber-500 rounded-full blur-[140px]" />
      </div>

      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden relative z-10 animate-in fade-in zoom-in-95 duration-300">
        
        {/* SUCCESS CONFIRMATION MODAL STATE */}
        {registeredResult ? (
          <div className="p-8 sm:p-14 text-center">
            <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl border border-emerald-100">
              <CheckCircle2 className="w-12 h-12" />
            </div>

            <span className="text-[10px] font-black uppercase tracking-[0.25em] text-emerald-600 bg-emerald-100/80 px-3 py-1.5 rounded-full inline-block mb-3">
              Church Station Onboarded Successfully
            </span>

            <h1 className="text-3xl sm:text-4xl font-black text-slate-950 uppercase tracking-tight leading-tight">
              {registeredResult.church.name}
            </h1>
            <p className="text-slate-500 text-sm max-w-lg mx-auto mt-2 font-medium">
              A fresh, independent church database has been initialized. You are now the Presiding Church Admin Elder with master governance rights.
            </p>

            {/* Credential Slip Card */}
            <div className="max-w-md mx-auto my-8 bg-slate-950 text-white rounded-2xl p-6 text-left border border-slate-800 shadow-xl relative overflow-hidden">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <SDALogo className="w-8 h-4 brightness-200" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                    Master Admin Credentials
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyCredentials}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 text-slate-300 transition-colors"
                >
                  {copiedCreds ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copiedCreds ? 'Copied!' : 'Copy'}
                </button>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-slate-400 block text-[9px] font-black uppercase tracking-wider">Church Station</span>
                  <span className="font-bold text-white text-sm">{registeredResult.church.name}</span>
                  <span className="text-[10px] text-slate-400 block">({registeredResult.church.conference})</span>
                </div>

                <div className="pt-1">
                  <span className="text-slate-400 block text-[9px] font-black uppercase tracking-wider">Church Admin Elder</span>
                  <span className="font-bold text-white">{registeredResult.elder.name}</span>
                </div>

                <div className="pt-1 grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-slate-400 block text-[9px] font-black uppercase tracking-wider">Official Email</span>
                    <span className="font-mono text-amber-300 font-bold">{registeredResult.elder.email}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9px] font-black uppercase tracking-wider">Master Password</span>
                    <span className="font-mono text-amber-300 font-bold">{elderPassword}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-[10px] text-slate-400 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Next: Use your Elder Portal to appoint your Church Clerk & Superintendent.</span>
              </div>
            </div>

            {/* Launch Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
              <button
                type="button"
                onClick={handleLaunchPortal}
                className="w-full sm:flex-1 py-4 bg-slate-950 hover:bg-black text-amber-400 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl shadow-slate-950/20 border-b-4 border-amber-500 transition-all active:scale-95"
              >
                <span>Launch {registeredResult.church.name}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => navigate('/login')}
                className="w-full sm:w-auto px-6 py-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl font-black text-xs uppercase tracking-wider transition-colors"
              >
                Go to Sign In
              </button>
            </div>
          </div>
        ) : (
          /* REGISTRATION FORM */
          <div>
            {/* Header Banner */}
            <div className="bg-slate-950 text-white p-6 sm:p-10 relative overflow-hidden border-b border-slate-800">
              <div className="absolute top-0 right-0 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
                <div>
                  <Link 
                    to="/login" 
                    className="inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-amber-400 transition-colors mb-3"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" /> Back to Sign In
                  </Link>
                  <div className="flex items-center gap-3">
                    <div className="bg-white p-2 rounded-xl shrink-0">
                      <SDALogo className="w-12 h-6" />
                    </div>
                    <div>
                      <h1 className="text-2xl sm:text-3xl font-black uppercase tracking-tight leading-none text-white">
                        Register Church Station
                      </h1>
                      <p className="text-xs text-amber-400 font-bold mt-1 tracking-wide">
                        Create Fresh Digital Register & Appoint Church Admin Elder
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:max-w-xs text-left">
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-wider text-emerald-400 mb-1">
                    <ShieldCheck className="w-4 h-4" /> Multi-Church Database
                  </div>
                  <p className="text-[11px] text-slate-300 leading-snug">
                    Each church station receives a fresh, isolated database with 0 members, clean registers, and independent officers.
                  </p>
                </div>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 sm:p-10 space-y-8">
              
              {errorMsg && (
                <div className="bg-rose-50 border-2 border-rose-200 text-rose-800 p-4 rounded-2xl flex items-center gap-3 text-xs font-bold animate-in fade-in">
                  <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Step 1: Church Station Details */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
                  <Building2 className="w-4 h-4 text-blue-600" />
                  <h2 className="text-xs font-black uppercase tracking-widest text-slate-900">
                    1. Church Station Profile
                  </h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">
                      Church Station Name <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        required 
                        value={churchName} 
                        onChange={(e) => setChurchName(e.target.value)} 
                        placeholder="e.g. Riverside Seventh-day Adventist Church" 
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm" 
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">
                      Conference / Mission <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={conference}
                      onChange={(e) => {
                        setConference(e.target.value);
                        setSelectedDistrictId('');
                      }}
                      className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm"
                    >
                      {conferences.length > 0 && (
                        <optgroup label="System Registered Conferences">
                          {conferences.map(c => (
                            <option key={c.id} value={c.name}>{c.name}</option>
                          ))}
                        </optgroup>
                      )}
                      <optgroup label="Standard Fields & Conferences">
                        {COMMON_CONFERENCES.filter(c => !conferences.some(conf => conf.name.toLowerCase() === c.toLowerCase())).map(c => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </optgroup>
                    </select>
                  </div>

                  {conference === 'Other / Independent Conference' ? (
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">
                        Specify Conference Name <span className="text-rose-500">*</span>
                      </label>
                      <input 
                        type="text" 
                        required 
                        value={customConference} 
                        onChange={(e) => setCustomConference(e.target.value)} 
                        placeholder="e.g. Western Zambia Field" 
                        className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm" 
                      />
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">
                          Church District <span className="text-rose-500">*</span>
                        </label>
                        {availableDistrictsForConf.length > 0 && (
                          <span className="text-[10px] font-bold text-indigo-600">
                            {availableDistrictsForConf.length} Created by Conference
                          </span>
                        )}
                      </div>

                      {availableDistrictsForConf.length > 0 ? (
                        <select
                          value={selectedDistrictId || (availableDistrictsForConf[0]?.id || '')}
                          onChange={(e) => {
                            setSelectedDistrictId(e.target.value);
                            if (e.target.value === 'custom') {
                              setCustomDistrict('');
                            }
                          }}
                          className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm"
                        >
                          {availableDistrictsForConf.map(d => (
                            <option key={d.id} value={d.id}>
                              {d.name} {d.pastorName ? `(${d.pastorName})` : ''}
                            </option>
                          ))}
                          <option value="custom">+ Other District / Enter Manually</option>
                        </select>
                      ) : (
                        <input 
                          type="text" 
                          value={district} 
                          onChange={(e) => setDistrict(e.target.value)} 
                          placeholder="e.g. Woodlands District" 
                          className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm" 
                        />
                      )}

                      {selectedDistrictId === 'custom' && (
                        <input 
                          type="text" 
                          required
                          value={customDistrict} 
                          onChange={(e) => setCustomDistrict(e.target.value)} 
                          placeholder="Enter your District name..." 
                          className="w-full px-4 py-3 mt-2 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm" 
                        />
                      )}
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">
                      Town / City
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        value={city} 
                        onChange={(e) => setCity(e.target.value)} 
                        placeholder="e.g. Lusaka" 
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm" 
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">
                      Physical Plot / Location
                    </label>
                    <input 
                      type="text" 
                      value={address} 
                      onChange={(e) => setAddress(e.target.value)} 
                      placeholder="e.g. Plot 140, Riverside Drive" 
                      className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm" 
                    />
                  </div>
                </div>
              </div>

              {/* Step 2: Presiding Church Admin Elder Credentials */}
              <div className="space-y-4 pt-2">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
                  <ShieldCheck className="w-4 h-4 text-amber-600" />
                  <h2 className="text-xs font-black uppercase tracking-widest text-slate-900">
                    2. Presiding Church Admin Elder (Main Administrator)
                  </h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">
                      Elder's Full Name <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        required 
                        value={elderName} 
                        onChange={(e) => setElderName(e.target.value)} 
                        placeholder="e.g. Elder James Lungu" 
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm" 
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">
                      Elder's Contact Phone / WhatsApp
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="tel" 
                        value={elderPhone} 
                        onChange={(e) => setElderPhone(e.target.value)} 
                        placeholder="e.g. +260 977 123456" 
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm" 
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">
                      Official Elder Email (Username) <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="email" 
                        required 
                        value={elderEmail} 
                        onChange={(e) => setElderEmail(e.target.value)} 
                        placeholder="elder@riversidechurch.org" 
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm" 
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">
                      Master Password <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type={showPassword ? 'text' : 'password'} 
                        required 
                        value={elderPassword} 
                        onChange={(e) => setElderPassword(e.target.value)} 
                        placeholder="Minimum 6 characters..." 
                        className="w-full pl-11 pr-11 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-600 outline-none transition-all font-bold text-slate-800 text-sm" 
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 3: Starting Register Configuration */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
                  <Layers className="w-4 h-4 text-indigo-600" />
                  <h2 className="text-xs font-black uppercase tracking-widest text-slate-900">
                    3. Starting Register Setup
                  </h2>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setInitialSetupType('blank')}
                    className={`p-4 rounded-2xl border-2 text-left transition-all ${
                      initialSetupType === 'blank'
                        ? 'border-slate-900 bg-slate-950 text-white shadow-lg'
                        : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        initialSetupType === 'blank' ? 'bg-amber-400 text-slate-950' : 'bg-slate-200 text-slate-700'
                      }`}>
                        Recommended
                      </span>
                      {initialSetupType === 'blank' && <Check className="w-4 h-4 text-amber-400" />}
                    </div>
                    <h3 className="font-black text-sm uppercase tracking-tight">Fresh Blank Register</h3>
                    <p className={`text-xs mt-1 font-medium ${initialSetupType === 'blank' ? 'text-slate-300' : 'text-slate-500'}`}>
                      Starts with 0 members, 0 classes, and clean ledgers. You and your clerk enter all details fresh.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setInitialSetupType('standard_classes')}
                    className={`p-4 rounded-2xl border-2 text-left transition-all ${
                      initialSetupType === 'standard_classes'
                        ? 'border-slate-900 bg-slate-950 text-white shadow-lg'
                        : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        initialSetupType === 'standard_classes' ? 'bg-amber-400 text-slate-950' : 'bg-slate-200 text-slate-700'
                      }`}>
                        Template
                      </span>
                      {initialSetupType === 'standard_classes' && <Check className="w-4 h-4 text-amber-400" />}
                    </div>
                    <h3 className="font-black text-sm uppercase tracking-tight">Standard SS Divisions</h3>
                    <p className={`text-xs mt-1 font-medium ${initialSetupType === 'standard_classes' ? 'text-slate-300' : 'text-slate-500'}`}>
                      Pre-creates 7 empty SDA Sabbath School divisions (Cradle Roll to Adult) ready to assign teachers.
                    </p>
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <Link
                  to="/login"
                  className="text-xs font-black uppercase tracking-wider text-slate-500 hover:text-slate-800"
                >
                  Already have an account? Sign In
                </Link>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto px-8 py-4 bg-slate-950 hover:bg-black text-amber-400 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl shadow-slate-950/20 border-b-4 border-amber-500 transition-all active:scale-95 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span>Registering Church Station...</span>
                  ) : (
                    <>
                      <span>Register Church & Initialize Register</span>
                      <Sparkles className="w-4 h-4 text-amber-400" />
                    </>
                  )}
                </button>
              </div>

            </form>
          </div>
        )}
      </div>
    </div>
  );
};

export default SignupPage;
