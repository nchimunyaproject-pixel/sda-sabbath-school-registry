import express, { Request, Response } from 'express';
import cors from 'cors';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { 
  initDatabase, 
  getAllChurchData, 
  syncAllChurchData, 
  getDatabaseHealth, 
  readLocalFileDatabase, 
  writeLocalFileDatabase,
  registerChurchStation
} from './server/db';
import { DEFAULT_INITIAL_DATA } from './server/seedData';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Initialize persistent database storage
async function bootstrapDatabase() {
  const existing = readLocalFileDatabase();
  if (!existing || !existing.classes || existing.classes.length === 0) {
    console.log('🌱 Populating initial database seed records...');
    writeLocalFileDatabase(DEFAULT_INITIAL_DATA);
  }
  await initDatabase();
}

// ----------------------------------------------------
// REST API Routes
// ----------------------------------------------------

// 1. Health & Database Diagnostic Endpoint
app.get('/api/health', (req: Request, res: Response) => {
  const health = getDatabaseHealth();
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    ...health
  });
});

// 2. Fetch Registered Churches List
app.get('/api/churches', async (req: Request, res: Response) => {
  try {
    const data = await getAllChurchData() || DEFAULT_INITIAL_DATA;
    const churches = data.churches || DEFAULT_INITIAL_DATA.churches || [];
    res.json(churches);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch registered churches', details: err.message });
  }
});

// 3. Register New Church Station + Church Admin Elder
app.post('/api/churches/register', async (req: Request, res: Response) => {
  try {
    const payload = req.body;
    if (!payload.churchName || !payload.elderName || !payload.elderEmail) {
      return res.status(400).json({ error: 'Missing required church or elder information' });
    }

    const result = await registerChurchStation(payload);
    res.json({
      success: true,
      ...result
    });
  } catch (err: any) {
    console.error('Church registration failure:', err);
    res.status(500).json({ error: 'Registration failed', details: err.message });
  }
});

// 4. Fetch Full Church Registry Data
app.get('/api/data', async (req: Request, res: Response) => {
  try {
    const data = await getAllChurchData();
    if (!data) {
      // Fallback to default initial data if storage was blank
      return res.json(DEFAULT_INITIAL_DATA);
    }
    res.json(data);
  } catch (err: any) {
    console.error('Error fetching registry data:', err);
    res.status(500).json({ error: 'Failed to fetch database records', details: err.message });
  }
});

// 3. Save / Sync Entire Registry State to Database
app.post('/api/sync', async (req: Request, res: Response) => {
  try {
    const payload = req.body;
    if (!payload || typeof payload !== 'object') {
      return res.status(400).json({ error: 'Invalid payload' });
    }

    const success = await syncAllChurchData(payload);
    if (success) {
      res.json({ 
        success: true, 
        message: 'Church registry synchronized and saved to database successfully',
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({ error: 'Partial synchronization warning' });
    }
  } catch (err: any) {
    console.error('Database sync failure:', err);
    res.status(500).json({ error: 'Synchronization failed', details: err.message });
  }
});

// 4. Quick Member Add / Update helper route
app.post('/api/members', async (req: Request, res: Response) => {
  try {
    const currentData = await getAllChurchData() || DEFAULT_INITIAL_DATA;
    const newMember = req.body;
    if (!newMember.id) {
      newMember.id = `mem-${Date.now()}`;
    }
    const updatedMembers = [...(currentData.churchMembers || []), newMember];
    await syncAllChurchData({ ...currentData, churchMembers: updatedMembers });
    res.json({ success: true, member: newMember });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Quick Study Guide Order helper route
app.post('/api/study-guide-orders', async (req: Request, res: Response) => {
  try {
    const currentData = await getAllChurchData() || DEFAULT_INITIAL_DATA;
    const newOrder = req.body;
    if (!newOrder.id) {
      newOrder.id = `sgo-${Date.now()}`;
    }
    const updatedOrders = [newOrder, ...(currentData.studyGuideOrders || [])];
    await syncAllChurchData({ ...currentData, studyGuideOrders: updatedOrders });
    res.json({ success: true, order: newOrder });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ----------------------------------------------------
// Server & Vite Middleware Bootstrap
// ----------------------------------------------------

async function startServer() {
  await bootstrapDatabase();

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`======================================================`);
    console.log(`🚀 SDA Digital Church Register Server Live on port ${PORT}`);
    console.log(`📡 Backend API: http://localhost:${PORT}/api/data`);
    console.log(`🏥 Health Check: http://localhost:${PORT}/api/health`);
    console.log(`======================================================`);
  });
}

startServer().catch(err => {
  console.error('Fatal Server Startup Error:', err);
});
