# SDA Management System — Database Setup & Real-World Testing Guide
### Seventh-day Adventist Church Management System (2025 Edition)

This guide provides the exact terminal commands and step-by-step instructions to set up and run a live, standalone database (**PostgreSQL** or **MySQL / MariaDB**) for production or local staging.

---

## ⚡ Option 1: Instant Docker Setup (Recommended — 30 Seconds)

If you have Docker installed, you can spin up a fully isolated, clean database with one terminal command:

### For PostgreSQL:
```bash
# 1. Run PostgreSQL 16 container
docker run --name sda-postgres \
  -e POSTGRES_DB=sda_church_registry \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -p 5432:5432 \
  -d postgres:16-alpine

# 2. Import the complete Adventist multi-tier schema & seed data
docker exec -i sda-postgres psql -U postgres -d sda_church_registry < init_postgres.sql
```

### For MySQL / MariaDB:
```bash
# 1. Run MySQL 8 container
docker run --name sda-mysql \
  -e MYSQL_DATABASE=sda_church_registry \
  -e MYSQL_ALLOW_EMPTY_PASSWORD=yes \
  -p 3306:3306 \
  -d mysql:8.0

# 2. Import the schema & seed data
docker exec -i sda-mysql mysql -u root sda_church_registry < init.sql
```

---

## 🐘 Option 2: Native PostgreSQL Setup (CLI / psql)

If you have PostgreSQL installed on your machine or cloud server (AWS RDS, Supabase, Neon, or local PostgreSQL):

### Step 1: Open Terminal and Create Database & User
```bash
# Log into PostgreSQL prompt as superuser
psql -U postgres

# Inside psql prompt, run:
CREATE DATABASE sda_church_registry;
CREATE USER sda_admin WITH ENCRYPTED PASSWORD 'sda_secure_pass123';
GRANT ALL PRIVILEGES ON DATABASE sda_church_registry TO sda_admin;
\c sda_church_registry
GRANT ALL ON SCHEMA public TO sda_admin;
\q
```

### Step 2: Execute the DDL Script
```bash
# Run from your project directory:
psql -U sda_admin -d sda_church_registry -h 127.0.0.1 -p 5432 -f init_postgres.sql
```

### Step 3: Verify Tables & Seeds
```bash
psql -U sda_admin -d sda_church_registry -h 127.0.0.1 -c "\dt"
psql -U sda_admin -d sda_church_registry -h 127.0.0.1 -c "SELECT id, name, president_name FROM conferences;"
psql -U sda_admin -d sda_church_registry -h 127.0.0.1 -c "SELECT id, name, role, email FROM users;"
```

---

## 🐬 Option 3: Native MySQL / MariaDB (CLI or XAMPP / WAMP)

### Using Terminal (Command Prompt / Bash):
```bash
# 1. Log in to MySQL
mysql -u root -p

# 2. Create the database
CREATE DATABASE IF NOT EXISTS sda_church_registry DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;

# 3. Import init.sql
mysql -u root -p sda_church_registry < init.sql
```

### Using phpMyAdmin (Browser GUI):
1. Start **Apache** & **MySQL** in your XAMPP/WAMP Control Panel.
2. Open `http://localhost/phpmyadmin` in your browser.
3. Click **New** on the left sidebar and name the database: `sda_church_registry`.
4. Click the **Import** tab at the top.
5. Click **Choose File**, select `init.sql` from your project directory, and click **Import** (or **Go**).
6. All 12 tables and initial seed data for all 8 administrative roles are created automatically!

---

## ⚙️ Environment Configuration (`.env`)

Create a `.env` file in the root directory of the application:

### For MySQL / MariaDB:
```env
PORT=3000
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=sda_church_registry
```

### For PostgreSQL:
```env
PORT=3000
DB_TYPE=postgres
DATABASE_URL=postgres://sda_admin:sda_secure_pass123@127.0.0.1:5432/sda_church_registry
```

---

## 🏃 Running the Application

In your project terminal, execute:
```bash
# Install dependencies
npm install

# Start the full-stack server
npm run dev
```

Open your browser to: **`http://localhost:3000`**

---

## 🔑 Pre-Configured Live Administrative Accounts

| Administrative Tier | Name | Email | Password | Scope |
| :--- | :--- | :--- | :--- | :--- |
| **Tier 1: System Super Admin** | Elder Dr. Harrington Tembo | `superadmin@sda.org` | `admin123` | System-wide / Union / Division |
| **Tier 2: Conference President** | Pastor Dr. Harrington Simpasa | `president@conference.org` | `president123` | Lusaka Conference Territory |
| **Tier 3: District Pastor** | Pastor H. Chisenga | `pastor@district.org` | `pastor123` | Woodlands Pastoral Circuit |
| **Tier 4: Church First Elder** | Elder M. S. Banda | `elder@church.org` | `elder123` | Woodlands SDA Church (Admin) |
| **Tier 4: Church Clerk** | Sister P. Tembo | `clerk@church.org` | `clerk123` | Master Membership Register |
| **Tier 4: Church Treasurer** | Elder Joseph Banda | `treasurer@church.org` | `treasurer123` | Sacred Trust & Treasury Ledger |
| **Tier 4: SS Superintendent** | Sister R. Simpasa | `superintendent@church.org` | `superintendent123` | Sabbath School Divisions |
| **Tier 4: SS Teacher** | Elder Musonda | `musonda@church.org` | `password123` | Adult Sabbath School Class |

---

## 💾 Zero-Config In-Memory / File Fallback Mode

If no external SQL database server is running, the application **automatically detects this** and activates the embedded JSON relational engine (`database/sda_church_registry.json`). Every change you make in any dashboard is persistently written to disk without data loss!
