import mysql, { Pool } from 'mysql2/promise';
import fs from 'fs';
import path from 'path';

export interface DatabaseHealth {
  status: 'ok' | 'error';
  engine: 'mysql' | 'local_file';
  isMySQLConnected: boolean;
  message: string;
  storagePath?: string;
  counts: {
    users: number;
    classes: number;
    students: number;
    churchMembers: number;
    studyGuideOrders: number;
    attendanceRecords: number;
    treasuryRecords: number;
  };
}

const DATA_DIR = path.join(process.cwd(), 'database');
const DATA_FILE = path.join(DATA_DIR, 'sda_church_registry.json');

// Ensure database directory exists
if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (err) {
    console.error('Failed to create database directory:', err);
  }
}

let mysqlPool: Pool | null = null;
let isMySQLConnected = false;

// Initialize MySQL pool
const dbConfig = {
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'sda_church_registry',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
};

export async function initDatabase(): Promise<boolean> {
  // 1. Attempt MySQL connection
  try {
    // First try connecting to MySQL server to ensure database exists
    const rootConnection = await mysql.createConnection({
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.user,
      password: dbConfig.password
    });

    await rootConnection.query(`CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    await rootConnection.end();

    // Now connect to the pool
    mysqlPool = mysql.createPool(dbConfig);
    const conn = await mysqlPool.getConnection();
    console.log(`\n======================================================`);
    console.log(`✅ [SDA Backend] Connected to MySQL: ${dbConfig.database}@${dbConfig.host}:${dbConfig.port}`);
    console.log(`======================================================\n`);
    conn.release();
    isMySQLConnected = true;

    // Run table creation scripts
    await createMySQLTables();
    return true;
  } catch (err: any) {
    isMySQLConnected = false;
    console.log(`\n======================================================`);
    console.log(`ℹ️ [SDA Backend] MySQL not available (${err.message || 'Connection refused'}).`);
    console.log(`💾 [SDA Backend] Using persistent Local File Database: ${DATA_FILE}`);
    console.log(`   (All changes are automatically saved to this JSON database file!)`);
    console.log(`======================================================\n`);
    return false;
  }
}

async function createMySQLTables() {
  if (!mysqlPool) return;

  const tableQueries = [
    `CREATE TABLE IF NOT EXISTS conferences (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      presidentName VARCHAR(100) NOT NULL,
      presidentEmail VARCHAR(100) NOT NULL,
      presidentPhone VARCHAR(50) DEFAULT NULL,
      headquartersCity VARCHAR(100) DEFAULT NULL,
      unionName VARCHAR(150) DEFAULT 'Southern Zambia Union Conference (SZUC)',
      address TEXT DEFAULT NULL,
      phone VARCHAR(50) DEFAULT NULL,
      email VARCHAR(100) DEFAULT NULL,
      createdAt VARCHAR(50) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS districts (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      conferenceId VARCHAR(50) NOT NULL,
      conferenceName VARCHAR(150) DEFAULT NULL,
      pastorName VARCHAR(100) NOT NULL,
      pastorEmail VARCHAR(100) NOT NULL,
      pastorPhone VARCHAR(50) DEFAULT NULL,
      createdAt VARCHAR(50) NOT NULL,
      INDEX (conferenceId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS churches (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      conference VARCHAR(100) NOT NULL,
      conferenceId VARCHAR(50) DEFAULT NULL,
      district VARCHAR(100) DEFAULT NULL,
      districtId VARCHAR(50) DEFAULT NULL,
      city VARCHAR(100) DEFAULT NULL,
      address TEXT DEFAULT NULL,
      phone VARCHAR(50) DEFAULT NULL,
      email VARCHAR(100) DEFAULT NULL,
      elderName VARCHAR(100) DEFAULT NULL,
      elderEmail VARCHAR(100) DEFAULT NULL,
      pastorId VARCHAR(50) DEFAULT NULL,
      pastorName VARCHAR(100) DEFAULT NULL,
      isDemo TINYINT(1) DEFAULT 0,
      createdAt VARCHAR(50) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      email VARCHAR(100) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL,
      role VARCHAR(50) NOT NULL,
      assignedClass VARCHAR(50) DEFAULT NULL,
      language VARCHAR(50) DEFAULT NULL,
      churchId VARCHAR(50) DEFAULT NULL,
      churchName VARCHAR(100) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS classes (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      teacherId VARCHAR(50) DEFAULT NULL,
      language VARCHAR(50) DEFAULT NULL,
      churchId VARCHAR(50) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS students (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      classId VARCHAR(50) NOT NULL,
      attendanceStatus VARCHAR(20) DEFAULT 'unmarked',
      lessonStudied TINYINT(1) DEFAULT 0,
      isTransferring TINYINT(1) DEFAULT 0,
      memberId VARCHAR(50) DEFAULT NULL,
      INDEX (classId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS church_members (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      memberNumber VARCHAR(50) DEFAULT NULL,
      givenNames VARCHAR(100) DEFAULT NULL,
      primarySurname VARCHAR(100) DEFAULT NULL,
      secondarySurname VARCHAR(100) DEFAULT NULL,
      churchId VARCHAR(50) NOT NULL,
      status VARCHAR(30) NOT NULL DEFAULT 'active',
      baptismDate VARCHAR(50) DEFAULT NULL,
      dob VARCHAR(50) DEFAULT NULL,
      gender VARCHAR(20) DEFAULT NULL,
      contact VARCHAR(50) DEFAULT NULL,
      email VARCHAR(100) DEFAULT NULL,
      address TEXT DEFAULT NULL,
      familyUnitId VARCHAR(50) DEFAULT NULL,
      relationshipToHead VARCHAR(50) DEFAULT NULL,
      memberType VARCHAR(50) DEFAULT NULL,
      outreachFlag TINYINT(1) DEFAULT 0,
      outreachNotes TEXT DEFAULT NULL,
      lastAttendDate VARCHAR(50) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS family_units (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      churchId VARCHAR(50) NOT NULL,
      familyName VARCHAR(100) NOT NULL,
      primaryContactId VARCHAR(50) NOT NULL,
      primaryContactName VARCHAR(100) DEFAULT NULL,
      address TEXT NOT NULL,
      contactPhone VARCHAR(50) NOT NULL,
      notes TEXT DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS study_guide_orders (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      churchId VARCHAR(50) NOT NULL,
      orderNumber VARCHAR(50) NOT NULL,
      memberId VARCHAR(50) DEFAULT NULL,
      memberName VARCHAR(100) NOT NULL,
      memberContact VARCHAR(50) DEFAULT NULL,
      memberEmail VARCHAR(100) DEFAULT NULL,
      guideType VARCHAR(100) NOT NULL,
      quarter VARCHAR(50) NOT NULL,
      quantity INT NOT NULL DEFAULT 1,
      unitPrice DECIMAL(10,2) NOT NULL DEFAULT 0.00,
      totalAmount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
      paymentStatus VARCHAR(30) NOT NULL DEFAULT 'pending',
      paymentMethod VARCHAR(50) NOT NULL DEFAULT 'Cash',
      orderStatus VARCHAR(30) NOT NULL DEFAULT 'placed',
      orderDate VARCHAR(50) NOT NULL,
      notes TEXT DEFAULT NULL,
      distributedDate VARCHAR(50) DEFAULT NULL,
      abcRequisitionRef VARCHAR(100) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS announcements (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      teacherId VARCHAR(50) NOT NULL,
      teacherName VARCHAR(100) NOT NULL,
      className VARCHAR(100) NOT NULL,
      content TEXT NOT NULL,
      timestamp DATETIME NOT NULL,
      status VARCHAR(20) DEFAULT 'pending'
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS attendance_records (
      id VARCHAR(50) NOT NULL PRIMARY KEY,
      date DATE NOT NULL,
      classId VARCHAR(50) NOT NULL,
      className VARCHAR(100) NOT NULL,
      teacherId VARCHAR(50) NOT NULL,
      teacherName VARCHAR(100) NOT NULL,
      totalStudents INT NOT NULL,
      presentCount INT NOT NULL,
      absentCount INT NOT NULL,
      visitorCount INT NOT NULL,
      lessonStudyCount INT DEFAULT 0,
      jsonData LONGTEXT DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS generic_store (
      entity_key VARCHAR(50) NOT NULL PRIMARY KEY,
      data LONGTEXT NOT NULL,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`
  ];

  for (const q of tableQueries) {
    try {
      await mysqlPool.query(q);
    } catch (err: any) {
      console.warn(`Table creation notice:`, err.message);
    }
  }
}

// Local File Database helper functions
export function readLocalFileDatabase(): any {
  if (!fs.existsSync(DATA_FILE)) {
    return null;
  }
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading local file database:', err);
    return null;
  }
}

export function writeLocalFileDatabase(data: any): boolean {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error writing local file database:', err);
    return false;
  }
}

/**
 * Fetch all church data from the active database engine
 */
export async function getAllChurchData(): Promise<any> {
  // If MySQL is active, read from MySQL
  if (isMySQLConnected && mysqlPool) {
    try {
      const [users] = await mysqlPool.query<any[]>('SELECT * FROM users');
      const [classes] = await mysqlPool.query<any[]>('SELECT * FROM classes');
      const [students] = await mysqlPool.query<any[]>('SELECT * FROM students');
      const [churchMembers] = await mysqlPool.query<any[]>('SELECT * FROM church_members');
      const [familyUnits] = await mysqlPool.query<any[]>('SELECT * FROM family_units');
      const [studyGuideOrders] = await mysqlPool.query<any[]>('SELECT * FROM study_guide_orders ORDER BY orderDate DESC');
      const [announcements] = await mysqlPool.query<any[]>('SELECT * FROM announcements ORDER BY timestamp DESC');
      const [attendanceRecords] = await mysqlPool.query<any[]>('SELECT * FROM attendance_records ORDER BY date DESC');
      const [genericStore] = await mysqlPool.query<any[]>('SELECT * FROM generic_store');

      // Unpack generic store
      const genericMap: Record<string, any> = {};
      genericStore.forEach(row => {
        try {
          genericMap[row.entity_key] = JSON.parse(row.data);
        } catch {}
      });

      const teachers = users.filter(u => u.role === 'TEACHER');
      const churchAdmins = users.filter(u => u.role === 'CHURCH_ADMIN');
      const clerks = users.filter(u => u.role === 'CLERK');
      const admins = users.filter(u => u.role === 'CLERK' || u.role === 'CHURCH_ADMIN');
      const treasurers = users.filter(u => u.role === 'TREASURER');
      const superintendents = users.filter(u => u.role === 'SUPERINTENDENT');

      const formattedClasses = classes.map(c => ({
        ...c,
        students: students.filter(s => s.classId === c.id).map(s => ({
          ...s,
          lessonStudied: !!s.lessonStudied,
          isTransferring: !!s.isTransferring
        }))
      }));

      const formattedAttendance = attendanceRecords.map(r => {
        let parsed = null;
        if (r.jsonData) {
          try {
            parsed = JSON.parse(r.jsonData);
          } catch {}
        }
        return parsed || {
          ...r,
          date: r.date instanceof Date ? r.date.toISOString().split('T')[0] : r.date,
          records: [],
          visitors: []
        };
      });

      return {
        conferences: genericMap.conferences || [],
        districts: genericMap.districts || [],
        superAdmins: genericMap.superAdmins || [],
        conferencePresidents: genericMap.conferencePresidents || [],
        districtPastors: genericMap.districtPastors || [],
        churches: genericMap.churches || [],
        churchAdmins,
        clerks,
        admins,
        teachers,
        treasurers: treasurers.length ? treasurers : genericMap.treasurers,
        superintendents: superintendents.length ? superintendents : genericMap.superintendents,
        classes: formattedClasses,
        churchMembers,
        familyUnits,
        studyGuideOrders,
        announcements,
        attendanceRecords: formattedAttendance,
        transferRequests: genericMap.transferRequests || [],
        meetings: genericMap.meetings || [],
        officers: genericMap.officers || [],
        bankAccounts: genericMap.bankAccounts || [],
        remittances: genericMap.remittances || [],
        ssTransmissions: genericMap.ssTransmissions || [],
        disbursements: genericMap.disbursements || [],
        auxiliaryDepartments: genericMap.auxiliaryDepartments || [],
        envelopes: genericMap.envelopes || [],
        looseOfferings: genericMap.looseOfferings || [],
        literatureOrders: genericMap.literatureOrders || [],
        auditRecords: genericMap.auditRecords || [],
        // Superintendent modules
        mobilisationPlan: genericMap.mobilisationPlan || null,
        conferenceEmphases: genericMap.conferenceEmphases || null,
        curriculumInventory: genericMap.curriculumInventory || null,
        programRunSheet: genericMap.programRunSheet || null,
        councilMembers: genericMap.councilMembers || null,
        auxiliaryOfficers: genericMap.auxiliaryOfficers || null,
        teacherCandidates: genericMap.teacherCandidates || null,
        teachersMeetings: genericMap.teachersMeetings || null,
        evangelismProjects: genericMap.evangelismProjects || null,
        greetingSchedules: genericMap.greetingSchedules || null,
        quarterlyReport: genericMap.quarterlyReport || null
      };
    } catch (err: any) {
      console.error('MySQL Read Error, falling back to local file DB:', err.message);
    }
  }

  // Fallback / primary read from local file database
  return readLocalFileDatabase();
}

/**
 * Save / Synchronize all church data to the active database engine
 */
export async function syncAllChurchData(data: any): Promise<boolean> {
  // Always update local file as persistent backup
  writeLocalFileDatabase(data);

  // If MySQL is active, save to MySQL transactionally
  if (isMySQLConnected && mysqlPool) {
    let connection: any = null;
    try {
      connection = await mysqlPool.getConnection();
      await connection.beginTransaction();

      // 1. Users (Church Admins, Clerks, Teachers, Treasurers, Superintendents)
      await connection.query('DELETE FROM users');
      const rawUsers = [
        ...(data.churchAdmins || []),
        ...(data.clerks || []),
        ...(data.admins || []),
        ...(data.teachers || []),
        ...(data.treasurers || []),
        ...(data.superintendents || [])
      ];
      const userMap = new Map();
      rawUsers.forEach(u => {
        if (u && u.id) userMap.set(u.id, u);
      });
      const allUsers = Array.from(userMap.values());

      if (allUsers.length > 0) {
        const userRows = allUsers.map((u: any) => [
          u.id,
          u.name,
          u.email,
          u.password || 'password123',
          u.role,
          u.assignedClass || null,
          u.language || null,
          u.churchName || null
        ]);
        await connection.query(
          'INSERT INTO users (id, name, email, password, role, assignedClass, language, churchName) VALUES ?',
          [userRows]
        );
      }

      // 2. Classes & Students
      await connection.query('DELETE FROM students');
      await connection.query('DELETE FROM classes');
      if (data.classes && data.classes.length > 0) {
        const classRows = data.classes.map((c: any) => [
          c.id,
          c.name,
          c.teacherId || null,
          c.language || null,
          c.churchId || null
        ]);
        await connection.query(
          'INSERT INTO classes (id, name, teacherId, language, churchId) VALUES ?',
          [classRows]
        );

        const allStudents = data.classes.flatMap((c: any) =>
          (c.students || []).map((s: any) => [
            s.id,
            s.name,
            c.id,
            s.attendanceStatus || 'unmarked',
            s.lessonStudied ? 1 : 0,
            s.isTransferring ? 1 : 0,
            s.memberId || null
          ])
        );
        if (allStudents.length > 0) {
          await connection.query(
            'INSERT INTO students (id, name, classId, attendanceStatus, lessonStudied, isTransferring, memberId) VALUES ?',
            [allStudents]
          );
        }
      }

      // 3. Church Members
      await connection.query('DELETE FROM church_members');
      if (data.churchMembers && data.churchMembers.length > 0) {
        const memberRows = data.churchMembers.map((m: any) => [
          m.id,
          m.name,
          m.memberNumber || null,
          m.givenNames || null,
          m.primarySurname || null,
          m.secondarySurname || null,
          m.churchId || 'admin-initial',
          m.status || 'active',
          m.baptismDate || null,
          m.dob || null,
          m.gender || null,
          m.contact || null,
          m.email || null,
          m.address || null,
          m.familyUnitId || null,
          m.relationshipToHead || null,
          m.memberType || null,
          m.outreachFlag ? 1 : 0,
          m.outreachNotes || null,
          m.lastAttendDate || null
        ]);
        await connection.query(
          'INSERT INTO church_members (id, name, memberNumber, givenNames, primarySurname, secondarySurname, churchId, status, baptismDate, dob, gender, contact, email, address, familyUnitId, relationshipToHead, memberType, outreachFlag, outreachNotes, lastAttendDate) VALUES ?',
          [memberRows]
        );
      }

      // 4. Family Units
      await connection.query('DELETE FROM family_units');
      if (data.familyUnits && data.familyUnits.length > 0) {
        const familyRows = data.familyUnits.map((f: any) => [
          f.id,
          f.churchId || 'admin-initial',
          f.familyName,
          f.primaryContactId,
          f.primaryContactName || null,
          f.address || '',
          f.contactPhone || '',
          f.notes || null
        ]);
        await connection.query(
          'INSERT INTO family_units (id, churchId, familyName, primaryContactId, primaryContactName, address, contactPhone, notes) VALUES ?',
          [familyRows]
        );
      }

      // 5. Study Guide Orders
      await connection.query('DELETE FROM study_guide_orders');
      if (data.studyGuideOrders && data.studyGuideOrders.length > 0) {
        const orderRows = data.studyGuideOrders.map((o: any) => [
          o.id,
          o.churchId || 'admin-initial',
          o.orderNumber,
          o.memberId || null,
          o.memberName,
          o.memberContact || null,
          o.memberEmail || null,
          o.guideType,
          o.quarter,
          o.quantity || 1,
          o.unitPrice || 0,
          o.totalAmount || 0,
          o.paymentStatus || 'pending',
          o.paymentMethod || 'Cash',
          o.orderStatus || 'placed',
          o.orderDate || new Date().toISOString(),
          o.notes || null,
          o.distributedDate || null,
          o.abcRequisitionRef || null
        ]);
        await connection.query(
          'INSERT INTO study_guide_orders (id, churchId, orderNumber, memberId, memberName, memberContact, memberEmail, guideType, quarter, quantity, unitPrice, totalAmount, paymentStatus, paymentMethod, orderStatus, orderDate, notes, distributedDate, abcRequisitionRef) VALUES ?',
          [orderRows]
        );
      }

      // 6. Announcements
      await connection.query('DELETE FROM announcements');
      if (data.announcements && data.announcements.length > 0) {
        const annRows = data.announcements.map((a: any) => [
          a.id,
          a.teacherId,
          a.teacherName,
          a.className,
          a.content,
          (a.timestamp || new Date().toISOString()).slice(0, 19).replace('T', ' '),
          a.status || 'pending'
        ]);
        await connection.query(
          'INSERT INTO announcements (id, teacherId, teacherName, className, content, timestamp, status) VALUES ?',
          [annRows]
        );
      }

      // 7. Attendance Records
      await connection.query('DELETE FROM attendance_records');
      if (data.attendanceRecords && data.attendanceRecords.length > 0) {
        const attRows = data.attendanceRecords.map((r: any) => [
          r.id,
          r.date,
          r.classId,
          r.className,
          r.teacherId,
          r.teacherName,
          r.totalStudents,
          r.presentCount,
          r.absentCount,
          r.visitorCount,
          r.lessonStudyCount || 0,
          JSON.stringify(r)
        ]);
        await connection.query(
          'INSERT INTO attendance_records (id, date, classId, className, teacherId, teacherName, totalStudents, presentCount, absentCount, visitorCount, lessonStudyCount, jsonData) VALUES ?',
          [attRows]
        );
      }

      // 8. Store complex modules in generic_store
      const genericKeys = [
        'conferences', 'districts', 'superAdmins', 'conferencePresidents', 'districtPastors',
        'churches', 'transferRequests', 'meetings', 'officers', 'bankAccounts',
        'remittances', 'ssTransmissions', 'disbursements', 'auxiliaryDepartments',
        'envelopes', 'looseOfferings', 'literatureOrders', 'auditRecords',
        'mobilisationPlan', 'conferenceEmphases', 'curriculumInventory',
        'programRunSheet', 'councilMembers', 'auxiliaryOfficers',
        'teacherCandidates', 'teachersMeetings', 'evangelismProjects',
        'greetingSchedules', 'quarterlyReport'
      ];

      for (const key of genericKeys) {
        if (data[key] !== undefined) {
          await connection.query(
            'INSERT INTO generic_store (entity_key, data) VALUES (?, ?) ON DUPLICATE KEY UPDATE data = VALUES(data)',
            [key, JSON.stringify(data[key])]
          );
        }
      }

      await connection.commit();
      return true;
    } catch (err: any) {
      if (connection) await connection.rollback();
      console.error('MySQL Transaction Sync Error:', err.message);
      return false;
    } finally {
      if (connection) connection.release();
    }
  }

  return true;
}

export function getDatabaseHealth(): DatabaseHealth {
  const localData = readLocalFileDatabase() || {};
  return {
    status: 'ok',
    engine: isMySQLConnected ? 'mysql' : 'local_file',
    isMySQLConnected,
    message: isMySQLConnected 
      ? `Connected to MySQL database '${dbConfig.database}' on ${dbConfig.host}:${dbConfig.port}`
      : `Active persistent JSON database at ${DATA_FILE}`,
    storagePath: DATA_FILE,
    counts: {
      users: (localData.admins?.length || 0) + (localData.teachers?.length || 0),
      classes: localData.classes?.length || 0,
      students: (localData.classes || []).reduce((acc: number, c: any) => acc + (c.students?.length || 0), 0),
      churchMembers: localData.churchMembers?.length || 0,
      studyGuideOrders: localData.studyGuideOrders?.length || 0,
      attendanceRecords: localData.attendanceRecords?.length || 0,
      treasuryRecords: (localData.envelopes?.length || 0) + (localData.disbursements?.length || 0) + (localData.remittances?.length || 0)
    }
  };
}

/**
 * Register a new SDA Church station + presiding Church Admin Elder
 * Persists immediately into the database and prepares a clean, isolated dataset for that church
 */
export async function registerChurchStation(payload: {
  churchName: string;
  conference: string;
  district?: string;
  city?: string;
  address?: string;
  phone?: string;
  elderName: string;
  elderEmail: string;
  elderPassword: string;
  elderPhone?: string;
  initialSetupType?: 'blank' | 'standard_classes';
}): Promise<{ church: any; elder: any; message: string }> {
  const currentData = await getAllChurchData() || {};
  const churches = currentData.churches || [];
  
  // Clean church slug
  const slug = payload.churchName.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  const churchId = `church-${slug || 'station'}-${Date.now().toString(36)}`;
  
  const newChurch = {
    id: churchId,
    name: payload.churchName.trim(),
    conference: payload.conference || 'SDA Conference',
    district: payload.district || '',
    city: payload.city || '',
    address: payload.address || '',
    phone: payload.phone || payload.elderPhone || '',
    email: payload.elderEmail.trim().toLowerCase(),
    elderName: payload.elderName.trim(),
    elderEmail: payload.elderEmail.trim().toLowerCase(),
    isDemo: false,
    createdAt: new Date().toISOString()
  };

  const elderId = `elder-${Date.now().toString(36)}`;
  const newElder = {
    id: elderId,
    name: payload.elderName.trim(),
    email: payload.elderEmail.trim().toLowerCase(),
    password: payload.elderPassword || 'elder123',
    role: 'CHURCH_ADMIN',
    churchId: newChurch.id,
    churchName: newChurch.name,
    title: 'Church Admin Elder (Main Admin)',
    phone: payload.elderPhone || payload.phone || '',
    status: 'active',
    createdAt: new Date().toISOString()
  };

  // If standard_classes selected, provision empty standard SDA SS divisions
  let updatedClasses = currentData.classes || [];
  if (payload.initialSetupType === 'standard_classes') {
    const standardDivisions = [
      { id: `c-${churchId}-cradle`, name: 'Cradle Roll (0-2 yrs)' },
      { id: `c-${churchId}-kinder`, name: 'Kindergarten (3-5 yrs)' },
      { id: `c-${churchId}-primary`, name: 'Primary Class (6-9 yrs)' },
      { id: `c-${churchId}-junior`, name: 'Junior Class (10-12 yrs)' },
      { id: `c-${churchId}-earliteen`, name: 'Earliteen (13-14 yrs)' },
      { id: `c-${churchId}-youth`, name: 'Youth Ministry (15-30 yrs)' },
      { id: `c-${churchId}-adult`, name: 'Adult Sabbath School' }
    ];
    const initialClassesForChurch = standardDivisions.map(div => ({
      id: div.id,
      name: div.name,
      teacherId: null,
      language: 'English',
      churchId: newChurch.id,
      students: []
    }));
    updatedClasses = [...updatedClasses, ...initialClassesForChurch];
  }

  const updatedChurches = [...churches, newChurch];
  const updatedAdmins = [...(currentData.churchAdmins || []), newElder];
  const updatedAllAdmins = [...(currentData.admins || []), newElder];

  const updatedData = {
    ...currentData,
    churches: updatedChurches,
    churchAdmins: updatedAdmins,
    admins: updatedAllAdmins,
    classes: updatedClasses
  };

  await syncAllChurchData(updatedData);

  return {
    church: newChurch,
    elder: newElder,
    message: `${newChurch.name} registered successfully. Fresh digital registers initialized.`
  };
}
