export const DEFAULT_INITIAL_DATA = {
  conferences: [
    {
      id: 'conf-lusaka',
      name: 'Lusaka Conference',
      presidentName: 'Pastor Dr. Harrington Simpasa',
      presidentEmail: 'president@conference.org',
      presidentPhone: '+260 211 251234',
      headquartersCity: 'Lusaka',
      unionName: 'Southern Zambia Union Conference (SZUC)',
      address: 'Plot 3025, Independence Avenue, Lusaka',
      phone: '+260 211 251234',
      email: 'info@lusakaconference.org',
      createdAt: '2026-01-01T00:00:00.000Z'
    },
    {
      id: 'conf-midlands',
      name: 'Midlands Conference',
      presidentName: 'Pastor C. M. Mulenga',
      presidentEmail: 'president@midlands.org',
      headquartersCity: 'Kabwe',
      unionName: 'Southern Zambia Union Conference (SZUC)',
      phone: '+260 215 222100',
      createdAt: '2026-01-01T00:00:00.000Z'
    },
    {
      id: 'conf-copperbelt',
      name: 'Copperbelt Conference',
      presidentName: 'Pastor S. K. Chilufya',
      presidentEmail: 'president@copperbelt.org',
      headquartersCity: 'Ndola',
      unionName: 'Northern Zambia Union Conference (NZUC)',
      phone: '+260 212 612300',
      createdAt: '2026-01-01T00:00:00.000Z'
    }
  ],
  districts: [
    {
      id: 'dist-woodlands',
      name: 'Woodlands District',
      conferenceId: 'conf-lusaka',
      conferenceName: 'Lusaka Conference',
      pastorName: 'Pastor Kelvin Mwale',
      pastorEmail: 'pastor@district.org',
      pastorPhone: '+260 977 888111',
      headquartersChurchId: 'church-woodlands',
      createdAt: '2026-01-01T00:00:00.000Z'
    },
    {
      id: 'dist-central',
      name: 'Central Lusaka District',
      conferenceId: 'conf-lusaka',
      conferenceName: 'Lusaka Conference',
      pastorName: 'Pastor Emmanuel Lungu',
      pastorEmail: 'pastor.lungu@district.org',
      pastorPhone: '+260 977 777222',
      createdAt: '2026-01-01T00:00:00.000Z'
    },
    {
      id: 'dist-matero',
      name: 'Matero District',
      conferenceId: 'conf-lusaka',
      conferenceName: 'Lusaka Conference',
      pastorName: 'Pastor David Banda',
      pastorEmail: 'pastor.banda@district.org',
      pastorPhone: '+260 977 666333',
      createdAt: '2026-01-01T00:00:00.000Z'
    }
  ],
  superAdmins: [
    {
      id: 'superadmin-1',
      name: 'Elder Dr. G. T. Ngwira',
      email: 'superadmin@sda.org',
      password: 'admin123',
      role: 'SUPER_ADMIN',
      title: 'System Super Admin (Overall Portal Overseer)',
      phone: '+260 977 999000',
      status: 'active'
    }
  ],
  conferencePresidents: [
    {
      id: 'president-1',
      name: 'Pastor Dr. Harrington Simpasa',
      email: 'president@conference.org',
      password: 'president123',
      role: 'CONFERENCE_PRESIDENT',
      conferenceId: 'conf-lusaka',
      conferenceName: 'Lusaka Conference',
      title: 'Conference President (Executive Overseer)',
      phone: '+260 977 555444',
      status: 'active'
    }
  ],
  districtPastors: [
    {
      id: 'pastor-1',
      name: 'Pastor Kelvin Mwale',
      email: 'pastor@district.org',
      password: 'pastor123',
      role: 'DISTRICT_PASTOR',
      conferenceId: 'conf-lusaka',
      conferenceName: 'Lusaka Conference',
      districtId: 'dist-woodlands',
      districtName: 'Woodlands District',
      churchId: 'church-woodlands',
      churchName: 'Woodlands SDA Church',
      title: 'District Pastor (Pastoral Overseer)',
      phone: '+260 977 888111',
      status: 'active'
    }
  ],
  churches: [
    {
      id: 'church-woodlands',
      name: 'Woodlands SDA Church',
      conference: 'Lusaka Conference',
      conferenceId: 'conf-lusaka',
      district: 'Woodlands District',
      districtId: 'dist-woodlands',
      city: 'Lusaka',
      address: 'Woodlands Main Road, Lusaka, Zambia',
      phone: '+260 211 254890',
      email: 'woodlands@church.org',
      elderName: 'Elder M. S. Banda',
      elderEmail: 'elder@church.org',
      pastorName: 'Pastor Kelvin Mwale',
      isDemo: true,
      createdAt: '2026-01-01T00:00:00.000Z'
    }
  ],
  churchAdmins: [
    {
      id: 'elder-1',
      name: 'Elder M. S. Banda',
      email: 'elder@church.org',
      password: 'elder123',
      role: 'CHURCH_ADMIN',
      churchId: 'church-woodlands',
      churchName: 'Woodlands SDA Church',
      title: 'Church Admin Elder (Main Admin)',
      phone: '+260 977 100200'
    }
  ],
  clerks: [
    {
      id: 'clerk-1',
      name: 'Sister P. Tembo',
      email: 'clerk@church.org',
      password: 'clerk123',
      role: 'CLERK',
      churchId: 'church-woodlands',
      churchName: 'Woodlands SDA Church',
      title: 'Church Clerk (Secretariat)',
      phone: '+260 977 200300'
    }
  ],
  admins: [
    {
      id: 'elder-1',
      name: 'Elder M. S. Banda',
      email: 'elder@church.org',
      password: 'elder123',
      role: 'CHURCH_ADMIN',
      churchId: 'church-woodlands',
      churchName: 'Woodlands SDA Church',
      title: 'Church Admin Elder (Main Admin)',
      phone: '+260 977 100200'
    },
    {
      id: 'clerk-1',
      name: 'Sister P. Tembo',
      email: 'clerk@church.org',
      password: 'clerk123',
      role: 'CLERK',
      churchId: 'church-woodlands',
      churchName: 'Woodlands SDA Church',
      title: 'Church Clerk (Secretariat)',
      phone: '+260 977 200300'
    }
  ],
  teachers: [
    { id: 't1', name: 'Elder Musonda', email: 'musonda@church.org', password: 'password123', role: 'TEACHER', assignedClass: 'c1', language: 'English', churchId: 'church-woodlands', churchName: 'Woodlands SDA Church' },
    { id: 't2', name: 'Sister Chanda', email: 'chanda@church.org', password: 'password123', role: 'TEACHER', assignedClass: 'c2', churchId: 'church-woodlands', churchName: 'Woodlands SDA Church' },
    { id: 't3', name: 'Brother Mwale', email: 'mwale@church.org', password: 'password123', role: 'TEACHER', assignedClass: 'c3', churchId: 'church-woodlands', churchName: 'Woodlands SDA Church' }
  ],
  superintendents: [
    {
      id: 'superintendent-1',
      name: 'Sister R. Simpasa',
      email: 'superintendent@church.org',
      password: 'superintendent123',
      role: 'SUPERINTENDENT',
      churchId: 'church-woodlands',
      churchName: 'Woodlands SDA Church'
    }
  ],
  treasurers: [
    {
      id: 'treasurer-1',
      name: 'Elder Joseph Banda',
      email: 'treasurer@church.org',
      password: 'treasurer123',
      role: 'TREASURER',
      churchId: 'church-woodlands',
      churchName: 'Woodlands SDA Church'
    }
  ],
  classes: [
    {
      id: 'c1',
      name: 'Adult Sabbath School',
      language: 'English',
      teacherId: 't1',
      churchId: 'church-woodlands',
      students: [
        { id: 's1', name: 'Alice Walker', classId: 'c1', attendanceStatus: 'unmarked', memberId: 'mem-1' },
        { id: 's2', name: 'Robert Miller', classId: 'c1', attendanceStatus: 'unmarked', memberId: 'mem-2' }
      ]
    },
    {
      id: 'c2',
      name: 'Youth Ministry',
      teacherId: 't2',
      churchId: 'church-woodlands',
      students: [
        { id: 's3', name: 'Sarah Jenkins', classId: 'c2', attendanceStatus: 'unmarked', memberId: 'mem-3' }
      ]
    },
    {
      id: 'c3',
      name: 'Primary Class',
      teacherId: 't3',
      churchId: 'church-woodlands',
      students: [
        { id: 's4', name: 'Little Timmy', classId: 'c3', attendanceStatus: 'unmarked', memberId: 'mem-4' }
      ]
    }
  ],
  churchMembers: [
    {
      id: 'mem-1',
      name: 'Alice Walker',
      memberNumber: 'WDL-2024-001',
      givenNames: 'Alice',
      primarySurname: 'Walker',
      churchId: 'admin-1',
      status: 'active',
      baptismDate: '2015-06-20',
      dob: '1988-04-12',
      gender: 'female',
      contact: '+260 97 1234567',
      email: 'alice.w@example.com',
      address: 'Plot 42, Woodlands Extension, Lusaka',
      familyUnitId: 'fam-1',
      relationshipToHead: 'Head of Household',
      memberType: 'baptized',
      outreachFlag: false,
      lastAttendDate: '2026-09-05'
    },
    {
      id: 'mem-2',
      name: 'Robert Miller',
      memberNumber: 'WDL-2024-002',
      givenNames: 'Robert',
      primarySurname: 'Miller',
      churchId: 'admin-1',
      status: 'active',
      baptismDate: '2010-11-14',
      dob: '1982-08-30',
      gender: 'male',
      contact: '+260 96 9876543',
      email: 'robert.m@example.com',
      address: '14 Kabulonga Road, Lusaka',
      familyUnitId: 'fam-2',
      relationshipToHead: 'Head of Household',
      memberType: 'baptized',
      outreachFlag: false,
      lastAttendDate: '2026-09-12'
    },
    {
      id: 'mem-3',
      name: 'Sarah Jenkins',
      memberNumber: 'WDL-2024-003',
      givenNames: 'Sarah',
      primarySurname: 'Jenkins',
      churchId: 'admin-1',
      status: 'active',
      baptismDate: '2021-04-10',
      dob: '2004-01-15',
      gender: 'female',
      contact: '+260 95 5551234',
      email: 'sarah.j@example.com',
      address: 'Plot 10, Chilenje South, Lusaka',
      familyUnitId: 'fam-3',
      relationshipToHead: 'Child',
      memberType: 'baptized',
      outreachFlag: false,
      lastAttendDate: '2026-09-12'
    },
    {
      id: 'mem-4',
      name: 'Little Timmy',
      memberNumber: 'WDL-2024-004',
      givenNames: 'Timothy',
      primarySurname: 'Chanda',
      churchId: 'admin-1',
      status: 'active',
      dob: '2017-09-22',
      gender: 'male',
      address: 'Plot 8, Nyumba Yanga, Lusaka',
      familyUnitId: 'fam-4',
      relationshipToHead: 'Child',
      memberType: 'unbaptized_child',
      outreachFlag: false,
      lastAttendDate: '2026-09-12'
    }
  ],
  studyGuideOrders: [
    {
      id: 'sgo-1',
      churchId: 'admin-1',
      orderNumber: 'SGO-2026-001',
      memberId: 'mem-1',
      memberName: 'Sister Alice Walker',
      memberContact: '+260 97 1234567',
      memberEmail: 'alice.w@example.com',
      guideType: 'Adult Sabbath School Study Guide (Standard)',
      quarter: 'Q4 2026',
      quantity: 2,
      unitPrice: 45,
      totalAmount: 90,
      paymentStatus: 'paid',
      paymentMethod: 'Mobile Money',
      orderStatus: 'received_from_abc',
      orderDate: '2026-09-02',
      notes: '1 English Standard and 1 Large Print requested.'
    },
    {
      id: 'sgo-2',
      churchId: 'admin-1',
      orderNumber: 'SGO-2026-002',
      memberId: 'mem-2',
      memberName: 'Elder Robert Miller',
      memberContact: '+260 96 9876543',
      memberEmail: 'robert.m@example.com',
      guideType: 'Sabbath School Teachers Edition',
      quarter: 'Q4 2026',
      quantity: 1,
      unitPrice: 65,
      totalAmount: 65,
      paymentStatus: 'paid',
      paymentMethod: 'Cash',
      orderStatus: 'distributed',
      orderDate: '2026-09-04',
      notes: 'Handed over during Teachers Council meeting.'
    }
  ],
  announcements: [
    {
      id: 'a1',
      teacherId: 't1',
      teacherName: 'Elder Musonda',
      className: 'Adult Sabbath School',
      content: 'Please study Lesson 11 daily. Sabbath School begins promptly at 08:30 AM with song service.',
      timestamp: '2026-09-12T08:00:00Z',
      status: 'approved'
    }
  ],
  attendanceRecords: [],
  familyUnits: [
    {
      id: 'fam-1',
      churchId: 'admin-1',
      familyName: 'Walker Household',
      primaryContactId: 'mem-1',
      primaryContactName: 'Alice Walker',
      address: 'Plot 42, Woodlands Extension, Lusaka',
      contactPhone: '+260 97 1234567'
    }
  ],
  meetings: [],
  officers: [],
  transferRequests: [],
  bankAccounts: [],
  remittances: [],
  ssTransmissions: [],
  disbursements: [],
  auxiliaryDepartments: [],
  envelopes: [],
  looseOfferings: [],
  literatureOrders: [],
  auditRecords: []
};
