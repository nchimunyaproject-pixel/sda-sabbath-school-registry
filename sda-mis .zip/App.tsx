import React, { useState, useEffect, useMemo } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { 
  Role, User, Class, Announcement, AttendanceRecord, Student, 
  ChurchMember, FamilyUnit, ChurchMeeting, ChurchOfficer, TransferRequest,
  ChurchBankAccount, OfferingEnvelope, LooseOfferingRecord, SabbathSchoolTransmission,
  DisbursementRecord, AuxiliaryDepartment, ConferenceRemittance, LiteratureOrder, AuditRecord,
  MobilisationPlanItem, ConferenceEmphases, SSCurriculumItem, SSProgramRunSheet,
  SSCouncilMember, SSAuxiliaryOfficer, SSTeacherCandidate, SSTeachersMeeting,
  SSEvangelismProject, SSGreetingSchedule, SSQuarterlyReport, SSClassSession,
  FinancialTransmission, StudyGuideOrder, ChurchStation, Conference, District
} from './types.ts';
import { 
  INITIAL_TEACHERS, INITIAL_CLASSES, INITIAL_FAMILY_UNITS, 
  INITIAL_MEETINGS, INITIAL_OFFICERS, INITIAL_CHURCH_MEMBERS, 
  INITIAL_TRANSFER_REQUESTS, INITIAL_TREASURER, INITIAL_BANK_ACCOUNTS,
  INITIAL_AUXILIARY_DEPARTMENTS, INITIAL_ENVELOPES, INITIAL_LOOSE_OFFERINGS,
  INITIAL_SS_TRANSMISSIONS, INITIAL_DISBURSEMENTS, INITIAL_CONFERENCE_REMITTANCES,
  INITIAL_LITERATURE_ORDERS, INITIAL_AUDIT_RECORDS,
  INITIAL_SUPERINTENDENT, INITIAL_MOBILISATION_PLAN, INITIAL_CONFERENCE_EMPHASES,
  INITIAL_CURRICULUM_INVENTORY, INITIAL_PROGRAM_RUN_SHEET, INITIAL_COUNCIL_MEMBERS,
  INITIAL_AUXILIARY_OFFICERS, INITIAL_TEACHER_CANDIDATES, INITIAL_TEACHERS_MEETINGS,
  INITIAL_EVANGELISM_PROJECTS, INITIAL_STUDY_GUIDE_ORDERS,
  INITIAL_CHURCH_ADMIN, INITIAL_CLERK, INITIAL_CHURCHES,
  INITIAL_CONFERENCES, INITIAL_DISTRICTS, INITIAL_SUPER_ADMIN,
  INITIAL_CONFERENCE_PRESIDENT, INITIAL_DISTRICT_PASTOR
} from './constants.ts';
import LoginPage from './pages/LoginPage.tsx';
import SignupPage from './pages/SignupPage.tsx';
import ClerkDashboard from './pages/ClerkDashboard.tsx';
import TeacherDashboard from './pages/TeacherDashboard.tsx';
import { TreasurerDashboard } from './pages/TreasurerDashboard.tsx';
import { SuperintendentDashboard } from './pages/SuperintendentDashboard.tsx';
import { ChurchAdminDashboard } from './pages/ChurchAdminDashboard.tsx';
import { SuperAdminDashboard } from './pages/SuperAdminDashboard.tsx';
import { ConferenceDashboard } from './pages/ConferenceDashboard.tsx';
import { DistrictDashboard } from './pages/DistrictDashboard.tsx';
import Navigation from './components/Navigation.tsx';
import ProfileModal from './components/ProfileModal.tsx';
import ClientPitchModal from './components/ClientPitchModal.tsx';
import SDALogo from './components/SDALogo.tsx';
import { DatabaseZap, ShieldCheck, ArrowLeft, Building2 } from 'lucide-react';

const BACKEND_URL = '/api';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [conferences, setConferences] = useState<Conference[]>(INITIAL_CONFERENCES);
  const [districts, setDistricts] = useState<District[]>(INITIAL_DISTRICTS);
  const [superAdmins, setSuperAdmins] = useState<User[]>([INITIAL_SUPER_ADMIN]);
  const [conferencePresidents, setConferencePresidents] = useState<User[]>([INITIAL_CONFERENCE_PRESIDENT]);
  const [districtPastors, setDistrictPastors] = useState<User[]>([INITIAL_DISTRICT_PASTOR]);
  const [churches, setChurches] = useState<ChurchStation[]>(INITIAL_CHURCHES);
  const [activeChurchId, setActiveChurchId] = useState<string>(INITIAL_CHURCHES[0].id);
  const [churchAdmins, setChurchAdmins] = useState<User[]>([INITIAL_CHURCH_ADMIN]);
  const [clerks, setClerks] = useState<User[]>([INITIAL_CLERK]);
  const [admins, setAdmins] = useState<User[]>([INITIAL_CHURCH_ADMIN, INITIAL_CLERK]);
  const [elderInspectionRole, setElderInspectionRole] = useState<Role | null>(null);
  const [teachers, setTeachers] = useState<User[]>(INITIAL_TEACHERS);
  const [classes, setClasses] = useState<Class[]>(INITIAL_CLASSES.map(c => ({ ...c, churchId: 'church-woodlands' })));
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [transferRequests, setTransferRequests] = useState<TransferRequest[]>(INITIAL_TRANSFER_REQUESTS);
  const [churchMembers, setChurchMembers] = useState<ChurchMember[]>(INITIAL_CHURCH_MEMBERS);
  const [familyUnits, setFamilyUnits] = useState<FamilyUnit[]>(INITIAL_FAMILY_UNITS);
  const [meetings, setMeetings] = useState<ChurchMeeting[]>(INITIAL_MEETINGS);
  const [officers, setOfficers] = useState<ChurchOfficer[]>(INITIAL_OFFICERS);

  // Financial and Custodianship State (SDA Church Manual)
  const [treasurers, setTreasurers] = useState<User[]>([INITIAL_TREASURER]);
  const [bankAccounts, setBankAccounts] = useState<ChurchBankAccount[]>(INITIAL_BANK_ACCOUNTS);
  const [remittances, setRemittances] = useState<ConferenceRemittance[]>(INITIAL_CONFERENCE_REMITTANCES);
  const [ssTransmissions, setSsTransmissions] = useState<SabbathSchoolTransmission[]>(INITIAL_SS_TRANSMISSIONS);
  const [disbursements, setDisbursements] = useState<DisbursementRecord[]>(INITIAL_DISBURSEMENTS);
  const [auxiliaryDepartments, setAuxiliaryDepartments] = useState<AuxiliaryDepartment[]>(INITIAL_AUXILIARY_DEPARTMENTS);
  const [envelopes, setEnvelopes] = useState<OfferingEnvelope[]>(INITIAL_ENVELOPES);
  const [looseOfferings, setLooseOfferings] = useState<LooseOfferingRecord[]>(INITIAL_LOOSE_OFFERINGS);
  const [literatureOrders, setLiteratureOrders] = useState<LiteratureOrder[]>(INITIAL_LITERATURE_ORDERS);
  const [auditRecords, setAuditRecords] = useState<AuditRecord[]>(INITIAL_AUDIT_RECORDS);

  // Superintendent Department State (SDA Church Manual & GC Sabbath School Standards)
  const [superintendents, setSuperintendents] = useState<User[]>([INITIAL_SUPERINTENDENT]);
  const [mobilisationPlan, setMobilisationPlan] = useState<MobilisationPlanItem[]>(INITIAL_MOBILISATION_PLAN);
  const [conferenceEmphases, setConferenceEmphases] = useState<ConferenceEmphases>(INITIAL_CONFERENCE_EMPHASES);
  const [curriculumInventory, setCurriculumInventory] = useState<SSCurriculumItem[]>(INITIAL_CURRICULUM_INVENTORY);
  const [programRunSheet, setProgramRunSheet] = useState<SSProgramRunSheet>(INITIAL_PROGRAM_RUN_SHEET);
  const [councilMembers, setCouncilMembers] = useState<SSCouncilMember[]>(INITIAL_COUNCIL_MEMBERS);
  const [auxiliaryOfficers, setAuxiliaryOfficers] = useState<SSAuxiliaryOfficer[]>(INITIAL_AUXILIARY_OFFICERS);
  const [teacherCandidates, setTeacherCandidates] = useState<SSTeacherCandidate[]>(INITIAL_TEACHER_CANDIDATES);
  const [teachersMeetings, setTeachersMeetings] = useState<SSTeachersMeeting[]>(INITIAL_TEACHERS_MEETINGS);
  const [evangelismProjects, setEvangelismProjects] = useState<SSEvangelismProject[]>(INITIAL_EVANGELISM_PROJECTS);
  const [greetingSchedules, setGreetingSchedules] = useState<SSGreetingSchedule[]>([
    {
      id: 'gs-1',
      churchId: 'admin-initial',
      sabbathDate: '2026-09-12',
      division: 'Main Sanctuary Foyer',
      assignedHostesses: ['Sister M. Kalunga (Head Greeter)', 'Brother B. Zulu', 'Sister S. Jenkins'],
      welcomeTheme: 'Rooted in Christ’s Love: A Warm Sabbath Welcome to All Guests',
      status: 'scheduled'
    },
    {
      id: 'gs-2',
      churchId: 'admin-initial',
      sabbathDate: '2026-09-19',
      division: 'Children & Youth Wing Entrance',
      assignedHostesses: ['Sister Alice Walker', 'Brother T. Silwimba'],
      welcomeTheme: 'Youth & Children Welcome with Memory Verse Cards',
      status: 'scheduled'
    }
  ]);
  const [quarterlyReport, setQuarterlyReport] = useState<SSQuarterlyReport>({
    id: 'rep-q3-2026',
    churchId: 'admin-initial',
    quarter: 'Q3',
    year: 2026,
    totalEnrollment: 320,
    averageAttendance: 283,
    dailyStudyPercentage: 78,
    missionOfferingsTotal: 28450,
    branchSabbathSchoolsCount: 2,
    baptismsFromSS: 14,
    isClassRegisterAudited: true,
    isDailyStudyCalculated: true,
    isOfferingsReconciled: true,
    isSuperintendentSigned: true,
    isSecretarySigned: true,
    isTransmittedToConference: false,
  });
  const [classSessions, setClassSessions] = useState<SSClassSession[]>([
    {
      id: 'cs-1',
      classId: 'c1',
      className: 'Adult Sabbath School',
      date: '2026-09-05',
      attendanceCount: 45,
      dailyLessonStudyCount: 36,
      missionOfferingAmount: 850,
      teacherName: 'Elder Musonda'
    },
    {
      id: 'cs-2',
      classId: 'c2',
      className: 'Youth Ministry',
      date: '2026-09-05',
      attendanceCount: 28,
      dailyLessonStudyCount: 22,
      missionOfferingAmount: 420,
      teacherName: 'Sister Chanda'
    },
    {
      id: 'cs-3',
      classId: 'c3',
      className: 'Primary Class',
      date: '2026-09-05',
      attendanceCount: 22,
      dailyLessonStudyCount: 19,
      missionOfferingAmount: 260,
      teacherName: 'Brother Mwale'
    }
  ]);

  const [studyGuideOrders, setStudyGuideOrders] = useState<StudyGuideOrder[]>(INITIAL_STUDY_GUIDE_ORDERS);

  const [isBackendConnected, setIsBackendConnected] = useState(false);
  const [dbError, setDbError] = useState<string | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isPitchModalOpen, setIsPitchModalOpen] = useState(false);

  // Initial Data Load
  useEffect(() => {
    const initializeApp = async () => {
      let backendDataFetched = false;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000);

      try {
        const response = await fetch(`${BACKEND_URL}/data`, {
          signal: controller.signal
        });
        
        if (response.ok) {
          const data = await response.json();
          if (data.conferences?.length) setConferences(data.conferences);
          if (data.districts?.length) setDistricts(data.districts);
          if (data.superAdmins?.length) setSuperAdmins(data.superAdmins);
          if (data.conferencePresidents?.length) setConferencePresidents(data.conferencePresidents);
          if (data.districtPastors?.length) setDistrictPastors(data.districtPastors);
          if (data.churches?.length) {
            setChurches(data.churches);
          }
          const cAdmins = data.churchAdmins?.length ? data.churchAdmins : [INITIAL_CHURCH_ADMIN];
          const clk = data.clerks?.length ? data.clerks : [INITIAL_CLERK];
          setChurchAdmins(cAdmins);
          setClerks(clk);
          setAdmins(data.admins?.length ? data.admins : [...cAdmins, ...clk]);
          setTeachers(data.teachers || INITIAL_TEACHERS);
          setClasses(data.classes || INITIAL_CLASSES);
          setAnnouncements(data.announcements || []);
          setAttendanceRecords(data.attendanceRecords || []);
          setTransferRequests(data.transferRequests?.length ? data.transferRequests : INITIAL_TRANSFER_REQUESTS);
          setChurchMembers(data.churchMembers?.length ? data.churchMembers : INITIAL_CHURCH_MEMBERS);
          setFamilyUnits(data.familyUnits?.length ? data.familyUnits : INITIAL_FAMILY_UNITS);
          setMeetings(data.meetings?.length ? data.meetings : INITIAL_MEETINGS);
          setOfficers(data.officers?.length ? data.officers : INITIAL_OFFICERS);
          if (data.treasurers?.length) setTreasurers(data.treasurers);
          if (data.superintendents?.length) setSuperintendents(data.superintendents);
          setIsBackendConnected(true);
          setDbError(null);
          backendDataFetched = true;
        } else if (response.status === 500) {
          setDbError("MySQL Database Connection Failed. Please start MySQL in XAMPP.");
          setIsBackendConnected(true); // Server is there, but DB is dead
        }
      } catch (err) {
        console.warn("Backend not detected. Falling back to local storage.");
      } finally {
        clearTimeout(timeoutId);
      }

      // If backend failed, try local storage
      if (!backendDataFetched) {
        const savedData = localStorage.getItem('sda_registry_full_data');
        if (savedData) {
          try {
            const parsed = JSON.parse(savedData);
            if (parsed.conferences?.length) setConferences(parsed.conferences);
            if (parsed.districts?.length) setDistricts(parsed.districts);
            if (parsed.superAdmins?.length) setSuperAdmins(parsed.superAdmins);
            if (parsed.conferencePresidents?.length) setConferencePresidents(parsed.conferencePresidents);
            if (parsed.districtPastors?.length) setDistrictPastors(parsed.districtPastors);
            if (parsed.churches?.length) setChurches(parsed.churches);
            const cAdmins = parsed.churchAdmins?.length ? parsed.churchAdmins : [INITIAL_CHURCH_ADMIN];
            const clk = parsed.clerks?.length ? parsed.clerks : [INITIAL_CLERK];
            setChurchAdmins(cAdmins);
            setClerks(clk);
            setAdmins(parsed.admins?.length ? parsed.admins : [...cAdmins, ...clk]);
            setTeachers(parsed.teachers || INITIAL_TEACHERS);
            setClasses(parsed.classes || INITIAL_CLASSES);
            setAnnouncements(parsed.announcements || []);
            setAttendanceRecords(parsed.attendanceRecords || []);
            setTransferRequests(parsed.transferRequests?.length ? parsed.transferRequests : INITIAL_TRANSFER_REQUESTS);
            setChurchMembers(parsed.churchMembers?.length ? parsed.churchMembers : INITIAL_CHURCH_MEMBERS);
            setFamilyUnits(parsed.familyUnits?.length ? parsed.familyUnits : INITIAL_FAMILY_UNITS);
            setMeetings(parsed.meetings?.length ? parsed.meetings : INITIAL_MEETINGS);
            setOfficers(parsed.officers?.length ? parsed.officers : INITIAL_OFFICERS);
            setTreasurers(parsed.treasurers?.length ? parsed.treasurers : [INITIAL_TREASURER]);
            setSuperintendents(parsed.superintendents?.length ? parsed.superintendents : [INITIAL_SUPERINTENDENT]);
            setBankAccounts(parsed.bankAccounts?.length ? parsed.bankAccounts : INITIAL_BANK_ACCOUNTS);
            setRemittances(parsed.remittances?.length ? parsed.remittances : INITIAL_CONFERENCE_REMITTANCES);
            setSsTransmissions(parsed.ssTransmissions?.length ? parsed.ssTransmissions : INITIAL_SS_TRANSMISSIONS);
            setDisbursements(parsed.disbursements?.length ? parsed.disbursements : INITIAL_DISBURSEMENTS);
            setAuxiliaryDepartments(parsed.auxiliaryDepartments?.length ? parsed.auxiliaryDepartments : INITIAL_AUXILIARY_DEPARTMENTS);
            setEnvelopes(parsed.envelopes?.length ? parsed.envelopes : INITIAL_ENVELOPES);
            setLooseOfferings(parsed.looseOfferings?.length ? parsed.looseOfferings : INITIAL_LOOSE_OFFERINGS);
            setLiteratureOrders(parsed.literatureOrders?.length ? parsed.literatureOrders : INITIAL_LITERATURE_ORDERS);
            setAuditRecords(parsed.auditRecords?.length ? parsed.auditRecords : INITIAL_AUDIT_RECORDS);
          } catch (e) {
            console.error("Local data parse error");
          }
        }
      }

      // Restore session
      const savedUser = localStorage.getItem('sda_current_user');
      if (savedUser) {
        try {
          const parsedUser = JSON.parse(savedUser);
          setCurrentUser(parsedUser);
          if (parsedUser.churchId) {
            setActiveChurchId(parsedUser.churchId);
          }
        } catch (e) {
          localStorage.removeItem('sda_current_user');
        }
      }
      
      setIsLoading(false);
    };

    initializeApp();
  }, []);

  // Sync Data Effect
  useEffect(() => {
    if (isLoading || dbError) return;

    const syncData = async () => {
      const dataToSync = { 
        conferences, districts, superAdmins, conferencePresidents, districtPastors,
        churches, churchAdmins, clerks, admins, teachers, classes, announcements, attendanceRecords, 
        transferRequests, churchMembers, familyUnits, meetings, officers,
        treasurers, superintendents, bankAccounts, remittances, ssTransmissions, disbursements,
        auxiliaryDepartments, envelopes, looseOfferings, literatureOrders, auditRecords,
        studyGuideOrders
      };
      localStorage.setItem('sda_registry_full_data', JSON.stringify(dataToSync));
      
      if (isBackendConnected) {
        try {
          const res = await fetch(`${BACKEND_URL}/sync`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dataToSync),
          });
          if (!res.ok) throw new Error("Sync failed");
          setDbError(null);
        } catch (err) {
          console.error("Sync failed:", err);
          if (err instanceof TypeError) setIsBackendConnected(false);
        }
      }
    };

    const debounceSync = setTimeout(syncData, 1000);
    return () => clearTimeout(debounceSync);
  }, [
    conferences, districts, superAdmins, conferencePresidents, districtPastors,
    churches, churchAdmins, clerks, admins, teachers, classes, announcements, attendanceRecords, isBackendConnected, 
    isLoading, dbError, churchMembers, familyUnits, meetings, officers, transferRequests,
    treasurers, superintendents, bankAccounts, remittances, ssTransmissions, disbursements,
    auxiliaryDepartments, envelopes, looseOfferings, literatureOrders, auditRecords, studyGuideOrders
  ]);

  const handleAddConference = (newConf: Conference, newPres: User) => {
    setConferences(prev => {
      const exists = prev.some(c => c.id === newConf.id);
      return exists ? prev.map(c => c.id === newConf.id ? newConf : c) : [...prev, newConf];
    });
    setConferencePresidents(prev => [...prev.filter(p => p.id !== newPres.id), newPres]);
  };

  const handleAddDistrict = (newDist: District, newPastor: User) => {
    setDistricts(prev => {
      const exists = prev.some(d => d.id === newDist.id);
      return exists ? prev.map(d => d.id === newDist.id ? newDist : d) : [...prev, newDist];
    });
    setDistrictPastors(prev => [...prev.filter(p => p.id !== newPastor.id), newPastor]);
  };

  const handleRegisterChurch = (
    newChurch: ChurchStation, 
    newElder: User, 
    initialSetupType: 'blank' | 'standard_classes'
  ) => {
    setChurches(prev => {
      const exists = prev.some(c => c.id === newChurch.id);
      return exists ? prev.map(c => c.id === newChurch.id ? newChurch : c) : [...prev, newChurch];
    });
    setChurchAdmins(prev => [...prev.filter(a => a.id !== newElder.id), newElder]);
    setAdmins(prev => [...prev.filter(a => a.id !== newElder.id), newElder]);
    setActiveChurchId(newChurch.id);

    if (initialSetupType === 'standard_classes') {
      const standardDivisions = [
        { id: `c-${newChurch.id}-cradle`, name: 'Cradle Roll (0-2 yrs)' },
        { id: `c-${newChurch.id}-kinder`, name: 'Kindergarten (3-5 yrs)' },
        { id: `c-${newChurch.id}-primary`, name: 'Primary Class (6-9 yrs)' },
        { id: `c-${newChurch.id}-junior`, name: 'Junior Class (10-12 yrs)' },
        { id: `c-${newChurch.id}-earliteen`, name: 'Earliteen (13-14 yrs)' },
        { id: `c-${newChurch.id}-youth`, name: 'Youth Ministry (15-30 yrs)' },
        { id: `c-${newChurch.id}-adult`, name: 'Adult Sabbath School' }
      ];
      const initialClassesForChurch: Class[] = standardDivisions.map(div => ({
        id: div.id,
        name: div.name,
        teacherId: '',
        language: 'English',
        churchId: newChurch.id,
        students: []
      }));
      setClasses(prev => [...prev, ...initialClassesForChurch]);
    }
  };

  const handleSignup = (user: User) => {
    setAdmins(prev => [...prev, user]);
    if (user.role === Role.CHURCH_ADMIN) {
      setChurchAdmins(prev => [...prev, user]);
    } else if (user.role === Role.CLERK) {
      setClerks(prev => [...prev, user]);
    }
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setElderInspectionRole(null);
    localStorage.setItem('sda_current_user', JSON.stringify(user));
    
    // Automatically scope session to user's registered church
    if (user.churchId) {
      setActiveChurchId(user.churchId);
    } else if (user.churchName) {
      const found = churches.find(c => c.name.toLowerCase() === user.churchName?.toLowerCase());
      if (found) setActiveChurchId(found.id);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setElderInspectionRole(null);
    localStorage.removeItem('sda_current_user');
  };

  // CHURCH ADMIN ELDER: Appoint Church Officers (Clerk, Superintendent, Treasurer, Teacher)
  const handleAddOfficerByElder = (officerData: {
    name: string;
    email: string;
    password: string;
    role: Role;
    phone?: string;
    assignedClass?: string;
    language?: string;
    title?: string;
    churchName?: string;
  }) => {
    const newId = `${officerData.role.toLowerCase()}-${Date.now()}`;
    const newOfficer: User = {
      id: newId,
      name: officerData.name,
      email: officerData.email,
      password: officerData.password,
      role: officerData.role,
      phone: officerData.phone,
      title: officerData.title,
      churchId: currentUser?.churchId || activeChurchId,
      churchName: officerData.churchName || currentUser?.churchName || 'Woodlands SDA Church',
      assignedClass: officerData.assignedClass,
      language: officerData.language,
      status: 'active',
      createdAt: new Date().toISOString()
    };

    if (officerData.role === Role.CLERK) {
      setClerks(prev => [...prev, newOfficer]);
      setAdmins(prev => [...prev, newOfficer]);
    } else if (officerData.role === Role.SUPERINTENDENT) {
      setSuperintendents(prev => [...prev, newOfficer]);
    } else if (officerData.role === Role.TREASURER) {
      setTreasurers(prev => [...prev, newOfficer]);
    } else if (officerData.role === Role.TEACHER) {
      setTeachers(prev => [...prev, newOfficer]);
      if (officerData.assignedClass) {
        setClasses(prev => prev.map(c => {
          if (c.id === officerData.assignedClass) {
            return {
              ...c,
              teacherId: newId,
              language: officerData.language || c.language
            };
          }
          return c;
        }));
      }
    } else if (officerData.role === Role.CHURCH_ADMIN) {
      setChurchAdmins(prev => [...prev, newOfficer]);
      setAdmins(prev => [...prev, newOfficer]);
    }
  };

  const handleUpdateOfficerByElder = (userId: string, updates: Partial<User>) => {
    setClerks(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));
    setAdmins(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));
    setSuperintendents(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));
    setTreasurers(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));
    setTeachers(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));
    setChurchAdmins(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));

    if (currentUser?.id === userId) {
      setCurrentUser(prev => prev ? { ...prev, ...updates } : null);
    }
  };

  const handleDeleteOfficerByElder = (userId: string) => {
    setClerks(prev => prev.filter(u => u.id !== userId));
    setAdmins(prev => prev.filter(u => u.id !== userId));
    setSuperintendents(prev => prev.filter(u => u.id !== userId));
    setTreasurers(prev => prev.filter(u => u.id !== userId));
    setTeachers(prev => prev.filter(u => u.id !== userId));
    setChurchAdmins(prev => prev.filter(u => u.id !== userId));
  };

  const addTeacher = (name: string, email: string, password: string, classId: string, language?: string) => {
    const newId = `t${Date.now()}`;
    const newTeacher: User = {
      id: newId,
      name,
      email,
      password,
      role: Role.TEACHER,
      assignedClass: classId,
      language: language
    };
    
    setTeachers(prev => [...prev, newTeacher]);
    setClasses(prev => prev.map(c => {
      if (c.id === classId) {
        const isAdult = c.name.toLowerCase().includes('adult');
        const baseName = c.name.split(' (')[0]; // Get name without existing language
        const newName = (isAdult && language) ? `${baseName} (${language})` : c.name;
        
        return { 
          ...c, 
          name: newName,
          teacherId: newId, 
          language: language || c.language, 
          churchId: currentUser?.id 
        };
      }
      return c;
    }));
  };

  const updateUserPassword = (userId: string, newPassword: string) => {
    setTeachers(prev => prev.map(t => t.id === userId ? { ...t, password: newPassword } : t));
    setAdmins(prev => prev.map(a => a.id === userId ? { ...a, password: newPassword } : a));
    
    if (currentUser?.id === userId) {
      const updated = { ...currentUser, password: newPassword } as User;
      setCurrentUser(updated);
      localStorage.setItem('sda_current_user', JSON.stringify(updated));
    }
  };

  const addStudentToClass = (classId: string, studentName: string, memberId?: string) => {
    const newStudent: Student = {
      id: `s${Date.now()}`,
      name: studentName,
      classId: classId,
      attendanceStatus: 'unmarked',
      memberId: memberId
    };
    
    setClasses(prev => prev.map(c => {
      if (c.id === classId) {
        return { ...c, students: [...c.students, newStudent] };
      }
      return c;
    }));
  };

  const deleteStudent = (classId: string, studentId: string) => {
    setClasses(prev => prev.map(c => {
      if (c.id === classId) {
        return { ...c, students: c.students.filter(s => s.id !== studentId) };
      }
      return c;
    }));
  };

  const updateTeacher = (teacherId: string, updates: Partial<User>) => {
    setTeachers(prev => prev.map(t => t.id === teacherId ? { ...t, ...updates } : t));
    
    // If the teacher's class or language changed, update the classes list too
    if (updates.assignedClass || updates.language) {
      setClasses(prev => prev.map(c => {
        if (c.teacherId === teacherId) {
          return { 
            ...c, 
            id: updates.assignedClass || c.id,
            language: updates.language || c.language 
          };
        }
        return c;
      }));
    }
  };

  const deleteTeacher = (teacherId: string) => {
    setTeachers(prev => prev.filter(t => t.id !== teacherId));
    setClasses(prev => prev.map(c => c.teacherId === teacherId ? { ...c, teacherId: '' } : c));
  };

  const initiateTransfer = (studentId: string, studentName: string, toChurchId: string, toChurchName: string, reason?: string) => {
    if (!currentUser) return;
    
    const newRequest: TransferRequest = {
      id: `tr-${Date.now()}`,
      studentId,
      studentName,
      fromChurchId: currentUser.id,
      fromChurchName: currentUser.churchName || 'Unknown Church',
      toChurchId,
      toChurchName,
      status: 'pending',
      requestDate: new Date().toISOString(),
      reason
    };

    setTransferRequests(prev => [...prev, newRequest]);
    
    // Mark student as transferring in their current class
    setClasses(prev => prev.map(c => ({
      ...c,
      students: c.students.map(s => s.id === studentId ? { ...s, isTransferring: true } : s)
    })));
  };

  const updateTransferStatus = (requestId: string, status: TransferRequest['status']) => {
    setTransferRequests(prev => prev.map(r => r.id === requestId ? { ...r, status } : r));
    
    if (status === 'approved') {
      const request = transferRequests.find(r => r.id === requestId);
      if (request) {
        // 1. Find the student in the old church's classes
        let studentToMove: Student | null = null;
        let oldClassId: string | null = null;

        classes.forEach(c => {
          const found = c.students.find(s => s.id === request.studentId);
          if (found) {
            studentToMove = found;
            oldClassId = c.id;
          }
        });

        if (studentToMove && oldClassId) {
          // 2. Remove from old class
          setClasses(prev => prev.map(c => {
            if (c.id === oldClassId) {
              return { ...c, students: c.students.filter(s => s.id !== request.studentId) };
            }
            return c;
          }));

          // 3. Add to a default class in the new church
          const targetClerk = admins.find(a => a.id === request.toChurchId);
          if (targetClerk) {
            // Find a class belonging to this church, or create a default one if none exists
            let targetClass = classes.find(c => c.churchId === request.toChurchId);
            
            if (!targetClass) {
              // Create a default "Transferred Members" class for this church
              const newClassId = `c-transferred-${request.toChurchId}`;
              targetClass = {
                id: newClassId,
                name: 'Transferred Members',
                teacherId: '',
                students: [],
                churchId: request.toChurchId
              };
              setClasses(prev => [...prev, targetClass!]);
            }

            const movedStudent: Student = {
              ...(studentToMove as unknown as Student),
              classId: targetClass.id,
              isTransferring: false,
              attendanceStatus: 'unmarked'
            };
            
            setClasses(prev => prev.map(c => {
              if (c.id === targetClass!.id) {
                return { ...c, students: [...c.students, movedStudent] };
              }
              return c;
            }));
          }
        }
      }
    }
  };

  const submitAnnouncement = (announcement: Announcement) => {
    setAnnouncements(prev => [announcement, ...prev]);
  };

  const submitAttendance = (record: AttendanceRecord) => {
    setAttendanceRecords(prev => [record, ...prev]);
    setClasses(prev => prev.map(c => {
      if (c.id === record.classId) {
        return { ...c, students: record.records };
      }
      return c;
    }));
  };

  const addChurchMember = (member: Omit<ChurchMember, 'id' | 'churchId'>) => {
    if (!currentUser) return;
    const newMember: ChurchMember = {
      ...member,
      id: `m-${Date.now()}`,
      churchId: currentUser.churchId || activeChurchId
    };
    setChurchMembers(prev => [...prev, newMember]);
  };

  const updateChurchMember = (memberId: string, updates: Partial<ChurchMember>) => {
    setChurchMembers(prev => prev.map(m => m.id === memberId ? { ...m, ...updates } : m));
  };

  const deleteChurchMember = (memberId: string) => {
    setChurchMembers(prev => prev.filter(m => m.id !== memberId));
  };

  // Family Units Handlers
  const addFamilyUnit = (fam: Omit<FamilyUnit, 'id' | 'churchId'>) => {
    if (!currentUser) return;
    const newFam: FamilyUnit = {
      ...fam,
      id: `fam-${Date.now()}`,
      churchId: currentUser.churchId || activeChurchId
    };
    setFamilyUnits(prev => [...prev, newFam]);
  };

  const updateFamilyUnit = (id: string, updates: Partial<FamilyUnit>) => {
    setFamilyUnits(prev => prev.map(f => f.id === id ? { ...f, ...updates } : f));
  };

  const deleteFamilyUnit = (id: string) => {
    setFamilyUnits(prev => prev.filter(f => f.id !== id));
  };

  // Governance Meetings Handlers
  const addMeeting = (meeting: Omit<ChurchMeeting, 'id' | 'churchId'>) => {
    if (!currentUser) return;
    const newM: ChurchMeeting = {
      ...meeting,
      id: `meet-${Date.now()}`,
      churchId: currentUser.churchId || activeChurchId
    };
    setMeetings(prev => [...prev, newM]);
  };

  const updateMeeting = (id: string, updates: Partial<ChurchMeeting>) => {
    setMeetings(prev => prev.map(m => m.id === id ? { ...m, ...updates } : m));
  };

  const deleteMeeting = (id: string) => {
    setMeetings(prev => prev.filter(m => m.id !== id));
  };

  // Church Officers Handlers
  const addOfficer = (officer: Omit<ChurchOfficer, 'id' | 'churchId'>) => {
    if (!currentUser) return;
    const newO: ChurchOfficer = {
      ...officer,
      id: `off-${Date.now()}`,
      churchId: currentUser.churchId || activeChurchId
    };
    setOfficers(prev => [...prev, newO]);
  };

  const updateOfficer = (id: string, updates: Partial<ChurchOfficer>) => {
    setOfficers(prev => prev.map(o => o.id === id ? { ...o, ...updates } : o));
  };

  const deleteOfficer = (id: string) => {
    setOfficers(prev => prev.filter(o => o.id !== id));
  };

  // Enhanced Transfer Stage Updates (with metadata)
  const updateTransferStage = (requestId: string, status: TransferRequest['status'], extra?: Partial<TransferRequest>) => {
    setTransferRequests(prev => prev.map(r => {
      if (r.id === requestId) {
        return { ...r, status, ...(extra || {}) };
      }
      return r;
    }));

    if (status === 'approved') {
      updateTransferStatus(requestId, 'approved');
    }
  };

  // Treasurer Financial Handlers
  const handleAddBankAccount = (acc: Omit<ChurchBankAccount, 'id' | 'churchId'>) => {
    const newAccount: ChurchBankAccount = {
      ...acc,
      id: `acc-${Date.now()}`,
      churchId: currentUser?.id || 'admin-initial',
    };
    setBankAccounts(prev => [newAccount, ...prev]);
  };

  const handleReconcileAccount = (id: string, date: string, statementBal: number) => {
    setBankAccounts(prev => prev.map(a => a.id === id ? {
      ...a,
      reconciliationStatus: 'reconciled',
      lastReconciledDate: date,
      currentBalance: statementBal
    } : a));
  };

  const handleCompileRemittance = (remittance: Omit<ConferenceRemittance, 'id' | 'churchId'>) => {
    const newRemit: ConferenceRemittance = {
      ...remittance,
      id: `remit-${Date.now()}`,
      churchId: currentUser?.churchId || activeChurchId,
    };
    setRemittances(prev => [newRemit, ...prev]);
  };

  const handleAcknowledgeReceipt = (id: string, conferenceReceiptNo: string) => {
    setRemittances(prev => prev.map(r => r.id === id ? {
      ...r,
      status: 'remitted_acknowledged',
      conferenceReceiptNumber: conferenceReceiptNo
    } : r));
  };

  const handleRecordSSTransmission = (data: Omit<SabbathSchoolTransmission, 'id' | 'churchId' | 'receiptNumber'>) => {
    const newTrans: SabbathSchoolTransmission = {
      ...data,
      id: `ss-trans-${Date.now()}`,
      churchId: currentUser?.churchId || activeChurchId,
      receiptNumber: `SSR-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`
    };
    setSsTransmissions(prev => [newTrans, ...prev]);
  };

  const handleAddDisbursement = (disbursement: Omit<DisbursementRecord, 'id' | 'churchId' | 'voucherNumber'>) => {
    const newDisb: DisbursementRecord = {
      ...disbursement,
      id: `disb-${Date.now()}`,
      churchId: currentUser?.churchId || activeChurchId,
      voucherNumber: `DIS-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`
    };
    setDisbursements(prev => [newDisb, ...prev]);
    setBankAccounts(prev => prev.map(b => b.accountType === 'operating_checking' ? { ...b, currentBalance: b.currentBalance - disbursement.amount } : b));
    if (disbursement.fundCategory === 'auxiliary') {
      setAuxiliaryDepartments(prev => prev.map(d => d.name === disbursement.fundName ? {
        ...d,
        currentBalance: Math.max(0, d.currentBalance - disbursement.amount)
      } : d));
    }
  };

  const handleReceiveAuxiliaryFunds = (auxId: string, amount: number, _donorNote: string) => {
    setAuxiliaryDepartments(prev => prev.map(a => a.id === auxId ? {
      ...a,
      currentBalance: a.currentBalance + amount
    } : a));
    setBankAccounts(prev => prev.map(b => b.accountType === 'operating_checking' ? { ...b, currentBalance: b.currentBalance + amount } : b));
  };

  const handleAddEnvelope = (envelope: Omit<OfferingEnvelope, 'id' | 'churchId' | 'receiptNumber'>) => {
    const newEnvelope: OfferingEnvelope = {
      ...envelope,
      id: `env-${Date.now()}`,
      churchId: currentUser?.churchId || activeChurchId,
      receiptNumber: `REC-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`
    };
    setEnvelopes(prev => [newEnvelope, ...prev]);
    setBankAccounts(prev => prev.map(b => b.accountType === 'operating_checking' ? { ...b, currentBalance: b.currentBalance + envelope.totalAmount } : b));
  };

  const handleAddLooseOffering = (loose: Omit<LooseOfferingRecord, 'id' | 'churchId' | 'receiptNumber'>) => {
    const newLoose: LooseOfferingRecord = {
      ...loose,
      id: `loose-${Date.now()}`,
      churchId: currentUser?.churchId || activeChurchId,
      receiptNumber: `LCR-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`
    };
    setLooseOfferings(prev => [newLoose, ...prev]);
    setBankAccounts(prev => prev.map(b => b.accountType === 'operating_checking' ? { ...b, currentBalance: b.currentBalance + loose.totalAmount } : b));
  };

  const handleAddLiteratureOrder = (order: Omit<LiteratureOrder, 'id' | 'churchId' | 'orderNumber'>) => {
    const newOrder: LiteratureOrder = {
      ...order,
      id: `lit-${Date.now()}`,
      churchId: currentUser?.churchId || activeChurchId,
      orderNumber: `ABC-${new Date().getFullYear()}-${Date.now().toString().slice(-3)}`
    };
    setLiteratureOrders(prev => [newOrder, ...prev]);
  };

  const handleUpdateLiteratureStatus = (id: string, status: 'collected' | 'remitted_to_abc' | 'delivered', ref?: string) => {
    setLiteratureOrders(prev => prev.map(l => l.id === id ? {
      ...l,
      status,
      ...(ref ? { abcInvoiceRef: ref, remittedToAbcDate: new Date().toISOString().split('T')[0] } : {})
    } : l));
  };

  const handleAddNewAudit = (audit: Omit<AuditRecord, 'id' | 'churchId'>) => {
    const newAudit: AuditRecord = {
      ...audit,
      id: `audit-${Date.now()}`,
      churchId: currentUser?.churchId || activeChurchId,
    };
    setAuditRecords(prev => [newAudit, ...prev]);
  };

  // Superintendent Handlers
  const handleToggleMobilisationItem = (id: string) => {
    setMobilisationPlan(prev => prev.map(m => {
      if (m.id === id) {
        const nextCompleted = !m.isCompleted;
        return {
          ...m,
          isCompleted: nextCompleted,
          completedDate: nextCompleted ? new Date().toISOString().split('T')[0] : undefined
        };
      }
      return m;
    }));
  };

  const handleAddMobilisationItem = (item: Omit<MobilisationPlanItem, 'id'>) => {
    const newItem: MobilisationPlanItem = {
      ...item,
      id: `mob-${Date.now()}`
    };
    setMobilisationPlan(prev => [...prev, newItem]);
  };

  const handleUpdateCurriculum = (id: string, updates: Partial<SSCurriculumItem>) => {
    setCurriculumInventory(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const handleUpdateRunSheet = (updated: SSProgramRunSheet) => {
    setProgramRunSheet(updated);
  };

  const handleAddAuxiliaryOfficer = (officer: Omit<SSAuxiliaryOfficer, 'id'>) => {
    const newOfficer: SSAuxiliaryOfficer = {
      ...officer,
      id: `aux-${Date.now()}`
    };
    setAuxiliaryOfficers(prev => [...prev, newOfficer]);
  };

  const handleUpdateTeacherCandidate = (id: string, updates: Partial<SSTeacherCandidate>) => {
    setTeacherCandidates(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const handleAddTeacherCandidate = (candidate: Omit<SSTeacherCandidate, 'id'>) => {
    const newCandidate: SSTeacherCandidate = {
      ...candidate,
      id: `tc-${Date.now()}`
    };
    setTeacherCandidates(prev => [...prev, newCandidate]);
  };

  const handleAddTeachersMeeting = (meeting: Omit<SSTeachersMeeting, 'id'>) => {
    const newMeeting: SSTeachersMeeting = {
      ...meeting,
      id: `tm-${Date.now()}`
    };
    setTeachersMeetings(prev => [newMeeting, ...prev]);
  };

  const handleAddEvangelismProject = (project: Omit<SSEvangelismProject, 'id'>) => {
    const newProj: SSEvangelismProject = {
      ...project,
      id: `evang-${Date.now()}`
    };
    setEvangelismProjects(prev => [...prev, newProj]);
  };

  const handleUpdateEvangelismProject = (id: string, updates: Partial<SSEvangelismProject>) => {
    setEvangelismProjects(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const handleAddGreetingSchedule = (item: Omit<SSGreetingSchedule, 'id'>) => {
    const newGreet: SSGreetingSchedule = {
      ...item,
      id: `gs-${Date.now()}`
    };
    setGreetingSchedules(prev => [...prev, newGreet]);
  };

  const handleUpdateQuarterlyReport = (updated: Partial<SSQuarterlyReport>) => {
    setQuarterlyReport(prev => ({ ...prev, ...updated }));
  };

  const handleAddStudyGuideOrder = (orderData: Omit<StudyGuideOrder, 'id' | 'churchId' | 'orderNumber'>) => {
    const nextNum = (studyGuideOrders.length + 1).toString().padStart(3, '0');
    const newOrder: StudyGuideOrder = {
      ...orderData,
      id: `sgo-${Date.now()}`,
      churchId: currentUser?.churchId || activeChurchId,
      orderNumber: `SGO-2026-${nextNum}`
    };
    setStudyGuideOrders(prev => [newOrder, ...prev]);
  };

  const handleUpdateStudyGuideOrder = (id: string, updates: Partial<StudyGuideOrder>) => {
    setStudyGuideOrders(prev => prev.map(o => o.id === id ? { ...o, ...updates } : o));
  };

  const handleDeleteStudyGuideOrder = (id: string) => {
    setStudyGuideOrders(prev => prev.filter(o => o.id !== id));
  };

  // Mapped transmissions connecting Sabbath School Secretary to Treasury
  const mappedFinancialTransmissions: FinancialTransmission[] = ssTransmissions.map(st => ({
    id: st.id,
    transmissionRef: st.receiptNumber,
    sabbathDate: st.date,
    breakdown: {
      worldMissionOffering: st.regularMissionOffering,
      thirteenthSabbathOffering: st.thirteenthSabbathOffering,
      birthdayThankOffering: st.birthdayThankOffering,
      missionInvestment: st.missionInvestment,
      sabbathSchoolExpense: st.sabbathSchoolExpense
    },
    totalAmount: st.totalMissionAmount,
    signedBySecretary: st.secretaryName,
    receivedByTreasurer: st.treasurerName,
    status: st.status === 'remitted' ? 'remitted' : 'transmitted'
  }));

  const handleSwitchRole = (newRole: Role) => {
    // Only Church Admin Elder has the authority to inspect or switch role views!
    if (currentUser?.role === Role.CHURCH_ADMIN) {
      if (newRole === Role.CHURCH_ADMIN) {
        setElderInspectionRole(null);
      } else {
        setElderInspectionRole(newRole);
      }
    }
  };

  const handleFastSwitchPersona = (targetRole: Role) => {
    setElderInspectionRole(null);
    let targetUser: User | undefined;
    switch (targetRole) {
      case Role.SUPER_ADMIN:
        targetUser = superAdmins[0] || INITIAL_SUPER_ADMIN;
        break;
      case Role.CONFERENCE_PRESIDENT:
        targetUser = conferencePresidents[0] || INITIAL_CONFERENCE_PRESIDENT;
        break;
      case Role.DISTRICT_PASTOR:
        targetUser = districtPastors[0] || INITIAL_DISTRICT_PASTOR;
        break;
      case Role.CHURCH_ADMIN:
        targetUser = churchAdmins.find(a => a.churchId === activeChurchId) || churchAdmins[0] || INITIAL_CHURCH_ADMIN;
        break;
      case Role.CLERK:
        targetUser = clerks.find(c => c.churchId === activeChurchId) || clerks[0] || INITIAL_CLERK;
        break;
      case Role.TREASURER:
        targetUser = treasurers.find(t => t.churchId === activeChurchId) || treasurers[0] || INITIAL_TREASURER;
        break;
      case Role.SUPERINTENDENT:
        targetUser = superintendents.find(s => s.churchId === activeChurchId) || superintendents[0] || INITIAL_SUPERINTENDENT;
        break;
      case Role.TEACHER:
        targetUser = teachers.find(t => t.churchId === activeChurchId) || teachers[0] || INITIAL_TEACHERS[0];
        break;
    }
    if (targetUser) {
      setCurrentUser(targetUser);
      localStorage.setItem('sda_current_user', JSON.stringify(targetUser));
      if (targetUser.churchId) setActiveChurchId(targetUser.churchId);
    }
  };

  // Compute active church station based on current selection or user's affiliation
  const activeChurch = useMemo(() => {
    return churches.find(c => 
      c.id === activeChurchId || 
      (currentUser?.churchId && c.id === currentUser.churchId) || 
      (currentUser?.churchName && c.name.toLowerCase() === currentUser.churchName.toLowerCase())
    ) || churches[0] || INITIAL_CHURCHES[0];
  }, [churches, activeChurchId, currentUser]);

  // Compute active conference for Conference President or Overseer
  const activeConference = useMemo(() => {
    return conferences.find(c => 
      c.id === currentUser?.conferenceId || 
      c.name.toLowerCase() === currentUser?.conferenceName?.toLowerCase()
    ) || conferences[0] || INITIAL_CONFERENCES[0];
  }, [conferences, currentUser]);

  // Compute active district for District Pastor or Overseer
  const activeDistrict = useMemo(() => {
    return districts.find(d => 
      d.id === currentUser?.districtId || 
      d.name.toLowerCase() === currentUser?.districtName?.toLowerCase()
    ) || districts[0] || INITIAL_DISTRICTS[0];
  }, [districts, currentUser]);

  const isDemoActive = activeChurch.isDemo || activeChurch.id === 'church-woodlands';

  // Scoped datasets: newly registered churches get fresh isolated data; Woodlands gets demo seed
  const scopedMembers = useMemo(() => {
    return churchMembers.filter(m => 
      m.churchId === activeChurch.id || 
      (isDemoActive && (!m.churchId || m.churchId === 'church-woodlands' || m.churchId === 'admin-initial'))
    );
  }, [churchMembers, activeChurch.id, isDemoActive]);

  const scopedClasses = useMemo(() => {
    return classes.filter(c => 
      c.churchId === activeChurch.id || 
      (isDemoActive && (!c.churchId || c.churchId === 'church-woodlands' || c.churchId === 'admin-1' || c.churchId === 'admin-initial'))
    );
  }, [classes, activeChurch.id, isDemoActive]);

  const scopedTeachers = useMemo(() => {
    return teachers.filter(t => 
      t.churchId === activeChurch.id || 
      (isDemoActive && (!t.churchId || t.churchId === 'church-woodlands'))
    );
  }, [teachers, activeChurch.id, isDemoActive]);

  const scopedClerks = useMemo(() => {
    return clerks.filter(c => 
      c.churchId === activeChurch.id || 
      (isDemoActive && (!c.churchId || c.churchId === 'church-woodlands'))
    );
  }, [clerks, activeChurch.id, isDemoActive]);

  const scopedSuperintendents = useMemo(() => {
    return superintendents.filter(s => 
      s.churchId === activeChurch.id || 
      (isDemoActive && (!s.churchId || s.churchId === 'church-woodlands'))
    );
  }, [superintendents, activeChurch.id, isDemoActive]);

  const scopedTreasurers = useMemo(() => {
    return treasurers.filter(t => 
      t.churchId === activeChurch.id || 
      (isDemoActive && (!t.churchId || t.churchId === 'church-woodlands'))
    );
  }, [treasurers, activeChurch.id, isDemoActive]);

  const scopedFamilyUnits = useMemo(() => {
    return familyUnits.filter(f => 
      f.churchId === activeChurch.id || 
      (isDemoActive && (!f.churchId || f.churchId === 'church-woodlands' || f.churchId === 'admin-initial'))
    );
  }, [familyUnits, activeChurch.id, isDemoActive]);

  const scopedTransferRequests = useMemo(() => {
    return transferRequests.filter(tr => 
      tr.fromChurchId === activeChurch.id || 
      tr.toChurchId === activeChurch.id || 
      (isDemoActive && (!tr.fromChurchId || tr.fromChurchId === 'church-woodlands'))
    );
  }, [transferRequests, activeChurch.id, isDemoActive]);

  const scopedMeetings = useMemo(() => {
    return meetings.filter(m => 
      m.churchId === activeChurch.id || 
      (isDemoActive && (!m.churchId || m.churchId === 'church-woodlands'))
    );
  }, [meetings, activeChurch.id, isDemoActive]);

  const scopedOfficers = useMemo(() => {
    return officers.filter(o => 
      o.churchId === activeChurch.id || 
      (isDemoActive && (!o.churchId || o.churchId === 'church-woodlands'))
    );
  }, [officers, activeChurch.id, isDemoActive]);

  const scopedStudyGuideOrders = useMemo(() => {
    return studyGuideOrders.filter(o => 
      o.churchId === activeChurch.id || 
      (isDemoActive && (!o.churchId || o.churchId === 'church-woodlands'))
    );
  }, [studyGuideOrders, activeChurch.id, isDemoActive]);

  const scopedAttendance = useMemo(() => {
    if (isDemoActive) return attendanceRecords;
    return attendanceRecords.filter(r => scopedClasses.some(c => c.id === r.classId));
  }, [attendanceRecords, scopedClasses, isDemoActive]);

  // Scoped financial records
  const scopedBankAccounts = useMemo(() => isDemoActive ? bankAccounts : bankAccounts.filter(b => (b as any).churchId === activeChurch.id), [bankAccounts, isDemoActive, activeChurch.id]);
  const scopedRemittances = useMemo(() => isDemoActive ? remittances : remittances.filter(r => (r as any).churchId === activeChurch.id), [remittances, isDemoActive, activeChurch.id]);
  const scopedSsTransmissions = useMemo(() => isDemoActive ? ssTransmissions : ssTransmissions.filter(s => (s as any).churchId === activeChurch.id), [ssTransmissions, isDemoActive, activeChurch.id]);
  const scopedDisbursements = useMemo(() => isDemoActive ? disbursements : disbursements.filter(d => (d as any).churchId === activeChurch.id), [disbursements, isDemoActive, activeChurch.id]);
  const scopedAuxiliaryDepartments = useMemo(() => isDemoActive ? auxiliaryDepartments : auxiliaryDepartments.filter(a => (a as any).churchId === activeChurch.id), [auxiliaryDepartments, isDemoActive, activeChurch.id]);
  const scopedEnvelopes = useMemo(() => isDemoActive ? envelopes : envelopes.filter(e => (e as any).churchId === activeChurch.id), [envelopes, isDemoActive, activeChurch.id]);
  const scopedLooseOfferings = useMemo(() => isDemoActive ? looseOfferings : looseOfferings.filter(l => (l as any).churchId === activeChurch.id), [looseOfferings, isDemoActive, activeChurch.id]);
  const scopedLiteratureOrders = useMemo(() => isDemoActive ? literatureOrders : literatureOrders.filter(l => (l as any).churchId === activeChurch.id), [literatureOrders, isDemoActive, activeChurch.id]);
  const scopedAuditRecords = useMemo(() => isDemoActive ? auditRecords : auditRecords.filter(a => (a as any).churchId === activeChurch.id), [auditRecords, isDemoActive, activeChurch.id]);

  // Find the specific class for the current teacher
  const getTeacherClass = () => {
    if (!currentUser || currentUser.role !== Role.TEACHER) return undefined;
    
    // Try to find the exact assigned class in this church
    const assignedClass = scopedClasses.find(c => c.id === currentUser.assignedClass);
    if (assignedClass) return assignedClass;
    
    // If assigned class not found, find any class that has this user as teacherId
    const teacherIdClass = scopedClasses.find(c => c.teacherId === currentUser.id);
    if (teacherIdClass) return teacherIdClass;

    return undefined;
  };

  // Determine effective dashboard to display (handles Elder inspection mode)
  const effectiveRole = currentUser 
    ? (currentUser.role === Role.CHURCH_ADMIN ? (elderInspectionRole || Role.CHURCH_ADMIN) : currentUser.role)
    : null;

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-blue-950 text-white">
        <div className="bg-white p-6 rounded-3xl shadow-2xl mb-8 animate-pulse">
          <SDALogo className="w-48 h-24" />
        </div>
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
        <p className="mt-6 text-[10px] font-black uppercase tracking-[0.4em] text-blue-300">Synchronizing Registry...</p>
      </div>
    );
  }

  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col">
        {dbError && (
          <div className="bg-amber-500 text-white px-4 py-2 flex items-center justify-center gap-3 font-black text-[10px] uppercase tracking-widest animate-in slide-in-from-top duration-500 z-[100]">
            <DatabaseZap className="w-4 h-4" />
            {dbError}
          </div>
        )}
        {currentUser && (
          <Navigation 
            user={currentUser} 
            churchStation={activeChurch}
            churches={churches}
            onSwitchChurch={setActiveChurchId}
            onLogout={handleLogout} 
            onProfileClick={() => setIsProfileModalOpen(true)}
            onSwitchRole={handleSwitchRole} 
            onOpenPitchModal={() => setIsPitchModalOpen(true)}
            onFastSwitchPersona={handleFastSwitchPersona}
          />
        )}
        {currentUser && isProfileModalOpen && (
          <ProfileModal 
            user={currentUser} 
            onClose={() => setIsProfileModalOpen(false)} 
            updatePassword={updateUserPassword} 
          />
        )}
        <ClientPitchModal 
          isOpen={isPitchModalOpen} 
          onClose={() => setIsPitchModalOpen(false)} 
        />

        {/* Elder Inspection Notification Banner */}
        {currentUser?.role === Role.CHURCH_ADMIN && elderInspectionRole && (
          <div className="bg-slate-950 text-white px-6 py-3 border-b-2 border-amber-400 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md z-40">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-widest text-amber-300 font-black block">
                  Elder Executive Inspection Mode
                </span>
                <p className="text-xs font-bold text-slate-200">
                  Currently previewing: <strong className="text-white underline uppercase">{elderInspectionRole}</strong> dashboard
                </p>
              </div>
            </div>
            <button
              onClick={() => setElderInspectionRole(null)}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 shadow-xs transition-all active:scale-95 shrink-0"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Return to Elder Admin Portal
            </button>
          </div>
        )}

        <main className="flex-grow">
          <Routes>
            <Route 
              path="/signup" 
              element={
                !currentUser ? (
                  <SignupPage 
                    onRegisterChurch={handleRegisterChurch} 
                    onAutoLogin={handleLogin} 
                    conferences={conferences}
                    districts={districts}
                  />
                ) : (
                  <Navigate to="/" />
                )
              } 
            />
            <Route 
              path="/login" 
              element={
                !currentUser ? (
                  <LoginPage 
                    onLogin={handleLogin} 
                    superAdmins={superAdmins}
                    conferencePresidents={conferencePresidents}
                    districtPastors={districtPastors}
                    churchAdmins={churchAdmins}
                    clerks={clerks}
                    admins={admins}
                    teachers={teachers} 
                    treasurers={treasurers} 
                    superintendents={superintendents}
                    churches={churches}
                    activeChurchId={activeChurchId}
                    onSelectChurch={setActiveChurchId}
                  />
                ) : <Navigate to="/" />
              } 
            />
            
            <Route 
              path="/superintendent"
              element={
                !currentUser ? (
                  <Navigate to="/login" />
                ) : (currentUser.role === Role.SUPERINTENDENT || currentUser.role === Role.CHURCH_ADMIN) ? (
                  <SuperintendentDashboard
                    user={currentUser}
                    mobilisationPlan={mobilisationPlan}
                    onToggleMobilisationItem={handleToggleMobilisationItem}
                    onAddMobilisationItem={handleAddMobilisationItem}
                    conferenceEmphases={conferenceEmphases}
                    curriculumInventory={curriculumInventory}
                    onUpdateCurriculum={handleUpdateCurriculum}
                    programRunSheet={programRunSheet}
                    onUpdateRunSheet={handleUpdateRunSheet}
                    councilMembers={councilMembers}
                    auxiliaryOfficers={auxiliaryOfficers}
                    onAddAuxiliaryOfficer={handleAddAuxiliaryOfficer}
                    teacherCandidates={teacherCandidates}
                    onUpdateTeacherCandidate={handleUpdateTeacherCandidate}
                    onAddTeacherCandidate={handleAddTeacherCandidate}
                    teachersMeetings={teachersMeetings}
                    onAddTeachersMeeting={handleAddTeachersMeeting}
                    evangelismProjects={evangelismProjects}
                    onAddEvangelismProject={handleAddEvangelismProject}
                    onUpdateEvangelismProject={handleUpdateEvangelismProject}
                    greetingSchedules={greetingSchedules}
                    onAddGreetingSchedule={handleAddGreetingSchedule}
                    quarterlyReport={quarterlyReport}
                    onUpdateQuarterlyReport={handleUpdateQuarterlyReport}
                    churchMembers={scopedMembers}
                    financialTransmissions={mappedFinancialTransmissions}
                    classSessions={classSessions}
                    teachers={scopedTeachers}
                    classes={scopedClasses}
                    onAddTeacher={addTeacher}
                    onUpdateTeacher={updateTeacher}
                    onDeleteTeacher={deleteTeacher}
                    onUpdatePassword={updateUserPassword}
                    studyGuideOrders={scopedStudyGuideOrders}
                    onAddStudyGuideOrder={handleAddStudyGuideOrder}
                    onUpdateStudyGuideOrder={handleUpdateStudyGuideOrder}
                    onDeleteStudyGuideOrder={handleDeleteStudyGuideOrder}
                  />
                ) : (
                  <Navigate to="/" />
                )
              }
            />

            <Route 
              path="/" 
              element={
                !currentUser ? (
                  <Navigate to="/login" />
                ) : effectiveRole === Role.SUPER_ADMIN ? (
                  <SuperAdminDashboard
                    user={currentUser}
                    conferences={conferences}
                    districts={districts}
                    churches={churches}
                    churchMembers={churchMembers}
                    onAddConference={handleAddConference}
                    onNavigateToConference={(targetConfId) => {
                      const targetConf = conferences.find(c => c.id === targetConfId);
                      if (targetConf) {
                        const pres = conferencePresidents.find(p => p.conferenceId === targetConfId) || {
                          id: `pres-${targetConf.id}`,
                          name: targetConf.presidentName,
                          email: targetConf.presidentEmail,
                          role: Role.CONFERENCE_PRESIDENT,
                          conferenceId: targetConf.id,
                          conferenceName: targetConf.name,
                          title: 'Conference President (Territory Overseer)'
                        } as User;
                        setCurrentUser(pres);
                        localStorage.setItem('sda_current_user', JSON.stringify(pres));
                      }
                    }}
                  />
                ) : effectiveRole === Role.CONFERENCE_PRESIDENT ? (
                  <ConferenceDashboard
                    user={currentUser}
                    conference={activeConference}
                    districts={districts}
                    churches={churches}
                    churchMembers={churchMembers}
                    remittances={remittances}
                    onAddDistrict={handleAddDistrict}
                    onNavigateToDistrict={(targetDistId) => {
                      const targetDist = districts.find(d => d.id === targetDistId);
                      if (targetDist) {
                        const pastor = districtPastors.find(p => p.districtId === targetDistId) || {
                          id: `pastor-${targetDist.id}`,
                          name: targetDist.pastorName,
                          email: targetDist.pastorEmail,
                          role: Role.DISTRICT_PASTOR,
                          districtId: targetDist.id,
                          districtName: targetDist.name,
                          conferenceId: targetDist.conferenceId,
                          conferenceName: targetDist.conferenceName,
                          title: 'District Pastor (Pastoral Circuit Overseer)'
                        } as User;
                        setCurrentUser(pastor);
                        localStorage.setItem('sda_current_user', JSON.stringify(pastor));
                      }
                    }}
                  />
                ) : effectiveRole === Role.DISTRICT_PASTOR ? (
                  <DistrictDashboard
                    user={currentUser}
                    district={activeDistrict}
                    churches={churches}
                    churchMembers={churchMembers}
                    attendanceRecords={attendanceRecords}
                    onSelectChurchForPastoralCare={(targetId) => {
                      setActiveChurchId(targetId);
                      const targetChurch = churches.find(c => c.id === targetId);
                      const elder = churchAdmins.find(a => a.churchId === targetId) || {
                        id: `elder-${targetId}`,
                        name: targetChurch?.elderName || 'Presiding Elder',
                        email: targetChurch?.elderEmail || 'elder@church.org',
                        role: Role.CHURCH_ADMIN,
                        churchId: targetId,
                        churchName: targetChurch?.name || 'Woodlands SDA Church',
                        title: 'Church First Elder (Station Administrator)'
                      } as User;
                      setCurrentUser(elder);
                      localStorage.setItem('sda_current_user', JSON.stringify(elder));
                    }}
                  />
                ) : effectiveRole === Role.CHURCH_ADMIN ? (
                  <ChurchAdminDashboard
                    user={currentUser}
                    clerks={scopedClerks}
                    superintendents={scopedSuperintendents}
                    treasurers={scopedTreasurers}
                    teachers={scopedTeachers}
                    classes={scopedClasses}
                    churchMembers={scopedMembers}
                    familyUnits={scopedFamilyUnits}
                    transferRequests={scopedTransferRequests}
                    meetings={scopedMeetings}
                    officers={scopedOfficers}
                    attendanceRecords={scopedAttendance}
                    onAddOfficer={handleAddOfficerByElder}
                    onUpdateOfficer={handleUpdateOfficerByElder}
                    onDeleteOfficer={handleDeleteOfficerByElder}
                    onNavigateToView={(viewRole) => setElderInspectionRole(viewRole)}
                  />
                ) : effectiveRole === Role.SUPERINTENDENT ? (
                  <SuperintendentDashboard
                    user={currentUser}
                    mobilisationPlan={mobilisationPlan}
                    onToggleMobilisationItem={handleToggleMobilisationItem}
                    onAddMobilisationItem={handleAddMobilisationItem}
                    conferenceEmphases={conferenceEmphases}
                    curriculumInventory={curriculumInventory}
                    onUpdateCurriculum={handleUpdateCurriculum}
                    programRunSheet={programRunSheet}
                    onUpdateRunSheet={handleUpdateRunSheet}
                    councilMembers={councilMembers}
                    auxiliaryOfficers={auxiliaryOfficers}
                    onAddAuxiliaryOfficer={handleAddAuxiliaryOfficer}
                    teacherCandidates={teacherCandidates}
                    onUpdateTeacherCandidate={handleUpdateTeacherCandidate}
                    onAddTeacherCandidate={handleAddTeacherCandidate}
                    teachersMeetings={teachersMeetings}
                    onAddTeachersMeeting={handleAddTeachersMeeting}
                    evangelismProjects={evangelismProjects}
                    onAddEvangelismProject={handleAddEvangelismProject}
                    onUpdateEvangelismProject={handleUpdateEvangelismProject}
                    greetingSchedules={greetingSchedules}
                    onAddGreetingSchedule={handleAddGreetingSchedule}
                    quarterlyReport={quarterlyReport}
                    onUpdateQuarterlyReport={handleUpdateQuarterlyReport}
                    churchMembers={scopedMembers}
                    financialTransmissions={mappedFinancialTransmissions}
                    classSessions={classSessions}
                    teachers={scopedTeachers}
                    classes={scopedClasses}
                    onAddTeacher={addTeacher}
                    onUpdateTeacher={updateTeacher}
                    onDeleteTeacher={deleteTeacher}
                    onUpdatePassword={updateUserPassword}
                    studyGuideOrders={scopedStudyGuideOrders}
                    onAddStudyGuideOrder={handleAddStudyGuideOrder}
                    onUpdateStudyGuideOrder={handleUpdateStudyGuideOrder}
                    onDeleteStudyGuideOrder={handleDeleteStudyGuideOrder}
                  />
                ) : effectiveRole === Role.TREASURER ? (
                  <TreasurerDashboard
                    user={currentUser}
                    churchMembers={scopedMembers}
                    bankAccounts={scopedBankAccounts}
                    onAddBankAccount={handleAddBankAccount}
                    onReconcileAccount={handleReconcileAccount}
                    remittances={scopedRemittances}
                    onCompileRemittance={handleCompileRemittance}
                    onAcknowledgeReceipt={handleAcknowledgeReceipt}
                    ssTransmissions={scopedSsTransmissions}
                    onRecordSSTransmission={handleRecordSSTransmission}
                    disbursements={scopedDisbursements}
                    auxiliaryDepartments={scopedAuxiliaryDepartments}
                    onAddDisbursement={handleAddDisbursement}
                    onReceiveAuxiliaryFunds={handleReceiveAuxiliaryFunds}
                    envelopes={scopedEnvelopes}
                    looseOfferings={scopedLooseOfferings}
                    literatureOrders={scopedLiteratureOrders}
                    onAddEnvelope={handleAddEnvelope}
                    onAddLooseOffering={handleAddLooseOffering}
                    onAddLiteratureOrder={handleAddLiteratureOrder}
                    onUpdateLiteratureStatus={handleUpdateLiteratureStatus}
                    auditRecords={scopedAuditRecords}
                    onAddNewAudit={handleAddNewAudit}
                  />
                ) : effectiveRole === Role.CLERK ? (
                  <ClerkDashboard 
                    user={currentUser}
                    teachers={scopedTeachers} 
                    classes={scopedClasses} 
                    announcements={announcements} 
                    attendanceRecords={scopedAttendance}
                    deleteStudent={deleteStudent}
                    admins={admins}
                    transferRequests={scopedTransferRequests}
                    initiateTransfer={initiateTransfer}
                    updateTransferStatus={updateTransferStatus}
                    updateTransferStage={updateTransferStage}
                    churchMembers={scopedMembers}
                    addChurchMember={addChurchMember}
                    updateChurchMember={updateChurchMember}
                    deleteChurchMember={deleteChurchMember}
                    familyUnits={scopedFamilyUnits}
                    addFamilyUnit={addFamilyUnit}
                    updateFamilyUnit={updateFamilyUnit}
                    deleteFamilyUnit={deleteFamilyUnit}
                    meetings={scopedMeetings}
                    addMeeting={addMeeting}
                    updateMeeting={updateMeeting}
                    deleteMeeting={deleteMeeting}
                    officers={scopedOfficers}
                    addOfficer={addOfficer}
                    updateOfficer={updateOfficer}
                    deleteOfficer={deleteOfficer}
                  />
                ) : (
                  <TeacherDashboard 
                    user={currentUser} 
                    churchClass={getTeacherClass()}
                    submitAnnouncement={submitAnnouncement}
                    submitAttendance={submitAttendance}
                    addStudent={addStudentToClass}
                    updatePassword={updateUserPassword}
                    churchMembers={scopedMembers}
                  />
                )
              } 
            />
          </Routes>
        </main>
        
        <footer className="bg-white border-t py-6 text-center text-gray-400 text-xs font-black uppercase tracking-[0.2em]">
          &copy; {new Date().getFullYear()} Seventh-day Adventist Church • Conference Digital Registry {isBackendConnected ? (dbError ? '(Server Ready, DB Offline)' : '(Connected to Terminal)') : '(Local Mode)'}
        </footer>
      </div>
    </HashRouter>
  );
};

export default App;