import React, { useState } from 'react';
import { User, Role, ChurchStation } from '../types';
import { 
  LogOut, User as UserIcon, Building2, ChevronDown, 
  Award, Sparkles, Shield, Landmark, School, Layers, Check
} from 'lucide-react';
import SDALogo from './SDALogo';

interface NavigationProps {
  user: User;
  churchStation?: ChurchStation;
  churches?: ChurchStation[];
  onSwitchChurch?: (churchId: string) => void;
  onLogout: () => void;
  onProfileClick: () => void;
  onSwitchRole?: (role: Role) => void;
  onOpenPitchModal?: () => void;
  onFastSwitchPersona?: (role: Role) => void;
}

const Navigation: React.FC<NavigationProps> = ({ 
  user, 
  churchStation, 
  churches = [], 
  onSwitchChurch, 
  onLogout, 
  onProfileClick, 
  onSwitchRole,
  onOpenPitchModal,
  onFastSwitchPersona
}) => {
  const [isPersonaMenuOpen, setIsPersonaMenuOpen] = useState(false);

  const ALL_PERSONAS = [
    { role: Role.SUPER_ADMIN, label: 'Super Admin (System Overseer)', icon: Shield, color: 'text-purple-600' },
    { role: Role.CONFERENCE_PRESIDENT, label: 'Conference President (Territory)', icon: Landmark, color: 'text-indigo-600' },
    { role: Role.DISTRICT_PASTOR, label: 'District Pastor (Circuit)', icon: School, color: 'text-teal-600' },
    { role: Role.CHURCH_ADMIN, label: 'First Elder (Local Church Admin)', icon: Building2, color: 'text-amber-600' },
    { role: Role.CLERK, label: 'Church Clerk (Membership Roll)', icon: Layers, color: 'text-blue-600' },
    { role: Role.TREASURER, label: 'Church Treasurer (Sacred Trust)', icon: Building2, color: 'text-amber-600' },
    { role: Role.SUPERINTENDENT, label: 'SS Superintendent (Discipleship)', icon: Layers, color: 'text-indigo-600' },
    { role: Role.TEACHER, label: 'Sabbath School Teacher (Class)', icon: Layers, color: 'text-emerald-600' },
  ];

  return (
    <nav className="bg-white border-b border-slate-100 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center gap-3 sm:gap-5">
            <div className="bg-white px-2 py-1 rounded-xl border border-slate-100 shadow-sm flex items-center justify-center shrink-0">
              <SDALogo className="w-16 h-8 sm:w-22 sm:h-11" />
            </div>
            
            {/* Tier & Station Badge / Switcher */}
            <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-2xl">
              <div className={`w-7 h-7 rounded-xl flex items-center justify-center font-black shrink-0 shadow-sm ${
                user.role === Role.SUPER_ADMIN ? 'bg-purple-950 text-purple-300' :
                user.role === Role.CONFERENCE_PRESIDENT ? 'bg-indigo-950 text-indigo-300' :
                user.role === Role.DISTRICT_PASTOR ? 'bg-teal-950 text-teal-300' :
                'bg-blue-950 text-amber-400'
              }`}>
                <Building2 className="w-3.5 h-3.5" />
              </div>
              <div className="text-left">
                {user.role === Role.SUPER_ADMIN ? (
                  <>
                    <span className="text-xs font-black uppercase text-purple-950 tracking-tight block">
                      General Administration
                    </span>
                    <span className="text-[9px] font-bold text-purple-600 uppercase tracking-wider block">
                      Union / Division Level
                    </span>
                  </>
                ) : user.role === Role.CONFERENCE_PRESIDENT ? (
                  <>
                    <span className="text-xs font-black uppercase text-indigo-950 tracking-tight block">
                      {user.conferenceName || 'Lusaka Conference'}
                    </span>
                    <span className="text-[9px] font-bold text-indigo-600 uppercase tracking-wider block">
                      Conference Headquarters
                    </span>
                  </>
                ) : user.role === Role.DISTRICT_PASTOR ? (
                  <>
                    <span className="text-xs font-black uppercase text-teal-950 tracking-tight block">
                      {user.districtName || 'Woodlands District'}
                    </span>
                    <span className="text-[9px] font-bold text-teal-600 uppercase tracking-wider block">
                      Pastoral Circuit • {user.conferenceName || 'Conference Field'}
                    </span>
                  </>
                ) : churches.length > 1 && onSwitchChurch ? (
                  <select
                    value={churchStation?.id || user.churchId || ''}
                    onChange={(e) => onSwitchChurch(e.target.value)}
                    className="text-xs font-black uppercase tracking-tight text-slate-900 bg-transparent border-none outline-none cursor-pointer pr-2"
                  >
                    {churches.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.isDemo ? '(Demo)' : ''}
                      </option>
                    ))}
                  </select>
                ) : (
                  <>
                    <span className="text-xs font-black uppercase text-slate-900 tracking-tight block truncate max-w-[150px] sm:max-w-xs">
                      {churchStation?.name || user.churchName || 'Woodlands SDA Church'}
                    </span>
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                      {churchStation?.conference || 'SDA Conference'}
                    </span>
                  </>
                )}
              </div>
            </div>

            {/* Quick Demo Persona Switcher (Crucial for Client Demonstrations) */}
            {onFastSwitchPersona && (
              <div className="relative hidden xl:block">
                <button
                  onClick={() => setIsPersonaMenuOpen(!isPersonaMenuOpen)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>Switch Tier / Role</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {isPersonaMenuOpen && (
                  <div className="absolute left-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 space-y-1">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider px-2 py-1 block">
                      Simulate Any Tier Persona
                    </span>
                    {ALL_PERSONAS.map(p => (
                      <button
                        key={p.role}
                        onClick={() => {
                          onFastSwitchPersona(p.role);
                          setIsPersonaMenuOpen(false);
                        }}
                        className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between transition-all ${
                          user.role === p.role ? 'bg-slate-900 text-white' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <p.icon className={`w-3.5 h-3.5 ${user.role === p.role ? 'text-amber-400' : p.color}`} />
                          <span className="text-[11px] truncate">{p.label}</span>
                        </div>
                        {user.role === p.role && <Check className="w-3.5 h-3.5 text-amber-400" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Inspection View Pill (Only accessible for Church Admin Elder) */}
          {user.role === Role.CHURCH_ADMIN && onSwitchRole && (
            <div className="hidden lg:flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl text-[10px] font-black uppercase tracking-wider">
              <span className="text-slate-400 px-2 flex items-center gap-1">
                Elder Oversight:
              </span>
              <button
                onClick={() => onSwitchRole(Role.CHURCH_ADMIN)}
                className={`px-3 py-1.5 rounded-lg transition-all ${user.role === Role.CHURCH_ADMIN ? 'bg-slate-950 text-amber-400 shadow-xs' : 'text-slate-600 hover:text-slate-950'}`}
              >
                Elder Admin
              </button>
              <button
                onClick={() => onSwitchRole(Role.CLERK)}
                className="px-3 py-1.5 rounded-lg text-slate-600 hover:text-slate-950 transition-all hover:bg-white"
              >
                Clerk
              </button>
              <button
                onClick={() => onSwitchRole(Role.SUPERINTENDENT)}
                className="px-3 py-1.5 rounded-lg text-slate-600 hover:text-slate-950 transition-all hover:bg-white"
              >
                Superintendent
              </button>
              <button
                onClick={() => onSwitchRole(Role.TREASURER)}
                className="px-3 py-1.5 rounded-lg text-slate-600 hover:text-slate-950 transition-all hover:bg-white"
              >
                Treasurer
              </button>
              <button
                onClick={() => onSwitchRole(Role.TEACHER)}
                className="px-3 py-1.5 rounded-lg text-slate-600 hover:text-slate-950 transition-all hover:bg-white"
              >
                Teacher
              </button>
            </div>
          )}
          
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Executive Client Briefing / Benchmark Button */}
            {onOpenPitchModal && (
              <button
                onClick={onOpenPitchModal}
                className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 hover:from-amber-400 hover:to-amber-500 font-black text-xs uppercase tracking-wider shadow-sm transition-all active:scale-95"
              >
                <Award className="w-4 h-4 text-slate-950" />
                <span>Client Briefing & Benchmark</span>
              </button>
            )}

            <div className="hidden md:block text-right">
              <p className="text-sm font-black text-slate-900 tracking-tight">{user.name}</p>
              <p className="text-[10px] font-black uppercase tracking-[0.2em]">
                {user.role === Role.SUPER_ADMIN && <span className="text-purple-600 font-bold">System Super Admin</span>}
                {user.role === Role.CONFERENCE_PRESIDENT && <span className="text-indigo-600 font-bold">Conference President</span>}
                {user.role === Role.DISTRICT_PASTOR && <span className="text-teal-600 font-bold">District Pastor</span>}
                {user.role === Role.CHURCH_ADMIN && <span className="text-amber-600 font-bold">Church Admin Elder</span>}
                {user.role === Role.SUPERINTENDENT && <span className="text-indigo-600 font-bold">SS Superintendent</span>}
                {user.role === Role.CLERK && <span className="text-blue-600">Church Clerk</span>}
                {user.role === Role.TREASURER && <span className="text-amber-600 font-bold">Church Treasurer</span>}
                {user.role === Role.TEACHER && <span className="text-emerald-600">Authorized Teacher</span>}
              </p>
            </div>
            <button 
              onClick={onProfileClick}
              className="h-10 w-10 sm:h-11 sm:w-11 bg-slate-50 rounded-2xl flex items-center justify-center border border-slate-200 text-slate-500 shadow-xs hover:bg-white hover:text-blue-600 hover:border-blue-200 transition-all active:scale-95"
              title="View Profile"
            >
              <UserIcon className="w-4 h-4" />
            </button>
            <button 
              onClick={onLogout}
              className="p-2.5 sm:p-3 bg-red-50 text-red-600 rounded-2xl hover:bg-red-600 hover:text-white transition-all active:scale-95 shadow-xs"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
