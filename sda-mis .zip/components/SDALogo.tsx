
import React from 'react';

interface SDALogoProps {
  className?: string;
}

const SDALogo: React.FC<SDALogoProps> = ({ className = "w-12 h-12" }) => {
  return (
    <img 
      src="sda.png" 
      alt="Seventh-day Adventist Logo" 
      className={`${className} object-contain`}
    />
  );
};

export default SDALogo;
